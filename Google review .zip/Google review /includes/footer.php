
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.js"></script>

<!-- <script src="../assets/js/gr.js"></script> -->


<script>

 function updateClock() {
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes().toString().padStart(2, '0');
    var seconds = now.getSeconds().toString().padStart(2, '0');
    
    hours = hours % 12;
    hours = hours ? hours : 12;

    var timeString = hours.toString().padStart(2, '0') + ':' + minutes ;

    document.getElementById('clock').innerHTML = timeString;

 }

 setInterval(updateClock, 1000);
 updateClock(); // Call the function immediately to display the clock on page load
</script>
</body>
</html>
<?php 
// Get the current URL
$currentURL = $_SERVER['REQUEST_URI'];

// Function to check if a given URL is the current URL
function isCurrentURL($url, $currentURL) {
    return (strpos($currentURL, $url) !== false);
}
echo 'hh';
?>
<div class="sidebar-main-section">
   <div class="brand-title">
      <a class="d-inline-flex align-items-center cursor-pointer" href="/">
         <img class="img-fluid Feedback px-1" src="../assets/img/logo.png" alt="">
      </a>
   </div>
   <div class="sidebar-main-section-inner pt-xl-1">
      <div class="nav flex-column nav-pills me-3">
         <a href="<?php echo base_url().'view/dashboard.php'?>">
            <button class="nav-link <?php echo (isCurrentURL('/dashboard.php', $currentURL) ? 'active' : ''); ?>"  type="button" role="tab" >
            <img class="menu-img active" src="../assets/img/Menu (1).png" alt="">
            <img class="menu-img d-none" src="../assets/img/Menu (1).png" alt="">Dashboard </button>
        </a>
        <?php if($_SESSION['user_id']) { ?>
         <a href="<?php echo base_url().'view/users.php'?>">
            <button class="nav-link <?php echo (isCurrentURL('/users.php', $currentURL) ? 'active' : ''); ?>" type="button" role="tab" >
            <img class="menu-img active" src="../assets/img/Profile user.png" alt="">
            <img class="menu-img d-none" src="../assets/img/Profile user.png" alt="">Users</button>
        </a>
        <?php } ?>
         <a href="<?php echo base_url().'view/search.php'?>">
         <button class="nav-link <?php echo (isCurrentURL('/search.php', $currentURL) ? 'active' : ''); ?>" type="button" role="tab" >
         <img class="menu-img active" src="../assets/img/Loupe (2).png" alt="">
         <img class="menu-img d-none"
            src="../assets/img/Loupe (2).png" alt="">Search</button></a>
         <a href="<?php echo base_url().'view/proposal.php'?>">
         <button class="nav-link <?php echo (isCurrentURL('/proposal.php', $currentURL) ? 'active' : ''); ?>"  type="button" role="tab">
         <img class="menu-img active" src="../assets/img/Fair trade (1).png" alt="">
         <img  class="menu-img d-none" src="../assets/img/Fair trade (1).png" alt="">Proposals & <br>
         Responses</button></a>
         <a href="<?php echo base_url().'view/submission.php'?>">
         <button class="nav-link <?php echo (isCurrentURL('/submission.php', $currentURL) ? 'active' : ''); ?>" type="button" role="tab">
         <img class="menu-img active" src="../assets/img/Checklist (1).png" alt=""><img
            class="menu-img d-none" src="../assets/img/Checklist (1).png" alt="">Submissions</button> </a>
         <!-- <a href="<?php //echo base_url().'/view/report.php'?>"> 
            <button class="nav-link <?php //echo (isCurrentURL('/report.php', $currentURL) ? 'active' : ''); ?>"  type="button" role="tab" >
            <img class="menu-img active" src="../assets/img/Report.png" alt=""><img
            class="menu-img d-none" src="../assets/img/Report.png" alt="">Reports</button>
         </a> -->
         <a href="<?php echo base_url().'logout.php'?>"> 
            <button class="nav-link"  type="button" role="tab" >
            <img class="menu-img active" src="../assets/img/Report.png" alt=""><img
            class="menu-img d-none" src="../assets/img/Report.png" alt="">Logout</button>
         </a>
      </div>
   </div>
</div>
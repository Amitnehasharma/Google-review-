<?php
    include('config/connection.php');
    header("Location: view/login.php"); 
?>
<?php 
function base_url() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    return "$protocol://$host" . dirname(dirname($script));
}

function headerHtml($text='') {
   date_default_timezone_set('Asia/Kolkata');
    $profile_pic=  $_SESSION['profile_pic'];
    $full_name=  $_SESSION['full_name'];
    $date = date("d-m-Y");
    $current_time = date("h:i");
    $html = '<header class="header-fix-top-section boder-top">
    <div class="container">
       <div class="row align-items-center">
          <div class="col-4">
             <div class="title">
                <h1 class="m-0">'.$text.'</h1>
             </div>
          </div>
          <div class="col-4 offset-1">
             <div class="calendar-title">
                <div class="calendar-inner">
                   <img src="../assets/img/Calendar.png" alt="">
                   <span>'.$date.'</span>
                </div>
                <div class="calendar-inner">
                   <img src="../assets/img/Clock.png" alt="">
                   <span id="clock">'.$current_time.'</span>
                </div>
             </div>
          </div>
          <div class="col-3">
             <div class="profile-title">
                <div class="profile-img">
                   <img src="'.base_url().'/uploads/'.$profile_pic.'" alt="">
                </div>
                <div class="profile-name">
                   <p class="m-0">Your profile </p>
                   <h6>'.$full_name.'</h6>
                </div>
             </div>
          </div>
       </div>
    </div>
 </header>
 ';

    return $html;
}

function updatePagination($totalPage, $itemsPerPage, $currentPage, $tab,$search) {
   $totalPages = ceil($totalPage / $itemsPerPage);
   $startPage = max(1, $currentPage - 2);
   $endPage = min($startPage + 3, $totalPages);
   if($currentPage==1){
      $paginationHtml = '<a   class="Me_Btn non-active  me-1" ' . ($currentPage == 1 ? 'disabled' : '') . '>Prev</a>';
   }
   else{
      $paginationHtml = '<a  href="?page=' . ($currentPage - 1) . '&tab=' . $tab . '&search=' . $search . '&limit=' . $itemsPerPage . '" class="Me_Btn non-active  me-1" ' . ($currentPage == 1 ? 'disabled' : '') . '>Prev</a>';
   }

   for ($i = $startPage; $i <= $endPage; $i++) {
       $paginationHtml .= '<a href="?page=' . $i . '&tab=' . $tab . '&search=' . $search . '&limit=' . $itemsPerPage . '" class="Me_Btn pageLInk ' . ($i == $currentPage ? 'active' : 'non-active') . '" ' . ($i === $currentPage ? 'disabled' : '') . '  data-page="' . $i . '" search me-1">' . $i . '</a>';
   }
   if($currentPage == $totalPages){
      $paginationHtml .= '<a  class="Me_Btn  non-active" ' . ($currentPage == $totalPages ? 'disabled' : '') . '>Next</a>';
   }else{
      $paginationHtml .= '<a href="?page=' . ($currentPage + 1) . '&tab=' . $tab . '&search=' . $search . '&limit=' . $itemsPerPage . '" class="Me_Btn  non-active" ' . ($currentPage == $totalPages ? 'disabled' : '') . '>Next</a>';
   }
 
   
   echo $paginationHtml;
}



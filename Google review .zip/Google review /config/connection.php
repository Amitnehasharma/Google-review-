<?php
$host = "localhost";
$username = "googlereview_googlereview";
$password = "^!i41ydzil*qkwL7";
$database = "googlereview_googlereview";
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

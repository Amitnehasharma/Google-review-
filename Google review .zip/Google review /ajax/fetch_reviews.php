<?php
include('../config/connection.php');

if (!empty($_GET['dynamicValue'])) {
    $dynamicValue = $_GET['dynamicValue'];
    global $conn;

    // Prepare SQL statement with a placeholder for the dynamic value
    $sql = "SELECT * FROM quotes_details WHERE uniqid = ?";
    
    // Prepare the statement
    $stmt = mysqli_prepare($conn, $sql);
    
    // Bind the dynamic value to the prepared statement
    mysqli_stmt_bind_param($stmt, "s", $dynamicValue);
    
    // Execute the prepared statement
    mysqli_stmt_execute($stmt);
    
    // Get the result set
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        // Fetch data from the result set
        $data = array();
        while ($row = mysqli_fetch_assoc($result)) {
            // Unserialize the selected_reviews field
            $row['selected_reviews'] = unserialize($row['selected_reviews']);
            $data[] = $row;
        }
        // Return data as JSON response
        echo json_encode($data);
    } else {
        // Handle query execution errors
        echo json_encode(array('error' => 'Error executing SQL query: ' . mysqli_error($conn)));
    }
    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // Handle missing dynamic value
    echo json_encode(array('error' => 'Dynamic value not provided'));
}
?>

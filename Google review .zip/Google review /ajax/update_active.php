<?php

include('../config/connection.php');



if (!empty($_POST)) {

    // Print $_POST data for debugging

    print_r($_POST);



    // Retrieve uniqid and reviewChargeValue from $_POST

    $rowId = $_POST['rowId'];

    $isActive = $_POST['isActive'];



    global $conn;



     // Use prepared statement to update the row in the quotes table

    //$sql = "UPDATE quotes SET active = ? WHERE uniqid = ?";
    $sql = "UPDATE quotes SET active = ?, active_date_time = current_timestamp() WHERE uniqid = ?";

    $stmt = $conn->prepare($sql);



    // Bind parameters

    $stmt->bind_param("ss", $isActive, $rowId);



    // Execute the query

    if ($stmt->execute()) {

        echo "Data updated successfully";

    } else {

        echo "Error: " . $sql . "<br>" . $conn->error;

    }



    // Close prepared statement and database connection

    $stmt->close(); 

    $conn->close();

}
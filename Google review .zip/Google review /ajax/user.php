<?php
session_start();
include('../controllers/User.php');
if ($_POST['status']==1 && $_POST['userid']=='' ) {
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $fullName = $_POST['fullName'];
    $dob = $_POST['dob'];
    $phoneNumber = $_POST['phoneNumber'];
    $created_by  = $_SESSION['full_name'];
    $last_modification_date = date("Y-m-d H:i:s");
    $_FILE =  $_FILES;

    $user_obj  = new User();
    $res= $user_obj->Create($email,$password,$fullName,$dob,$phoneNumber,$_FILE);
    echo json_encode($res);
}
if ($_POST['status']==2 && $_POST['userid']!='') {
    $userid = $_POST['userid'];
    $email = $_POST['email'];
    $password = '';
    if($_POST['password'] != ''){
        $password = md5($_POST['password']);
    }
    $fullName = $_POST['fullName'];
    $dob = $_POST['dob'];
    $phoneNumber = $_POST['phoneNumber'];
    $created_by  = $_SESSION['full_name'];
    $last_modification_date = date("Y-m-d H:i:s");
    $_FILE =  $_FILES;
    $user_obj  = new User();
    $res= $user_obj->UserUpdate($userid,$email,$password,$fullName,$dob,$phoneNumber,$_FILE);

    echo json_encode($res);
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['status']==3) {
    $userId = $_POST['userId'];
    $user_obj  = new User();
    $user_obj->UserDeleted($userId);
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['status']==4) {
    $email = $_POST['email'];
    $user_obj  = new User();
    echo $user_obj->checkEmail($email);
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['status']==10) {
    $startIndex = $_POST['startIndex'];
    $endIndex = $_POST['endIndex'];
    $search = $_POST['search'];
    $itemsPerPage = $_POST['itemsPerPage'];
    $user_obj  = new User();
    echo $user_obj->UserPasination($startIndex,$endIndex,$search,$itemsPerPage);
}
?>

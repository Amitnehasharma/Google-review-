<?php
include('../config/connection.php');
if (!empty($_POST)) {
    $uniqid = $_POST['uniqid'];
    global $conn;

    //$sql_check_uniqid = "SELECT * FROM quotes_details WHERE uniqid = ?";
    $sql_check_uniqid = "SELECT *, (SELECT review_rate FROM quotes WHERE uniqid = ?) AS review_rate FROM quotes_details WHERE uniqid = ?";
    $stmt_check_uniqid = $conn->prepare($sql_check_uniqid);
    //$stmt_check_uniqid->bind_param("s", $uniqid);
    $stmt_check_uniqid->bind_param("ss", $uniqid, $uniqid);
    $stmt_check_uniqid->execute();
    $result_check_uniqid = $stmt_check_uniqid->get_result();

    if ($result_check_uniqid->num_rows > 0) {
        // Fetch all rows and add them to the response array
         // Fetch all rows and unserialize the selected_reviews column
         while ($row = $result_check_uniqid->fetch_assoc()) {
            // Unserialize the selected_reviews column
            $row['selected_reviews'] = unserialize($row['selected_reviews']);
            // Add the row to the response array
            $response[] = $row;
        }
        // Return the response as JSON
        //echo json_encode($response);
        echo json_encode(['status' => 2,'response' => $response]);
    } else {
        // Uniqid does not exist
        echo json_encode(array('error' => 'uniqid_not_exists'));
    }

    $stmt_check_uniqid->close();
    $conn->close();
}
?>
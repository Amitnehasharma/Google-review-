<?php
include('../config/connection.php');

if (!empty($_POST)) {
    // Print $_POST data for debugging
    print_r($_POST);

    // Retrieve uniqid and reviewChargeValue from $_POST
    $uniqid = $_POST['uniqid'];
    $reviewChargeValue = $_POST['reviewChargeValue'];

    global $conn;
    $status = 1;

    // Use prepared statement to update the row in the quotes table
    $sql = "UPDATE quotes SET review_rate = ?, status = ?, submit_date = NOW() WHERE uniqid = ?";
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("sss", $reviewChargeValue, $status, $uniqid);

    // Execute the query
    if ($stmt->execute()) {
        echo "Data updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close prepared statement and database connection
    $stmt->close();
    $conn->close();
}
?>

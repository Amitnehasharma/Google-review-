<?php
include('../config/connection.php');

if (!empty($_POST['middleColId'])) {
    $middleColId = $_POST['middleColId'];
    global $conn;

    // Prepare SQL statement with a placeholder for the dynamic value
    $sql = "SELECT body FROM quotes_details_transactions WHERE id = ?";
    
    // Prepare the statement
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt === false) {
        // Handle prepare statement error
        die(json_encode(array('error' => 'Error preparing SQL statement: ' . mysqli_error($conn))));
    }
    
    // Bind the dynamic value to the prepared statement
    $bindResult = mysqli_stmt_bind_param($stmt, "i", $middleColId); // Use "i" for integer types
    if ($bindResult === false) {
        // Handle bind parameter error
        die(json_encode(array('error' => 'Error binding parameter: ' . mysqli_error($conn))));
    }
    
    // Execute the prepared statement
    $executeResult = mysqli_stmt_execute($stmt);
    if ($executeResult === false) {
        // Handle execute statement error
        die(json_encode(array('error' => 'Error executing SQL statement: ' . mysqli_error($conn))));
    }
    
    // Get the result set
    $result = mysqli_stmt_get_result($stmt);
    if ($result === false) {
        // Handle get result error
        die(json_encode(array('error' => 'Error getting result set: ' . mysqli_error($conn))));
    }

    // Fetch data from the result set
    $data = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    // Return data as JSON response
    echo json_encode($data);

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // Handle missing dynamic value
    echo json_encode(array('error' => 'Dynamic value not provided'));
}
?>

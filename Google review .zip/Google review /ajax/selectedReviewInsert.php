<?php
include('../config/connection.php');

// Check if $_POST is not empty
if (!empty($_POST)) {
    // Print $_POST data for debugging
    print_r($_POST);

    // Retrieve uniqid from $_POST
    $uniqid = $_POST['uniqid'];
    $review_id = $_POST['review_id'];
    $place_id = $_POST['place_id'];

    // Serialize $_POST data
    $serializedData = serialize($_POST);

    global $conn;
    // Use prepared statement to insert data into the database
    $sql = "INSERT INTO quotes_details (uniqid, review_id, place_id, selected_reviews,author_name,review_link) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $uniqid, $review_id, $place_id, $serializedData, $_POST['authorName'], $_POST['review_link']);


    if ($stmt->execute()) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close prepared statement and database connection
    $stmt->close();
    $conn->close();
} else {
    echo "No data received from the form";
}
?>

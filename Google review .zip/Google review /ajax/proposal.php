<?php 
session_start();
include('../controllers/QuoteView.php');
if ($_SERVER["REQUEST_METHOD"] == "POST" && $_POST['status']==1) {
    $id = $_POST['id'];
    $proposal_obj  = new QuoteView();
    $proposal_obj->ProposalDeleted($id);
}
?>
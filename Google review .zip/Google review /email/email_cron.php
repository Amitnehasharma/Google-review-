

<?php

//require 'PHPMailer/PHPMailerAutoload.php';
include('../config/connection.php');
session_start();
$imap_username = 'resoluteme16@gmail.com';
$imap_password = 'hjygmivsalcdzubv';

// Enable the IMAP extension
if (!extension_loaded('imap')) {
   dl('imap.so'); // Load the IMAP extension dynamically
}
$inbox = imap_open('{imap.gmail.com:993/imap/ssl}INBOX', $imap_username, $imap_password) or die('Cannot connect to gmail: ' . imap_last_error());

$prev_date = date('j-M-Y', strtotime(date('Y-m-d') . ' - 0 days'));

$emails = imap_search($inbox, 'SINCE ' . $prev_date);

if ($emails) {


    rsort($emails);

    foreach ($emails as $email_number) {
        $header = imap_headerinfo($inbox, $email_number);

        $subject = imap_utf8($header->subject);
        $toaddress = $header->toaddress;
        
        $from_email = '';
        $from_name = '';

        foreach ($header->from as $receiver) {
            $from_email = $receiver->mailbox . '@' . $receiver->host;
            $from_name = imap_utf8($receiver->personal);
        }

        $mail_body = imap_fetchbody($inbox, $email_number, 1);
        $mail_date = date('Y-m-d H:i:s', strtotime($header->date));

        $msg_no = $header->Msgno;

        $query = "SELECT * FROM emails_records WHERE msg_no = '$msg_no'";
        $result = $conn->query($query);

        // If the message number doesn't exist, insert the email data into the database
        if ($result->num_rows == 0) {
            $subject = mysqli_real_escape_string($conn, $subject);
            $toaddress = mysqli_real_escape_string($conn, $toaddress);
            $from_email = mysqli_real_escape_string($conn, $from_email);
            $from_name = mysqli_real_escape_string($conn, $from_name);
            $mail_body = mysqli_real_escape_string($conn, $mail_body);
            $mail_date = mysqli_real_escape_string($conn, $mail_date);
            $msg_no = mysqli_real_escape_string($conn, $msg_no);
            
            // Insert data into the table
            $sql = "INSERT INTO emails_records (subject, toaddress, senderaddress, sender_name, mail_body, mail_date, msg_no)
                    VALUES ('$subject', '$toaddress', '$from_email', '$from_name', '$mail_body', '$mail_date', '$msg_no')";

            if ($conn->query($sql) === TRUE) {
            }
        }
        
    }

    $conn->close();
}

imap_close($inbox);
?>

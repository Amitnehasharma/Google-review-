<?php 

echo 'hello';
?>
<?php
session_start();
include('../config/connection.php');
 
// IMAP Server settings

//with ssl hostname
// $hostname = '{mail.bewertungsentferner.com:993/imap/ssl}INBOX';

//without ssl hostname
$hostname = '{mail.bewertungsentferner.com:993/imap/ssl/novalidate-cert}INBOX';
$username = 'pot@bewertungsentferner.com';
$password = 'Sternehero@123';

// Connect to the IMAP server
$inbox = imap_open($hostname, $username, $password) or die('Cannot connect to IMAP: ' . imap_last_error());
$usernameParts = explode('@', $username);
$currentEmailAddress = $usernameParts[0] . '@' . $usernameParts[1]; // Construct email address
// Search for emails received by the current user since the previous day
$searchResult = imap_search($inbox, 'TO "' . $currentEmailAddress . '" SINCE "' . $prevDateStr . '"');
// Get the total number of messages in the inbox
$totalMessages = imap_num_msg($inbox);

// Loop through each message

$currentDate = strtotime(date('Y-m-d')); // Get current date in Unix timestamp
$previousDate = strtotime('-1 day', $currentDate); // Get Unix timestamp for the previous day

// Format the previous date for use in IMAP search
$prevDateStr = date('d-M-Y', $previousDate);

// Search for emails since the previous day
$searchResult = imap_search($inbox, 'SINCE "' . $prevDateStr . '"');

// Check if any emails were found
if ($searchResult) {

    rsort($searchResult);

    // Loop through each found message
    foreach ($searchResult as $messageNumber) {
        // Fetch the email header
        $header = imap_headerinfo($inbox, $messageNumber);
        
        // Fetch additional information
        $fromName = isset($header->from[0]->personal) ? $header->from[0]->personal : '';
        $fromAddress = isset($header->from[0]->mailbox) && isset($header->from[0]->host) ? $header->from[0]->mailbox . "@" . $header->from[0]->host : '';
        $toAddress = isset($header->to[0]->mailbox) && isset($header->to[0]->host) ? $header->to[0]->mailbox . "@" . $header->to[0]->host : '';
        $mailDate = isset($header->date) ? $header->date : '';
        $messageNo = isset($header->Msgno) ? $header->Msgno : '';
        
        $body = imap_body($inbox, $messageNumber, 1);
        $decodedBody = quoted_printable_decode($body);
        
        // Find the position of the first <p> tag
        $htmlStartPos = strpos($decodedBody, '<p');
        
        // Find the position of the last </p> tag
        $htmlEndPos = strrpos($decodedBody, '</p>');
        $htmlBody ='';
        if ($htmlStartPos !== false && $htmlEndPos !== false) {
            // Extract HTML content
            $htmlBody = substr($decodedBody, $htmlStartPos, $htmlEndPos - $htmlStartPos + strlen('</p>'));
        } 
        
        $old_details = $conn->query("SELECT * FROM quotes_details_transactions WHERE messageno = ".$messageNo);
        if($old_details->num_rows == 0){
            $quotes_details = $conn->query("SELECT * FROM quotes_details WHERE not_possible IS NULL AND deleted IS NULL AND email_id = '".$toAddress."'");
            if($quotes_details->num_rows > 0){

                while($row = $quotes_details->fetch_assoc()) {
                    $dateTime = DateTime::createFromFormat('D, d M Y H:i:s O', $mailDate);
                    $phpDatetime = $dateTime->format('Y-m-d H:i:s');

                    $uniqid = $row['uniqid'];
                    $quote_details_id = $row['id'];
                    $conn->query("INSERT INTO quotes_details_transactions(uniqid, quote_details_id, subject, body, trans_date, messageno)
                    VALUES ('".$uniqid."', ".$quote_details_id.", '".$header->subject."', '".$htmlBody."', '".$phpDatetime."', ".$messageNo.")");
                }
                
                if(strpos($decodedBody, 'Ihre befindet sich nun in der Warteschlange und wir werden') !== false){
                    // echo 'Status 1 - Review deletion Form submit request received';
                }elseif(strpos($decodedBody, 'Leider konnten wir anhand der von Ihnen angegebenen Informationen') !== false){
                    // echo 'Status 2 - Not possible to delete review';
                    $conn->query("UPDATE quotes_details SET not_possible = 1 WHERE id = ".$quote_details_id);
                    $conn->query("UPDATE email_list SET IsActive = 0 WHERE email = ".$toAddress);
                }elseif(strpos($decodedBody, 'wir haben eine Antwort auf Ihre schriftliche Mitteilung erhalten:') !== false){
                    // echo 'Status 3';
                    $conn->query("UPDATE quotes_details SET not_possible = 1 WHERE id = ".$quote_details_id);
                    $conn->query("UPDATE email_list SET IsActive = 0 WHERE email = ".$toAddress);
                }elseif(strpos($decodedBody, 'Der folgende Inhalt wird in Kürze entfernt:') !== false){
                    $conn->query("UPDATE quotes_details SET deleted = 1 WHERE id = ".$quote_details_id);
                    $conn->query("UPDATE email_list SET IsActive = 0 WHERE email = ".$toAddress);
                    // echo 'Status - 4 -  Review deleted shortly';
                }elseif(strpos($decodedBody, 'haben wir Ihre Beanstandung weitergeleitet:') !== false){
                    $conn->query("UPDATE quotes_details SET not_possible = 1 WHERE id = ".$quote_details_id);
                    $conn->query("UPDATE email_list SET IsActive = 0 WHERE email = ".$toAddress);
                    // echo 'Status 5';
                }
            }
        }
    }
} else {
    echo "No emails found since $prevDateStr";
}

// Close the IMAP connection
imap_close($inbox); 

?>


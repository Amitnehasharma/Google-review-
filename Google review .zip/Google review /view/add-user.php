<?php
   session_start();
   
   // Check if the user is not logged in
   if (!isset($_SESSION['user_id'])) {
       header("Location: login.php");
       exit();
   }
   
    include('../includes/header.php');
    include('../includes/sidebar.php');
   ?>
<div class="content-main-section left">
   <div class="container showdiv studentdetail">
      <div class="tab-content" id="v-pills-tabContent">
         <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab"
            tabindex="0">
            <?php echo headerHtml('Users'); ?>
            <div class="pt-2">
               <div class="container Me_padding-2">
                  <div class="floatright-d">
                     <a href='<?php echo base_url().'view/users.php';?>'><button type="button" class="Me_Btn active float-right">Users</button></a>
                  </div>
                  <div class="row   ">
                     <form id="AddUser" method="post" enctype="multipart/form-data" >
                        <div class="card ">
                           <div class="card-body row">
                              <div class="col-md-6">
                                 <!-- Full Name -->
                                 <div class="mb-3">
                                    <label for="fullName" class="form-label">Full Name*</label>
                                    <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Enter your full name" tabindex="1">
                                 </div>
                                 <!-- Password -->
                                 <div class="mb-3">
                                    <label for="password" class="form-label">Password*</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" tabindex="3" >
                                    <span id="passwordError" class="text-danger"></span>
                                 </div>
                                 <!-- Phone Number -->
                                 <div class="mb-3">
                                    <label for="phoneNumber" class="form-label">Phone Number*</label>
                                    <input type="tel" maxlength="12" minlength="10" class="form-control" id="phoneNumber"  oninput="this.value = this.value.replace(/[^0-9]/g, '');" name="phoneNumber" placeholder="Enter your phone number" tabindex="5" required>
                              
                                 </div>

                              </div>
                              <div class='col-md-6'>
                                 <!-- Email -->
                                 <div class="mb-3">
                                    <label for="email" class="form-label">Email*</label>
                                    <input type="email" class="form-control" id="email" onkeyup="checkEmailAvailability()" name="email" placeholder="Enter your email" tabindex="2">
                                    <span id="emailerror" class="error"></span>
                                 </div>
                                 <!-- Date of Birth -->
                                 <div class="mb-3">
                                    <label for="dob" class="form-label">Date of Birth*</label>
                                    <input type="text" placeholder='Select date of birth' class="form-control datepicker" id="dob" name="dob" tabindex="4">
                                 </div>
                                 <!-- Profile Picture -->
                                 <div class="mb-3">
                                    <label for="profilePic" class="form-label">Profile Picture*</label>
                                    <input type="file" class="form-control" onchange="previewImage()" id="profilePic" name="profilePic" tabindex="6">
                                 </div>
                                 <!-- Profile Img Preview -->
                                 <img id="imagePreview" class="d-none" src="" alt="Image Preview">
                              </div>
                           </div>
                           <div class="card-footer">
                              <button type="submit" class="Me_Btn active">Register</button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php 
include('../includes/footer_new.php');
?>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="../assets/js/user.js?ver=<?php echo rand(); ?>"></script>
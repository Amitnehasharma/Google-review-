<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include('../includes/header.php');
include('../includes/sidebar.php');
include('../controllers/ProposalResponse.php');

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$tab = isset($_GET['tab']) ? $_GET['tab'] : 1;
$search = isset($_GET['search']) ? $_GET['search'] : '';
$limit = isset($_GET['limit']) ? $_GET['limit'] :10;

$offset = ($page - 1) * $limit;

    // Instantiate the ProposalsResponse class
    $proposalResponse = new ProposalsResponse();

    // Call the FetchProposals method
    $proposals = $proposalResponse->FetchProposals($offset, $limit,$search);
 
    $responses = $proposalResponse->FetchResponse($offset, $limit,$search);


    $total_proposals_query = $proposalResponse->TotalProposalsCount($search);

    $total_pages_proposals = ceil($total_proposals_query / $limit);

    $total_responses_query = $proposalResponse->TotalResponsesCount($search);

   // print_r($total_responses_query);
    //$total_pages_responses = ceil($total_responses_query / $limit);

?>
<style>
    .Me_Btn.Me_Btn.search.small {
        padding: 0.5vw 1.25vw !important;
    }
</style>
<div class="content-main-section left ">
   <div class="container showdiv studentdetail">
      <div class="tab-content" id="v-pills-tabContent">
         <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab" tabindex="0">
            <?php echo headerHtml('Proposals'); ?>

            <div class="active-complete-job">
                        <div class="container-fluid">
                            <div class="row align-items-center justify-content-center">
                                <div class="row Me_padding-4">
                                    <div class="col-lg-4 proposals_btn  proposals_btn_align ">
                                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link <?php echo $tab==1?'active':''?> my-0" id="pills-proposal-tab"
                                                    data-bs-toggle="pill" data-bs-target="#pills-proposal" type="button"
                                                    role="tab" aria-controls="pills-proposal"
                                                    aria-selected="true">Proposals</button>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <button class="nav-link <?php echo $tab==2?'active':''?> my-0" id="pills-response-tab"
                                                    data-bs-toggle="pill" data-bs-target="#pills-response" type="button"
                                                    role="tab" aria-controls="pills-response"
                                                    aria-selected="false">Responses</button>
                                            </li>
                                        </ul>
                                    </div>
                                    <div class="col-lg-4">
                                        <!-- <div class="text-lg-end">
                                            <input class="Me-search" type="search" placeholder="Search client" id="searchInput"></input>
                                            <img class="Me_Btn active search" src="../assets/img/LoupeWhite.svg" id="searchBtn"></img>
                                        </div> -->
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="text-lg-end">
                                            
                                        </div>
                                    </div>
                                </div>

                                <!-- PROPOSAL TO PROPOSAL -->

                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade <?php echo $tab==1?'show active':''?>  mb-6" id="pills-proposal" role="tabpanel"
                                        aria-labelledby="pills-proposal-tab" tabindex="0">
                                        <div class="row Me_padding-4">
                                            <div class="col-lg-2 proposals_btn"></div>
                                            <div class="col-lg-6">
                                                <div class="text-lg-end">
                                                    
                                                    <input class="Me-search" type="search" value='<?php  echo $search; ?>' placeholder="Search client" id="proposal_searchInput"></input>
                                                    <img data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>' class="Me_Btn active search" src="../assets/img/LoupeWhite.svg" id="proposal_searchBtn"></img>
                                                    <select data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>' name="proposal-limit" id='proposal-limit' class="filter-list" style="margin: 0;padding: 10px 20px;">
                                                        <option value='10' <?php echo  $limit==10?'selected':''; ?>>10</option>
                                                        <option value='20' <?php echo  $limit==20?'selected':''; ?>>20</option>
                                                        <option value='50' <?php echo $limit==50?'selected':''; ?>>50</option>
                                                        <option value='100' <?php echo $limit==100?'selected':''; ?>>100</option>
                                                   </select>
                                                </div>
                                                
                                            </div>
                                            
                                            <div class="col-lg-4">
                                                <div class="text-lg-end d-flex">
                                                    <?php  updatePagination($total_proposals_query, $limit, $page,1,$search); ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row m-auto table_padd">
                                            <table class="table proposal-table">
                                                <thead>
                                                    <tr class="Me_table-Head">
                                                        <th class="Me_table-Head" scope="col">List</th>
                                                        <th scope="col">Client</th>
                                                        <th scope="col">Proposals date</th>
                                                        <th scope="col">Url Copy </th>
                                                        <th scope="col">Status </th>
                                                        <th scope="col">Action </th>
                                                        <th scope="col"></th>
                                                    </tr>
                                                </thead>
                                                
                                                <tbody class="proposals">
                                                    <?php
                                                        if (!empty($proposals)) {
                                                            $sr_number = ($page - 1) * $limit + 1;
                                                            foreach ($proposals as $proposal) {
                                                                //echo "ID: " . $proposal["id"]. " - uniqid: " . $proposal["uniqid"]. " - company_info: " . $proposal["company_info"]. " - creation_date: " . $proposal["creation_date"]."<br>";
                                                                $company_info = unserialize($proposal["company_info"]); 
                                                                $per_review_charge = unserialize($proposal["per_review_charge"]); 	
                                                    ?>
                                                                <tr id='remove-row<?php echo $proposal["uniqid"]; ?>'>
                                                                    <th scope="row"><?php echo $sr_number++; ?></th>
                                                                    <td>
                                                                        <?php
                                                                            echo $company_info['name'];
                                                                        ?>
                                                                    </td>
                                                                    <td><?php echo date('d-m-Y', strtotime($proposal["creation_date"])); ?></td>
                                                                    <td><a onclick="copyLink(this)" href="javascript:void(0)" data-link='<?php echo base_url().'qoute?'.$proposal["uniqid"]; ?>' id="copyLink">Copy Link</a> </td>
                                                                    <td><?php  if($proposal["is_seen"]==1){ echo '<span class="badge badge-success">Seen</span>'; } else {echo '<span class="badge badge-warning">Unseen</span>'; } ?></td>
                                                                    
                                                                    <td> 
                                                                        <?php $modal_id = "modal_" . $proposal["id"]; ?>
                                                                    <div class='dropdown'>
                                                                        <button class='btn dropdown-toggle' type='button' id='dropdownMenuButton' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>&#8230;</button>
                                                                        <div class='dropdown-menu' aria-labelledby='dropdownMenuButton'>
                                                                            <a class='dropdown-item' href='javascript:void(0)' data-bs-toggle="modal" data-bs-target="#<?php echo $modal_id; ?>">View</a>
                                                                            <a class='dropdown-item ProposalDelete' id='<?php echo $proposal["uniqid"]; ?>' href='javascript:void(0)'>Delete</a>
                                                                        </div>
                                                                    </div>
                                                                        <!-- <button type="button" class="bg-ff border-0"
                                                                            data-bs-toggle="modal" data-bs-target="#<?php echo $modal_id; ?>">
                                                                            <i class="bi Me_three_dot bi-three-dots-vertical"></i>
                                                                        </button> -->
                                                                        <div class="modal fade" id="<?php echo $modal_id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                            <div class="modal-dialog modal-dialog-centered">
                                                                                <div class="modal-content">
                                                                                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                                                                        <li class="nav-item" role="presentation">
                                                                                            <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                                                                                data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                                                                                aria-selected="true">Summary</button>
                                                                                        </li>
                                                                                    </ul>
                                                                                    <div class="tab-content pb-3" id="pills-tabContent">
                                                                                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab"
                                                                                            tabindex="0">
                                                                                            <div class="title mb-3">
                                                                                                <h6><?php echo $company_info['name']; ?></h6>
                                                                                            </div>
                                                                                            <div class="d-flex address">
                                                                                                <img src="../assets/img/Maps and Flags.png" alt="">
                                                                                                <p class="ps-2 mb-0"><?php echo $company_info['formatted_address']; ?></p>
                                                                                            </div>
                                                                                            <div class="d-flex align-items-center justify-content-start mb-3">
                                                                                                <p class="mb-0"><?php echo $company_info['rating']; ?>/5</p>
                                                                                                <span class="px-3 border-right">
                                                                                                   <!--  <svg xmlns="http://www.w3.org/2000/svg" width="36" height="41" viewBox="0 0 36 41"
                                                                                                        fill="none">
                                                                                                        <path
                                                                                                            d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                            fill="#FED156" />
                                                                                                        <mask id="mask0_174_3041" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
                                                                                                            width="24" height="41">
                                                                                                            <rect x="0.76001" width="22.4255" height="40.0455" fill="white" />
                                                                                                        </mask>
                                                                                                        <g mask="url(#mask0_174_3041)">
                                                                                                            <path
                                                                                                                d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                                fill="#E2E2E2" />
                                                                                                        </g>
                                                                                                    </svg>
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                        fill="none">
                                                                                                        <path
                                                                                                            d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                            fill="#FED156" />
                                                                                                    </svg>
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                        fill="none">
                                                                                                        <path
                                                                                                            d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                            fill="#FED156" />
                                                                                                    </svg>
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                        fill="none">
                                                                                                        <path
                                                                                                            d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                            fill="#FED156" />
                                                                                                    </svg> 
                                                                                                    
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                        fill="none">
                                                                                                        <path
                                                                                                            d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                            fill="#FED156" />
                                                                                                    </svg>-->
                                                                                                       
                                                                                                    <?php 
                                                                                                        $rating = $company_info['rating'];
                                                                                                        $integer_part = floor($rating); // Get the integer part of the rating
                                                                                                        $fractional_part = $rating - $integer_part; // Get the fractional part of the rating

                                                                                                        if ($fractional_part > 0) {
                                                                                                            // Display partially filled star icon
                                                                                                            ?>
                                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="41" viewBox="0 0 36 41"
                                                                                                                fill="none">
                                                                                                                <path
                                                                                                                    d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                                    fill="#FED156" />
                                                                                                                <mask id="mask0_174_3041" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
                                                                                                                    width="24" height="41">
                                                                                                                    <rect x="0.76001" width="22.4255" height="40.0455" fill="white" />
                                                                                                                </mask>
                                                                                                                <g mask="url(#mask0_174_3041)">
                                                                                                                    <path
                                                                                                                        d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                                        fill="#E2E2E2" />
                                                                                                                </g>
                                                                                                            </svg>
                                                                                                            <?php
                                                                                                        }

                                                                                                        for ($i = 0; $i < $integer_part; $i++) {
                                                                                                            // Display filled star icon
                                                                                                            ?>
                                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                                                                                                                <path d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z" fill="#FED156" />
                                                                                                            </svg>
                                                                                                            <?php
                                                                                                        }

                                                                                                       
                                                                                                    ?>
                                                                                                </span>
                                                                                                <p class="mb-0 px-3"><?php echo $company_info['user_ratings_total']; ?> Reviews</p> 
                                                                                            </div>
                                                                                            <div class="amt_para">
                                                                                                <p>Review Deletion Price</p>
                                                                                            </div>
                                                                                           
                                                                                                <div class="amt">
                                                                                                    <span class="pe-2">Min</span>
                                                                                                    <span class=""></span>
                                                                                                    <span class="px-2">Max</span>
                                                                                                    <span class=""></span>
                                                                                                    <span class="px-2">Amt</span> 
                                                                                                    </div>
                                                                                                <div class="amt">
                                                                                                <?php foreach($per_review_charge as $charge){ ?>
                                                                                                    <span class="pe-2"><?php echo sprintf('%02d', $charge['range_min']); ?></span>
                                                                                                    <span class="px-2">-</span>
                                                                                                    <span class="px-2"><?php echo sprintf('%02d', $charge['range_max']); ?></span>
                                                                                                    <span class="px-2"></span>
                                                                                                    <span class="px-2">$<?php echo $charge['range_amt']; ?></span>  
                                                                                                <?php } ?>
                                                                                                </div>
                                                                                            
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                    <?php 
                                                            }
                                                        } else {
                                                            echo '<tr>

                                                            <td valign="top" colspan="3" class="dataTables_empty text-center">No data available in table</td>
                                                        </tr>';
                                                        } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- RESPONSES -->

                                    <div class="tab-pane  <?php echo $tab==2?'show active':''?> fade mb-6" id="pills-response" role="tabpanel"
                                        aria-labelledby="pills-response-tab" tabindex="0">
                                        <div class="row Me_padding-4">
                                            <div class="col-lg-2 proposals_btn"></div>
                                            <div class="col-lg-6">
                                                <div class="text-lg-end">
                                                    <input class="Me-search" value='<?php  echo $search; ?>' type="search" placeholder="Search client" id="searchInputResponse"></input>
                                                    <img data-page='<?php  echo $page; ?>' data-tab='<?php  echo 2; ?>' data-limit='<?php  echo $limit; ?>' class="Me_Btn active search" src="../assets/img/LoupeWhite.svg" id="searchBtnResponse"></img>
                                                    <select data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>'  name="response-limit" id='response-limit' class="filter-list" style="margin: 0;padding: 10px 20px;">
                                                        <option value='10' <?php echo $limit==10?'selected':''; ?>>10</option>
                                                        <option value='20' <?php echo $limit==20?'selected':''; ?>>20</option>
                                                        <option value='50' <?php echo $limit==50?'selected':''; ?>>50</option>
                                                        <option value='100' <?php echo  $limit==100?'selected':''; ?>>100</option>
                                                   </select>
                                                   
                                                </div>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="text-lg-end d-flex">
                                                    
                                                     <?php  updatePagination($total_responses_query, $limit, $page,2,$search); ?>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row m-auto table_padd">
                                            <table class="table response-table">
                                                <thead>
                                                    <tr class="Me_table-Head">
                                                        <th class="Me_table-Head" scope="col">List</th>
                                                        <th scope="col">Client</th>
                                                        <th scope="col">Proposals date</th>
                                                        <th scope="col">Approval date</th>
                                                        <th scope="col">No. of review</th>
                                                        <th scope="col">Rate per review</th>
                                                        <th scope="col">Value($)</th>
                                                        <th scope="col">Status</th>
                                                      
                                                        <th scope="col">Active</th>
                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="proposals">
                                                    <?php  if (!empty($responses)) {
                                                            $sr_number = ($page - 1) * $limit + 1;
                                                            foreach ($responses as $response){ 
                                                                $company_info = unserialize($response["company_info"]); 
                                                    ?>
                                                    <tr id='remove-row<?php echo $response["uniqid"]; ?>'>
                                                        <th scope="row"><?php echo $sr_number++; ?></th>
                                                        <td>
                                                            <?php
                                                                echo $company_info['name'];
                                                            ?>
                                                        </td>
                                                        <td><?php echo date('d-m-Y', strtotime($response["creation_date"])); ?></td>
                                                        <td><?php  echo date('d-m-Y', strtotime($response["submitdate"])); ?></td>
                                                        <td>
                                                            <?php
                                                                echo $response['num_occurrences'];
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                echo $response['review_rate'];
                                                            ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                echo $response['num_occurrences']*$response['review_rate'];
                                                            ?>
                                                        </td>
                                                        
                                                        <td>
                                                        <?php  if($response["is_seen"]==1){ echo '<span class="badge badge-success">Seen</span>'; } else {echo '<span class="badge badge-warning">Unseen</span>'; } ?>
                                                           
                                                        </td>
                                                        <td>
                                                            
                                                            <div
                                                                class="form-check form-switch d-flex align-items-center justify-content-around">
                                                                <input class="form-check-input flexSwitchCheckChecked" type="checkbox"
                                                                    role="switch" <?php if ($response["active"] == 1) echo 'checked'; ?>>
                                                                <input type="hidden" class="row-id" value="<?php echo $response['uniqid']; ?>">


                                                            </div>
                                                        </td>
                                                        <td>    
                                                        <?php $modal_id = "modal_" . $response["uniqid"]; ?> 
                                                                <div class='dropdown'>
                                                                        <button class='btn dropdown-toggle' type='button' id='dropdownMenuButton' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>&#8230;</button>
                                                                        <div class='dropdown-menu' aria-labelledby='dropdownMenuButton'>
                                                                            <a class='dropdown-item' href='javascript:void(0)' data-bs-toggle="modal" data-bs-target="#<?php echo $modal_id; ?>">View</a>
                                                                            
                                                                            <a class='dropdown-item' onclick="copyLink(this)" href="javascript:void(0)" data-link='<?php echo base_url().'qoute?'.$response["uniqid"]; ?>' id="copyLink">Copy Link</a>     
                                                                       
                                                                            <a class='dropdown-item ProposalDelete' id='<?php echo $response["uniqid"]; ?>' href='javascript:void(0)'>Delete</a>
                                                                        </div>
                                                                    </div>
                                                               
                                                                <div class="modal fade" id="<?php echo $modal_id; ?>" data_modal_id="<?php echo $modal_id; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                                    <div class="modal-dialog modal-dialog-centered">
                                                                        <div class="modal-content">
                                                                            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                                                                <li class="nav-item" role="presentation">
                                                                                    <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-home_<?php echo $modal_id; ?>" type="button" role="tab" aria-controls="pills-home"
                                                                                        aria-selected="true">Summary</button>
                                                                                </li>
                                                                                <li class="nav-item" role="presentation">
                                                                                    
                                                                                    <button class="nav-link modal_class_response" id="pills-profile-tab" data-bs-toggle="pill"
                                                                                        data-bs-target="#pills-profile_<?php echo $modal_id; ?>" type="button" role="tab" aria-controls="pills-profile"
                                                                                        aria-selected="false" data-dynamic-value="<?php echo $response["uniqid"]; ?>">Selected review</button>
                                                                                    
                                                                                </li>

                                                                            </ul>
                                                                            <div class="tab-content pb-3" id="pills-tabContent">
                                                                                <div class="tab-pane fade show active" id="pills-home_<?php echo $modal_id; ?>" role="tabpanel" aria-labelledby="pills-home-tab"
                                                                                    tabindex="0">
                                                                                    <div class="title mb-3">
                                                                                        <h6><?php echo $company_info['name']; ?></h6>
                                                                                    </div>
                                                                                    <div class="d-flex address">
                                                                                        <img src="../assets/img/Maps and Flags.png" alt="">
                                                                                        <p class="ps-2 mb-0"><?php echo $company_info['formatted_address']; ?></p>
                                                                                    </div>
                                                                                    <div class="d-flex align-items-center justify-content-start mb-3">
                                                                                        <p class="mb-0"><?php echo $company_info['rating']; ?>/5</p>
                                                                                        <span class="px-3 border-right">
                                                                                            <!-- <svg xmlns="http://www.w3.org/2000/svg" width="36" height="41" viewBox="0 0 36 41"
                                                                                                fill="none">
                                                                                                <path
                                                                                                    d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                    fill="#FED156" />
                                                                                                <mask id="mask0_174_3041" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
                                                                                                    width="24" height="41">
                                                                                                    <rect x="0.76001" width="22.4255" height="40.0455" fill="white" />
                                                                                                </mask>
                                                                                                <g mask="url(#mask0_174_3041)">
                                                                                                    <path
                                                                                                        d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                        fill="#E2E2E2" />
                                                                                                </g>
                                                                                            </svg>
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                fill="none">
                                                                                                <path
                                                                                                    d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                    fill="#FED156" />
                                                                                            </svg>
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                fill="none">
                                                                                                <path
                                                                                                    d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                    fill="#FED156" />
                                                                                            </svg>
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                fill="none">
                                                                                                <path
                                                                                                    d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                    fill="#FED156" />
                                                                                            </svg> 
                                                                                           
                                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                                                                                fill="none">
                                                                                                <path
                                                                                                    d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z"
                                                                                                    fill="#FED156" />
                                                                                            </svg>
                                                                                            -->
                                                                                            <?php 
                                                                                                $rating = $company_info['rating'];
                                                                                                $integer_part = floor($rating); // Get the integer part of the rating
                                                                                                $fractional_part = $rating - $integer_part; // Get the fractional part of the rating
                                                                                                if ($fractional_part > 0) {
                                                                                                    // Display partially filled star icon
                                                                                                    ?>
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="41" viewBox="0 0 36 41"
                                                                                                        fill="none">
                                                                                                        <path
                                                                                                            d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                            fill="#FED156" />
                                                                                                        <mask id="mask0_174_3041" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
                                                                                                            width="24" height="41">
                                                                                                            <rect x="0.76001" width="22.4255" height="40.0455" fill="white" />
                                                                                                        </mask>
                                                                                                        <g mask="url(#mask0_174_3041)">
                                                                                                            <path
                                                                                                                d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                                                                                fill="#E2E2E2" />
                                                                                                        </g>
                                                                                                    </svg>
                                                                                                    <?php
                                                                                                }

                                                                                                for ($i = 0; $i < $integer_part; $i++) {
                                                                                                    // Display filled star icon
                                                                                                    ?>
                                                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                                                                                                        <path d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z" fill="#FED156" />
                                                                                                    </svg>
                                                                                                    <?php
                                                                                                }

                                                                                                
                                                                                            ?>

                                                                                        </span>
                                                                                        <p class="mb-0 px-3"><?php echo $company_info['user_ratings_total']; ?> Reviews</p>
                                                                                    </div>
                                                                                    <div class="amt_para">
                                                                                        <p>Selected reviews for proposals</p>
                                                                                    </div>
                                                                                    <div class="amt">
                                                                                        <span class="pe-2"><?php echo $response['num_occurrences'];?></span>
                                                                                        <span class="px-2">x</span>
                                                                                        <span class="px-2"><?php echo $response['review_rate'];?></span>
                                                                                        <span class="px-2">=</span>
                                                                                        <span class="px-2"><?php echo $response['num_occurrences'] * $response['review_rate'];?></span>
                                                                                    </div>
                                                                                </div>
                                                                                
                                                                                <div class="tab-pane fade pills-profile" id="pills-profile_<?php echo $modal_id; ?>" role="tabpanel" aria-labelledby="pills-profile-tab"
                                                                                    tabindex="0">
                                                                                    <!-- <div class="model_review_box d-flex align-items-center justify-content-between">
                                                                                        <div class="d-flex align-items-center model_inner">
                                                                                            <img src="../assets/img/Pexels Photo by Andrea Piacquadio.png" alt="">
                                                                                            <h6 class="m-0 ps-2">Brokin Saiman</h6>
                                                                                        </div>
                                                                                        <div class="model_date">
                                                                                            <p class="m-0">01/02/2022</p>
                                                                                        </div>
                                                                                        <div>
                                                                                            <span>
                                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15" viewBox="0 0 16 15"
                                                                                                    fill="none">
                                                                                                    <path
                                                                                                        d="M8 0L9.79611 5.52786H15.6085L10.9062 8.94427L12.7023 14.4721L8 11.0557L3.29772 14.4721L5.09383 8.94427L0.391548 5.52786H6.20389L8 0Z"
                                                                                                        fill="#FED156" />
                                                                                                </svg>
                                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15" viewBox="0 0 16 15"
                                                                                                    fill="none">
                                                                                                    <path
                                                                                                        d="M8 0L9.79611 5.52786H15.6085L10.9062 8.94427L12.7023 14.4721L8 11.0557L3.29772 14.4721L5.09383 8.94427L0.391548 5.52786H6.20389L8 0Z"
                                                                                                        fill="#FED156" />
                                                                                                </svg>
                                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15" viewBox="0 0 16 15"
                                                                                                    fill="none">
                                                                                                    <path
                                                                                                        d="M8 0L9.79611 5.52786H15.6085L10.9062 8.94427L12.7023 14.4721L8 11.0557L3.29772 14.4721L5.09383 8.94427L0.391548 5.52786H6.20389L8 0Z"
                                                                                                        fill="#FED156" />
                                                                                                </svg>
                                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15" viewBox="0 0 16 15"
                                                                                                    fill="none">
                                                                                                    <path
                                                                                                        d="M8 0L9.79611 5.52786H15.6085L10.9062 8.94427L12.7023 14.4721L8 11.0557L3.29772 14.4721L5.09383 8.94427L0.391548 5.52786H6.20389L8 0Z"
                                                                                                        fill="#FED156" />
                                                                                                </svg>
                                                                                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15" viewBox="0 0 16 15"
                                                                                                    fill="none">
                                                                                                    <path
                                                                                                        d="M8 0L9.79611 5.52786H15.6085L10.9062 8.94427L12.7023 14.4721L8 11.0557L3.29772 14.4721L5.09383 8.94427L0.391548 5.52786H6.20389L8 0Z"
                                                                                                        fill="#FED156" />
                                                                                                </svg>
                                                                                            </span>
                                                                                        </div>
                                                                                    </div> -->

                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                        </td>
                                                        
                                                    </tr>
                                                    <?php
                                                        }
                                                    }else{
                                                        echo '<tr>

                                                            <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                        </tr>';
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                <!-- PROPOSALS END -->
      </div>
   </div>
</div>

    
<?php 
    include('../includes/footer.php');
?>
<script src="../assets/js/gr.js?ver=<?php echo rand(); ?>"></script>
<script src="../assets/js/proposal.js?ver=<?php echo rand(); ?>"></script>
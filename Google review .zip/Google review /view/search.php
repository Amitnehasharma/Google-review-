<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
   header("Location: login.php");
   exit();
}
include('../includes/header.php');
include('../includes/sidebar.php');
?>

<div class="content-main-section left">
   <div class="container showdiv studentdetail">
      <div class="tab-content" id="v-pills-tabContent">
         <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab" tabindex="0">
            <?php echo headerHtml('Search'); ?>
            <div class="search-section">
               <div class="container-fluid">
                  <div class="row Me_padding-search">
                     <div class="col-lg-9">
                        <div>
                           <input type="search" class="w-100 Me_search_inp" id="search_company_input" placeholder="Type company name">
                           <p id="search_company_input_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;">Company name is required</p>
                        </div>
                     </div>
                     <div class="col-lg-3">
                        <div>
                           <button class="w-100 Me_search_btn" id="search_company"> Search <img
                                 src="../assets/img/LoupeWhite.svg" alt=""></button>
                        </div>
                     </div>
                  </div>

                  <div class="row mb-3 mx-0" bis_skin_checked="1">
                     <div class="col-lg-9" id="search_result">
                     </div>
                     <div class="col-lg-3 pe-0" id="search_company_bio">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

<?php
include('../includes/footer_new.php');
?>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-dateFormat/1.0/jquery.dateFormat.min.js?ver=<?php echo rand(); ?>"></script>
   <script src="../assets/js/search.js?ver=<?php echo rand(); ?>"></script>
</body>
</html>
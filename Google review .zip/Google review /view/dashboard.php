<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
///include('../config/connection.php');
include('../controllers/Dashboard.php');
$oj   = new Dashboard();
$proposal_data  =  $oj->getCurrentProposal();
$response_data  =  $oj->getCurrentResponse();
$getActiveJob   =  $oj->getActiveJob();
$getCompletedJob   =  $oj->getCompletedJob();
$current_week = $getCompletedJob['current_week'];
$last_week    = $getCompletedJob['last_week'];
$last_month   = $getCompletedJob['last_month'];
$last_year    = $getCompletedJob['last_year'];

$conversion_data = $oj->getCurrentConversion();
include('../includes/header.php');
include('../includes/sidebar.php');




?>
 <div class="content-main-section left">
    <div class="container showdiv studentdetail">
        <div class="tab-content" id="v-pills-tabContent">

            <div class="tab-pane fade show active" id="v-pills-dashboard" role="tabpanel"
                aria-labelledby="v-pills-dashboard-tab" tabindex="0">

                <?php echo headerHtml('Dashboard'); ?>
                <div class="pt-2">
                    <div class="container">
                        <div class="row  Me_padding-2">
                            <div class="col-lg-6">
                                <div class="row">
                                    <div class="dash-inner-title">
                                        <h6>Conversion</h6>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <div class="dash-inner-box">
                                            <p class="mb-2">Today</p>
                                            <h6><span class="pe-3"><?php echo $conversion_data['today_conversion']; ?></span><span class="ps-1">$<?php echo $conversion_data['today_review_rate_total']; ?></span></h6>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="dash-inner-box">
                                            <p class="mb-2">This week</p>
                                            <h6><span class="pe-3"><?php echo $conversion_data['total_conversion_week']; ?></span><span class="ps-1">$<?php echo $conversion_data['total_week_review_rate_total']; ?></span></h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="dash-inner-box">
                                            <p class="mb-2">This month</p>
                                            <h6><span class="pe-3"><?php echo $conversion_data['current_month_conversion']; ?></span><span class="ps-1">$<?php echo $conversion_data['current_month_review_rate_total']; ?></span></h6>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="dash-inner-box">
                                            <p class="mb-2">This year</p>
                                            <h6><span class="pe-3"><?php echo $conversion_data['current_year_conversion']; ?></span><span class="ps-1">$<?php echo $conversion_data['current_year_review_rate_total']; ?></span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="row">
                                    <div class="col-6">
                                        <div class="dash-inner-title">
                                            <h6>Responses</h6>
                                        </div>
                                        <div class="res_prop">
                                            <div class="d-flex justify-content-around Me_boder pb-3">
                                                <div class="">
                                                    <p>Today</p>
                                                    <h6><?php echo $response_data['today_response']?></h6>
                                                </div>
                                                <div>
                                                    <p>This week</p>
                                                    <h6><?php echo $response_data['total_response_week']?></h6>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-around pt-3">
                                                <div>
                                                    <p>This month</p>
                                                    <h6><?php echo $response_data['current_month_response']?></h6>
                                                </div>
                                                <div>
                                                    <p>This year</p>
                                                    <h6><?php echo $response_data['current_year']?></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="dash-inner-title">
                                            <h6>Proposals</h6>
                                        </div>
                                        <div class="res_prop">
                                            <div class="d-flex justify-content-around Me_boder pb-3">
                                                <div class="">
                                                    <p>Today</p>
                                                    <h6><?php echo $proposal_data['today_proposal']; ?></h6>
                                                </div>
                                                <div>
                                                    <p>This week</p>
                                                    <h6><?php echo $proposal_data['total_proposal_week']; ?></h6>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-around pt-3">
                                                <div>
                                                    <p>This month</p>
                                                    <h6><?php echo $proposal_data['current_month_proposal']; ?></h6>
                                                </div>
                                                <div>
                                                    <p>This year</p>
                                                    <h6><?php echo $proposal_data['current_year']; ?></h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="active-complete-job p-x-12">
                        <div class="container-fluid">
                            <div class="row justify-content-center">
                                <div class="row Me_padding align-items-center">
                                    <div class="col-lg-6 ps-0">
                                        <div>
                                            <h6 class="m-0">Active Jobs</h6>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 px-0">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="text-lg-end marin-right">
                                                <input class="Me-search Me_search_width" type="search"
                                                    placeholder="Search client"></input>
                                                <img class="Me_Btn active search" src="../assets/img/LoupeWhite.svg"></img>
                                            </div>
                                            <div class="text-lg-end">
                                                <!-- <button class="Me_Btn non-active view_all">View all</button> -->
                                                <a class="Me_Btn non-active view_all" href="<?php echo base_url().'view/active-jobs.php'?> ">View all</a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="row table_padd">
                                    <table class="table">
                                        <thead>
                                            <tr class="Me_table-Head">
                                                <th class="Me_table-Head" scope="col">List</th>
                                                <th scope="col">Client</th>
                                                <th scope="col">Approval date</th>
                                                <th scope="col">Review to delete</th>
                                                <th scope="col">Deleted</th>
                                                <th scope="col">Not possible</th>
                                                <th scope="col">Pending</th>
                                                <th scope="col">Value($)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $total_reveiw_to_delete=0;
                                            $total_delete=0;
                                            $total_not_possible=0;
                                            $total_pending=0;
                                            $total_value=0;
                                            if(count($getActiveJob)>0){
                                             foreach ($getActiveJob as $key => $getActiveJobs) {
                                                $total_reveiw_to_delete  += $getActiveJobs['reviewtodelete'];
                                                $total_delete  += $getActiveJobs['deleted'];
                                                $total_not_possible += $getActiveJobs['not_possible'];
                                                $total_pending  += $getActiveJobs['pending'];
                                                $total_value  += $getActiveJobs['value'];
                                                ?>
                                                <tr>
                                                    <th scope="row"><?php echo ($key+1)?></th>
                                                    <td><?php echo $getActiveJobs['company_name']; ?></td>
                                                    <td><?php echo $getActiveJobs['approval_date']; ?></td>
                                                    <td><?php echo $getActiveJobs['reviewtodelete']; ?></td>
                                                    <td><?php echo $getActiveJobs['deleted']; ?></td>
                                                    <td><?php echo $getActiveJobs['not_possible']; ?></td>
                                                    <td><?php echo $getActiveJobs['pending']; ?></td>
                                                    <td><?php echo '$'.$getActiveJobs['value']; ?></td>
                                                </tr>
                                           <?php  } } else {?>
                                                    <tr>

                                                        <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                    </tr>
                                                    <?php } ?>
                                           
                                        </tbody>
                                        <tr class="total_color">
                                            <td></td>
                                            <td>Total</td>
                                            <td></td>
                                            <td><?php echo $total_reveiw_to_delete;?></td>
                                            <td><?php echo $total_delete;?></td>
                                            <td><?php echo $total_not_possible;?></td>
                                            <td><?php echo $total_pending;?></td>
                                            <td>$<?php echo $total_value;?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="active-complete-job p-x-12">
                        <div class="container-fluid">
                            <div class="row justify-content-center">
                                <div class="row px-0">
                                    <div class="p-0">
                                        <h6 class="m-0">Completed jobs</h6>
                                    </div>
                                </div>
                                <div class="row Me_padding ">
                                    <div class="col-lg-6 ps-0 proposals_btn">
                                         
                                            <ul class="nav nav-pills" id="pills-tab" role="tablist">
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link active my-0" id="pills-current_week-tab"
                                                        data-bs-toggle="pill" data-bs-target="#pills-current_week" type="button"
                                                        role="tab" aria-controls="pills-current_week"
                                                        aria-selected="true">Current week</button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link my-0" id="pills-last_week-tab"
                                                        data-bs-toggle="pill" data-bs-target="#pills-last_week" type="button"
                                                        role="tab" aria-controls="pills-last_week"
                                                        aria-selected="false">Last week</button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link my-0" id="pills-last_month-tab"
                                                        data-bs-toggle="pill" data-bs-target="#pills-last_month" type="button"
                                                        role="tab" aria-controls="pills-last_month"
                                                        aria-selected="false">Last month</button>
                                                </li>
                                                <li class="nav-item" role="presentation">
                                                    <button class="nav-link my-0" id="pills-last_year-tab"
                                                        data-bs-toggle="pill" data-bs-target="#pills-last_year" type="button"
                                                        role="tab" aria-controls="pills-last_year"
                                                        aria-selected="false">Last year</button>
                                                </li>
                                            </ul>
                                    </div>
                                    <div class="col-lg-6 px-0">
                                        <div class="d-flex justify-content-between">
                                            <div class="text-lg-end marin-right">
                                                <input class="Me-search Me_search_width" type="search"
                                                    placeholder="Search client"></input>
                                                <img class="Me_Btn active search" src="../assets/img/LoupeWhite.svg"></img>
                                            </div>
                                            <div class="text-lg-end">
                                                <!-- <button class="Me_Btn non-active view_all">View all</button> -->
                                                <a class="Me_Btn non-active view_all" href="<?php echo base_url().'view/completed-jobs.php'?> ">View all</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-content" id="pills-tabContent">
                                    <div class="tab-pane fade show active mb-6" id="pills-current_week" role="tabpanel"
                                        aria-labelledby="pills-current_week-tab" tabindex="0">
                                        <div class="row table_padd">
                                            <table class="table">
                                                <thead>
                                                    <tr class="Me_table-Head">
                                                        <th class="Me_table-Head" scope="col">List</th>
                                                        <th scope="col">Client</th>
                                                        <th scope="col">Approval date</th>
                                                        <th scope="col">Review to delete</th>
                                                        <th scope="col">Deleted</th>
                                                        <th scope="col">Not possible</th>
                                                        <th scope="col">Pending</th>
                                                        <th scope="col">Value($)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                   <?php
                                                    $total_reveiw_to_delete=0;
                                                    $total_delete=0;
                                                    $total_not_possible=0;
                                                    $total_pending=0;
                                                    $total_value=0;
                                                    if(count($current_week)>0){
                                                    foreach ($current_week as $key => $completeData) {
                                                        $total_reveiw_to_delete  += $completeData['reviewtodelete'];
                                                        $total_delete  += $completeData['deleted'];
                                                        $total_not_possible += $completeData['not_possible'];
                                                        $total_pending  += $completeData['pending'];
                                                        $total_value  += $completeData['value'];
                                                        ?>
                                                        <tr>
                                                            <th scope="row"><?php echo ($key+1)?></th>
                                                            <td><?php echo $completeData['company_name']; ?></td>
                                                            <td><?php echo $completeData['approval_date']; ?></td>
                                                            <td><?php echo $completeData['reviewtodelete']; ?></td>
                                                            <td><?php echo $completeData['deleted']; ?></td>
                                                            <td><?php echo $completeData['not_possible']; ?></td>
                                                            <td><?php echo $completeData['pending']; ?></td>
                                                            <td><?php echo '$'.$completeData['value']; ?></td>
                                                        </tr>
                                                   <?php  } } else {?>
                                                    <tr>

                                                        <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                                <tr class="total_color">
                                                    <td></td>
                                                    <td>Total</td>
                                                    <td></td>
                                                    <td><?php echo $total_reveiw_to_delete;?></td>
                                                    <td><?php echo $total_delete;?></td>
                                                    <td><?php echo $total_not_possible;?></td>
                                                    <td><?php echo $total_pending;?></td>
                                                    <td>$<?php echo $total_value;?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade   mb-6" id="pills-last_week" role="tabpanel"
                                        aria-labelledby="pills-current_week-tab" tabindex="0">
                                        <div class="row table_padd">
                                        <table class="table">
                                                <thead>
                                                    <tr class="Me_table-Head">
                                                        <th class="Me_table-Head" scope="col">List</th>
                                                        <th scope="col">Client</th>
                                                        <th scope="col">Approval date</th>
                                                        <th scope="col">Review to delete</th>
                                                        <th scope="col">Deleted</th>
                                                        <th scope="col">Not possible</th>
                                                        <th scope="col">Pending</th>
                                                        <th scope="col">Value($)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                   <?php
                                                    $total_reveiw_to_delete=0;
                                                    $total_delete=0;
                                                    $total_not_possible=0;
                                                    $total_pending=0;
                                                    $total_value=0;
                                                    if(count($last_week)>0){
                                                    foreach ($last_week as $key => $completeData) {
                                                        $total_reveiw_to_delete  += $completeData['reviewtodelete'];
                                                        $total_delete  += $completeData['deleted'];
                                                        $total_not_possible += $completeData['not_possible'];
                                                        $total_pending  += $completeData['pending'];
                                                        $total_value  += $completeData['value'];
                                                        ?>
                                                        <tr>
                                                            <th scope="row"><?php echo ($key+1)?></th>
                                                            <td><?php echo $completeData['company_name']; ?></td>
                                                            <td><?php echo $completeData['approval_date']; ?></td>
                                                            <td><?php echo $completeData['reviewtodelete']; ?></td>
                                                            <td><?php echo $completeData['deleted']; ?></td>
                                                            <td><?php echo $completeData['not_possible']; ?></td>
                                                            <td><?php echo $completeData['pending']; ?></td>
                                                            <td><?php echo '$'.$completeData['value']; ?></td>
                                                        </tr>
                                                   <?php  } } else {?>
                                                    <tr>

                                                        <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                                <tr class="total_color">
                                                    <td></td>
                                                    <td>Total</td>
                                                    <td></td>
                                                    <td><?php echo $total_reveiw_to_delete;?></td>
                                                    <td><?php echo $total_delete;?></td>
                                                    <td><?php echo $total_not_possible;?></td>
                                                    <td><?php echo $total_pending;?></td>
                                                    <td>$<?php echo $total_value;?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade   mb-6" id="pills-last_month" role="tabpanel"
                                        aria-labelledby="pills-current_week-tab" tabindex="0">
                                        <div class="row table_padd">
                                        <table class="table">
                                                <thead>
                                                    <tr class="Me_table-Head">
                                                        <th class="Me_table-Head" scope="col">List</th>
                                                        <th scope="col">Client</th>
                                                        <th scope="col">Approval date</th>
                                                        <th scope="col">Review to delete</th>
                                                        <th scope="col">Deleted</th>
                                                        <th scope="col">Not possible</th>
                                                        <th scope="col">Pending</th>
                                                        <th scope="col">Value($)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                   <?php
                                                    $total_reveiw_to_delete=0;
                                                    $total_delete=0;
                                                    $total_not_possible=0;
                                                    $total_pending=0;
                                                    $total_value=0;
                                                    if(count($last_month)>0){
                                                    foreach ($last_month as $key => $completeData) {
                                                        $total_reveiw_to_delete  += $completeData['reviewtodelete'];
                                                        $total_delete  += $completeData['deleted'];
                                                        $total_not_possible += $completeData['not_possible'];
                                                        $total_pending  += $completeData['pending'];
                                                        $total_value  += $completeData['value'];
                                                        ?>
                                                        <tr>
                                                            <th scope="row"><?php echo ($key+1)?></th>
                                                            <td><?php echo $completeData['company_name']; ?></td>
                                                            <td><?php echo $completeData['approval_date']; ?></td>
                                                            <td><?php echo $completeData['reviewtodelete']; ?></td>
                                                            <td><?php echo $completeData['deleted']; ?></td>
                                                            <td><?php echo $completeData['not_possible']; ?></td>
                                                            <td><?php echo $completeData['pending']; ?></td>
                                                            <td><?php echo '$'.$completeData['value']; ?></td>
                                                        </tr>
                                                   <?php  } } else {?>
                                                    <tr>

                                                        <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                                <tr class="total_color">
                                                    <td></td>
                                                    <td>Total</td>
                                                    <td></td>
                                                    <td><?php echo $total_reveiw_to_delete;?></td>
                                                    <td><?php echo $total_delete;?></td>
                                                    <td><?php echo $total_not_possible;?></td>
                                                    <td><?php echo $total_pending;?></td>
                                                    <td>$<?php echo $total_value;?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade   mb-6" id="pills-last_year" role="tabpanel"
                                        aria-labelledby="pills-current_week-tab" tabindex="0">
                                        <div class="row table_padd">
                                        <table class="table">
                                                <thead>
                                                    <tr class="Me_table-Head">
                                                        <th class="Me_table-Head" scope="col">List</th>
                                                        <th scope="col">Client</th>
                                                        <th scope="col">Approval date</th>
                                                        <th scope="col">Review to delete</th>
                                                        <th scope="col">Deleted</th>
                                                        <th scope="col">Not possible</th>
                                                        <th scope="col">Pending</th>
                                                        <th scope="col">Value($)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                   <?php
                                                    $total_reveiw_to_delete=0;
                                                    $total_delete=0;
                                                    $total_not_possible=0;
                                                    $total_pending=0;
                                                    $total_value=0;
                                                    if(count($last_year)>0){
                                                    foreach ($last_year as $key => $completeData) {
                                                        $total_reveiw_to_delete  += $completeData['reviewtodelete'];
                                                        $total_delete  += $completeData['deleted'];
                                                        $total_not_possible += $completeData['not_possible'];
                                                        $total_pending  += $completeData['pending'];
                                                        $total_value  += $completeData['value'];
                                                        ?>
                                                        <tr>
                                                            <th scope="row"><?php echo ($key+1)?></th>
                                                            <td><?php echo $completeData['company_name']; ?></td>
                                                            <td><?php echo $completeData['approval_date']; ?></td>
                                                            <td><?php echo $completeData['reviewtodelete']; ?></td>
                                                            <td><?php echo $completeData['deleted']; ?></td>
                                                            <td><?php echo $completeData['not_possible']; ?></td>
                                                            <td><?php echo $completeData['pending']; ?></td>
                                                            <td><?php echo '$'.$completeData['value']; ?></td>
                                                        </tr>
                                                   <?php  } } else {?>
                                                    <tr>

                                                        <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                                <tr class="total_color">
                                                    <td></td>
                                                    <td>Total</td>
                                                    <td></td>
                                                    <td><?php echo $total_reveiw_to_delete;?></td>
                                                    <td><?php echo $total_delete;?></td>
                                                    <td><?php echo $total_not_possible;?></td>
                                                    <td><?php echo $total_pending;?></td>
                                                    <td>$<?php echo $total_value;?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                        
                                
                            </div>
                        </div>
                    </div>

            </div>

            <!-- DASHBOARD END -->


        </div>
    </div>
</div>
<?php 
 include('../includes/footer.php');
?>
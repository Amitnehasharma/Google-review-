<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../includes/header.php');
include('../includes/sidebar.php');


?>
<div class="content-main-section left">
   <div class="container showdiv studentdetail">
      <div class="tab-content" id="v-pills-tabContent">
         <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab"
            tabindex="0">
            <?php echo headerHtml('Reports'); ?>
            
         </div>
      </div>
   </div>
</div>
         
<?php 
include('../includes/footer.php');
?>
<?php
function base_url() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $script = $_SERVER['SCRIPT_NAME'];
    return "$protocol://$host";
}
$postData = file_get_contents('php://input');
$data = json_decode($postData, true);
if ($data['type'] == 'find_company') {
    session_start();
    $apiKey = 'AIzaSyAROdryFjF6uJY-DCFBNX_oryDhJV-mUK0';
    $apiEndpoint = 'https://maps.googleapis.com/maps/api/place/textsearch/json';
    $query = urlencode($data['key']);
    $url = "$apiEndpoint?query=$query&key=$apiKey";

     $response = file_get_contents($url);
    // $_SESSION['response']=$response;

    //print_r($_SESSION['response']);
    if ($response === false) {
        die('Error occurred while fetching data from Google Places API');
    }

    $resonsedata = json_decode($response, true);
    $response = [];
    if(isset($resonsedata['results'])){
        foreach($resonsedata['results'] AS $results){
            $response[] = [
                'place_id' => $results['place_id'],
                'name' => $results['name'],
                'rating' => $results['rating'],
                'user_ratings_total' => $results['user_ratings_total'],
                'business_status' => $results['business_status'],
                'formatted_address' => $results['formatted_address']
            ];
        }
    }
    
    echo json_encode($response);
    // echo '[{"place_id":"ChIJQ_OpdfdT4DsRa_lnzXPmE7A","name":"Resolute Solutions","rating":5,"user_ratings_total":4,"business_status":"OPERATIONAL","formatted_address":"LA-13 to LA-16, Tribhuvan Complex, Ghod Dod Rd, next to Pizza Hut, Surat, Gujarat 395007, India"},{"place_id":"ChIJVWcjl6CVwjsRQLdHDiLuMpE","name":"Resolute Solutions","rating":1,"user_ratings_total":1,"business_status":"OPERATIONAL","formatted_address":"BUILDING-A, Office No 5, First Floor, Off, Maharana Pratap Singh Rd, Vadgaon Budruk, Pune, Maharashtra 411041, India"}]';
}

if ($data['type'] == 'find_review') {

        $apiKey = 'MWNhZDdiNTU1MmM1NDcxOWI0OGJhZGVjODVlZjQ3MmV8MzM3YTYwMzczMw';
        $placeId = $data['place_id'];
        $curl = curl_init();

        $review_pagination_id = $data['review_pagination_id'];
        $link = 'https://api.app.outscraper.com/maps/reviews-v3?query='.$placeId.'&reviewsLimit=100&async=false&sort=lowest_rating';
        if($review_pagination_id != ''){
            $link = 'https://api.app.outscraper.com/maps/reviews-v3?query='.$placeId.'&reviewsLimit=100&async=false&sort=lowest_rating&lastPaginationId='.$review_pagination_id;
        }

        curl_setopt_array($curl, array(
        CURLOPT_URL => $link,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        CURLOPT_HTTPHEADER => array(
            'X-API-KEY: MWNhZDdiNTU1MmM1NDcxOWI0OGJhZGVjODVlZjQ3MmV8MzM3YTYwMzczMw'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        echo $response;

        // echo '{"id":"a-866b9516-2f9d-462f-b926-c4258b96acc4","status":"Success","data":[{"query":"ChIJQ_OpdfdT4DsRa_lnzXPmE7A","name":"Resolute Solutions","place_id":"ChIJQ_OpdfdT4DsRa_lnzXPmE7A","google_id":"0x3be053f775a9f343:0xb013e673cd67f96b","full_address":"LA-13 to LA-16, Tribhuvan Complex, Ghod Dod Rd, next to Pizza Hut, Surat, Gujarat 395007, India","borough":"Athwa","street":"LA-13 to LA-16, Tribhuvan Complex, Ghod Dod Rd, next to Pizza Hut","postal_code":"395007","area_service":false,"country_code":"IN","country":"India","city":"Surat","us_state":null,"state":"Gujarat","plus_code":"7JHJ5QGX+2G","latitude":21.175098,"longitude":72.7987508,"time_zone":"Asia/Calcutta","popular_times":null,"site":"https://www.resolutesolutions.in/","phone":"+91 82383 91804","type":"Corporate office","logo":null,"description":null,"typical_time_spent":null,"located_in":null,"located_google_id":null,"category":"Corporate office","subtypes":"Corporate office","posts":null,"reviews_tags":null,"rating":5,"reviews":4,"reviews_data":[{"review_id":"ChZDSUhNMG9nS0VJQ0FnSURLMU5XV1JBEAE","review_pagination_id":"CAESBkVnSUlBUQ==","author_link":"https://www.google.com/maps/contrib/106846529966932339608?hl=en-US","author_title":"Zaki Pathan","author_id":"106846529966932339608","author_image":"https://lh3.googleusercontent.com/a/ACg8ocLY8p2zOmh6mID0e6oCGWiHn8gudGBjNA1u7GHgGk7H=s120-c-rp-mo-br100","author_reviews_count":2,"author_ratings_count":2,"review_text":"I have been working as a android and react native developer in this company for the last 4+ years. I only have 1 year of experience in android when I joined here but this company gave me the opportunity to learn react native along with the job which has added one more skill to my bucket. Team management is very helpful and understanding. I enjoyed working with them.","review_img_url":null,"review_img_urls":null,"review_questions":null,"review_photo_ids":null,"owner_answer":null,"owner_answer_timestamp":null,"owner_answer_timestamp_datetime_utc":null,"review_link":"https://www.google.com/maps/reviews/data=!4m8!14m7!1m6!2m5!1sChZDSUhNMG9nS0VJQ0FnSURLMU5XV1JBEAE!2m1!1s0x0:0xb013e673cd67f96b!3m1!1s2@1:CIHM0ogKEICAgIDK1NWWRA%7CCgsI0821hAYQoIzRcg%7C?hl=en-US","review_rating":5,"review_timestamp":1619879635,"review_datetime_utc":"05/01/2021 14:33:55","review_likes":0}],"photos_count":1,"cid":"12687737960274590059","reviews_link":"https://search.google.com/local/reviews?placeid=ChIJQ_OpdfdT4DsRa_lnzXPmE7A&authuser=0&hl=en&gl=US","reviews_id":"-5759006113434961557","photo":"https://streetviewpixels-pa.googleapis.com/v1/thumbnail?panoid=wIBU97Fso9Cn64TGqBhp-w&cb_client=search.gws-prod.gps&w=800&h=500&yaw=58.48818&pitch=0&thumbfov=100","street_view":"https://streetviewpixels-pa.googleapis.com/v1/thumbnail?panoid=wIBU97Fso9Cn64TGqBhp-w&cb_client=search.gws-prod.gps&w=1600&h=1000&yaw=58.48818&pitch=0&thumbfov=100","working_hours_old_format":"Monday:10AM-7PM|Tuesday:10AM-7PM|Wednesday:10AM-7PM|Thursday:10AM-7PM|Friday:10AM-7PM|Saturday:10AM-5PM|Sunday:Closed","working_hours":{"Monday":"10AM-7PM","Tuesday":"10AM-7PM","Wednesday":"10AM-7PM","Thursday":"10AM-7PM","Friday":"10AM-7PM","Saturday":"10AM-5PM","Sunday":"Closed"},"other_hours":null,"business_status":"OPERATIONAL","about":{},"range":null,"reviews_per_score":{"1":0,"2":0,"3":0,"4":0,"5":4},"reservation_links":null,"booking_appointment_link":null,"menu_link":null,"order_links":null,"owner_id":null,"verified":false,"owner_title":"Resolute Solutions","owner_link":null,"location_link":"https://www.google.com/maps/place/Resolute+Solutions/@21.175098,72.7987508,14z/data=!4m8!1m2!2m1!1sResolute+Solutions!3m4!1s0x3be053f775a9f343:0xb013e673cd67f96b!8m2!3d21.175098!4d72.7987508","location_reviews_link":"https://www.google.com/maps/place/Resolute+Solutions/@21.175098,72.7987508,13.99z/data=!4m16!1m7!3m6!1s0x3be053f775a9f343:0xb013e673cd67f96b!2sResolute+Solutions!8m2!3d21.175098!4d72.7987508!16s%2Fg%2F11ckvg1dmb!3m7!1s0x3be053f775a9f343:0xb013e673cd67f96b!8m2!3d21.175098!4d72.7987508!9m1!1b1!16s%2Fg%2F11ckvg1dmb?entry=ttu"}]}';
}

if ($data['type'] == 'find_review_for_new_quote') {
    session_start();
    $apiKey = 'AIzaSyAROdryFjF6uJY-DCFBNX_oryDhJV-mUK0';

    $apiEndpoint = 'https://maps.googleapis.com/maps/api/place/details/json';
    $place_id = $data['place_id'];
    $url = "$apiEndpoint?place_id=$place_id&key=$apiKey";

    $response = file_get_contents($url);
    // $_SESSION['response']=$response;

    //print_r($_SESSION['response']);
    if ($response === false) {
        die('Error occurred while fetching data from Google Places API');
    }

    $resonsedata = json_decode($response, true);
    
    $response = [];
    if(isset($resonsedata['result'])){
        // Assuming 'result' is an array of a single place detail, not an array of multiple results
        $result = $resonsedata['result'];
    
        // Extract details from the result
        $response = [
            'place_id' => $result['place_id'],
            'name' => $result['name'],
            'rating' => isset($result['rating']) ? $result['rating'] : null,
            'user_ratings_total' => isset($result['user_ratings_total']) ? $result['user_ratings_total'] : null,
            'business_status' => isset($result['business_status']) ? $result['business_status'] : null,
            'formatted_address' => isset($result['formatted_address']) ? $result['formatted_address'] : null
        ];
    }
    
    echo json_encode($response);
    // echo '[{"place_id":"ChIJQ_OpdfdT4DsRa_lnzXPmE7A","name":"Resolute Solutions","rating":5,"user_ratings_total":4,"business_status":"OPERATIONAL","formatted_address":"LA-13 to LA-16, Tribhuvan Complex, Ghod Dod Rd, next to Pizza Hut, Surat, Gujarat 395007, India"},{"place_id":"ChIJVWcjl6CVwjsRQLdHDiLuMpE","name":"Resolute Solutions","rating":1,"user_ratings_total":1,"business_status":"OPERATIONAL","formatted_address":"BUILDING-A, Office No 5, First Floor, Off, Maharana Pratap Singh Rd, Vadgaon Budruk, Pune, Maharashtra 411041, India"}]';
}
if ($data['type'] == 'send_qoute') {
    // error_reporting(E_ALL);
    // ini_set('display_errors', 1);
    // session_start();
    include('../../controllers/Quotes.php');
    $place_id = $data['place_id'];
    $per_review_amount = serialize($data['per_review_amount']);
    $email_id = $data['email_id'];
    $offer_expire = $data['offer_expire'];
    $serialNumber = 1;
    foreach ($data['company_reviews'] as &$element) {
        $element['sr_number'] = $serialNumber++;
    }
    //$company_reviews = json_encode($data['company_reviews']);
    $company_reviews = serialize($data['company_reviews']);
    $company_info = serialize($data['company_info']);
    

    $Quotes_obj  = new Quotes();
    $response = $Quotes_obj->Create($place_id, $per_review_amount, $email_id,$offer_expire, $company_reviews, $company_info);
    $responseArray= json_decode($response);

    $message = "<div class='container'>
            <p>Dear User,<br /><br />
            I'm Rinku from GR Deletion, seeking a quote for a review deletion strategy.
            Your expertise caught our attention.
            Kindly provide a detailed quote via our Quote Review link: <a href='".base_url()."/qoute/?".$responseArray->uniqid."'>Learn More</a>.
            Confidentiality is key.
            <br /><br />Thanks!</p>
        </div>
    </html>";

    require_once('PHPMailer/PHPMailerAutoload.php');
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.zoho.com';
    $mail->SMTPAuth = true;       
    $mail->Username = 'rinku@resolutesolutions.in';
    $mail->Password = 'Mayra@2021#';
    $mail->SMTPSecure = 'ssl';      
    $mail->Port = 465;
    $mail->setFrom('rinku@resolutesolutions.in', 'GR Deletion');
    $mail->addReplyTo('rinku@resolutesolutions.in', 'GR Deletion');
    $mail->addAddress($email_id);
    $mail->isHTML(true);

    $mail->Subject = 'Quote Request - Review Deletion';
    $mail->Body = $message;
    if ($mail->send()) {
         //echo 'Email sent successfully';
    } else {
         //echo 'Error: ' . $mail->ErrorInfo;
    }
    echo $response;
}
if ($data['type'] == 'copy_qoute') {

    // error_reporting(E_ALL);
    // ini_set('display_errors', 1);
    // session_start();
    include('../../controllers/Quotes.php');
    
    $place_id = $data['place_id'];
    $per_review_amount = serialize($data['per_review_amount']);

    $email_id = $data['email_id'];
    $offer_expire = $data['offer_expire'];

    $serialNumber = 1;
    foreach ($data['company_reviews'] as &$element) {
        $element['sr_number'] = $serialNumber++;
    }
    $company_reviews = serialize($data['company_reviews']);
    $company_info = serialize($data['company_info']);
    

    $Quotes_obj  = new Quotes();
    $response = $Quotes_obj->Create($place_id, $per_review_amount, $email_id,$offer_expire, $company_reviews, $company_info);
    $responseArray= json_decode($response);
    $message = "<div class='container'>
            <p>Dear User,<br /><br />
            I'm Rinku from GR Deletion, seeking a quote for a review deletion strategy.
            Your expertise caught our attention.
            Kindly provide a detailed quote via our Quote Review link: <a href='".base_url()."/qoute/?".$responseArray->uniqid."'>Learn More</a>.
            Confidentiality is key.
            <br /><br />Thanks!</p>
        </div>
    </html>";

    // require_once('PHPMailer/PHPMailerAutoload.php');
    // $mail = new PHPMailer;
    // $mail->isSMTP();
    // $mail->Host = 'smtp.zoho.com';
    // $mail->SMTPAuth = true;       
    // $mail->Username = 'rinku@resolutesolutions.in';
    // $mail->Password = 'Mayra@2021#';
    // $mail->SMTPSecure = 'ssl';      
    // $mail->Port = 465;
    // $mail->setFrom('rinku@resolutesolutions.in', 'GR Deletion');
    // $mail->addReplyTo('rinku@resolutesolutions.in', 'GR Deletion');
    // $mail->addAddress($email_id);
    // $mail->isHTML(true);

    // $mail->Subject = 'Quote Request - Review Deletion';
    // $mail->Body = $message;
    // if ($mail->send()) {
    //     // echo 'Email sent successfully';
    // } else {
    //     // echo 'Error: ' . $mail->ErrorInfo;
    // }
    echo base_url()."/qoute/?".$responseArray->uniqid;
}
?>
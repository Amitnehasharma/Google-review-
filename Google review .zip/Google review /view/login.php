<?php
session_start(); // Start the session
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
        // Include database connection file
        include('../config/connection.php');

        // Get input data from the login form
        $email = $_POST["email"];
        $password = $_POST["password"];
        
        $sql = "SELECT *  FROM users WHERE email = '$email' and is_deleted=0";
        $result = $conn->query($sql);

        

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            // echo '<pre>';
            // print_r($row);
            // print_r(md5($password));
            // echo '</pre>';
            // die;

            if (md5($password) === $row['password']) {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['full_name'] = $row['full_name'];
                $_SESSION['profile_pic'] = $row['profile_pic'];

                if(!empty($_POST["remember"])) {
                    setcookie ("user_login",$_POST["email"],time()+ (10 * 365 * 24 * 60 * 60));
                    setcookie ("userpassword",$_POST["password"],time()+ (10 * 365 * 24 * 60 * 60));
                    setcookie ("rememberMe",$_POST["remember"],time()+ (10 * 365 * 24 * 60 * 60));
                }else{
                    
                    if(isset($_COOKIE["user_login"])) {
                        setcookie ("user_login","");
                    }
                    if(isset($_COOKIE["userpassword"])) {
                        setcookie ("userpassword","");               
                    }
                    if(isset($_COOKIE["userpassword"])) {
                        setcookie ("rememberMe","");               
                    }          
                }

                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Invalid  password ";
            }
        } else {
            $error = "Invalid email  ";
        }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- <link href="https://fonts.googleapis.com/css2?family=Red+Hat+Text:wght@500;600;700&display=swap" rel="stylesheet"> -->
    <link href='https://fonts.googleapis.com/css?family=Inter:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/style.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/scss/main.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/login.css?ver=<?php echo rand(); ?>">
</head>

<body>
    <div class="login-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="left">
                        <div class="brand-title p-0">
                            <a class="d-inline-flex align-items-center cursor-pointer" href="/">
                                <img class="img-fluid Feedback px-1" src="../assets/img/logo.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mobile-d-none">
                    <div class="left">
                        <div class="rating-img-box login-banner">
                            <img src="../assets/img/login-banner.png" alt="">
                        </div>
                        
                    </div>
                </div>
                <div class="col-md-6 col-lg-5">
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data" onsubmit="return validateLoginForm()" id='loginForm'>
                        <div class="right">
                            <div class="login_title text-center">
                                <h3 class='login-welcome-text'>Wilkommen bei  </h3>
                                <h3 class='login-welcome-text txt-bold-600 mb-3'>Sternehero</h3>
                                <div class="rating-img-box login-banner">
                                    <img src="../assets/img/custom-login-Icon.png" alt="">
                                </div>
                                <h1 class='login-welcome-login mt-2 mb-4'>Login to </h1>
                            </div>
                            <?php if (isset($error)) { echo "<p class='text-center text-danger'>$error</p>"; } ?>
                            <div class="mb-3 login_title email">
                                <label for="email" class="form-label mb-2 ">Email Address <sup>*</sup> </label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <div class="input-group-text"><img src="../assets/img/Email.png" alt="Lock Icon" class=""></div>
                                    </div>
                                    <input type="email" class="form-control email"  value="<?php if(isset($_COOKIE["user_login"])) { echo $_COOKIE["user_login"]; } ?>" name="email" id="email"
                                    placeholder="demo123123@gamil.com">
                                </div>
                            </div>
                            <span id="usernameError" style="color: red;"></span>
                            <div class="mb-3 login_title">
                                <label for="password" class="form-label mb-2 ">Password <sup>*</sup></label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                      <div class="input-group-text"><img src="../assets/img/Secured lock.png" onclick="togglePasswordVisibility()" alt="Lock Icon"></div>
                                    </div>
                                    <input type="password" value="<?php if(isset($_COOKIE["userpassword"])) { echo $_COOKIE["userpassword"]; } ?>" class="form-control password" name="password" id="password"
                                    placeholder="********">
                                </div>
                               
                                
                            </div>
                            <span id="passwordError" style="color: red;"></span>
                            <div class="mb-3 mt-3 login_title password">
                                <input class="remember_inp form-check-input checkbox" <?php if(isset($_COOKIE["rememberMe"])) { echo 'checked'; } ?> name="remember" id="rememberme" type="checkbox">
                                <label for="rememberme">Login speichern</label>
                            </div>
                            <div class="mb-3 mt-4 login_title">
                                <button type="submit" name="submit">Log In </button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js?ver=<?php echo rand(); ?>"></script>
    <script src="../assets/js/gr.js?ver=<?php echo rand(); ?>"></script>
    <script src="../assets/js/login.js?ver=<?php echo rand(); ?>"></script>
</body>

</html>
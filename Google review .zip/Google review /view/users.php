<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../controllers/User.php');
include('../includes/header.php');
include('../includes/sidebar.php');

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$tab = isset($_GET['tab']) ? $_GET['tab'] : 1;
$search = isset($_GET['search']) ? $_GET['search'] : '';
$limit = isset($_GET['limit']) ? $_GET['limit'] :10;

$offset = ($page - 1) * $limit;


$user_object  = new User();

$userData  =  $user_object->UserPasination($offset, $limit,$search);

$user_list = $userData['data'];
$totalRow = $userData['totalRow'];


?>

<div class="content-main-section left users-list">
    <div class="container showdiv studentdetail">
        <div class="tab-content" id="v-pills-tabContent">
            <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab" tabindex="0">
                <?php echo headerHtml('Users'); ?>
                <div class="active-complete-job">
                    <div class="container">
                        <div class="row p-3">
                            <!-- <div class="row py-3">
                                <div class="p-0 acive_comp_job_title">
                                    <p class="m-0">Users </p>
                                </div>
                            </div> -->
                            <div class="row Me_padding">
                                <div class="col-lg-2">
                                    <div>
                                        <a href='<?php echo base_url() . 'view/add-user.php'; ?>'><button
                                                class="Me_Btn active">Add User </button></a>
                                        <!-- <button class="Me_Btn non-active">Completed jobs</button> -->
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="text-end">
                                        <input class="Me-search" value='<?php  echo $search; ?>' type="search" id='user-search' placeholder="Search client"></input>
                                        <img  data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>' id="user-search-btn" class="Me_Btn active search" src="../assets/img/Loupe (1).png"></img>
                                        <select  data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>' name="user-limit" id='user-limit' class="filter-list" style="margin: 0;padding: 10px 20px;">
                                            <option value='10' <?php echo  $limit==10?'selected':''; ?>>10</option>
                                            <option value='20' <?php echo  $limit==20?'selected':''; ?>>20</option>
                                            <option value='50' <?php echo $limit==50?'selected':''; ?>>50</option>
                                            <option value='100' <?php echo $limit==100?'selected':''; ?>>100</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="text-end text-lg-end d-flex">
                                       <?php  updatePagination($totalRow, $limit, $page,1,$search); ?>
                                    </div>
                                </div>
                            </div>



                            <div class="row m-auto table_padd">
                                <table class="table" id='userTable'>
                                    <thead>
                                        <tr class="Me_table-Head">
                                            <th class="Me_table-Head" scope="col">Sr. No.</th>
                                            <th scope="col">Name</th>
                                            <th scope="col">Email</th>
                                            <th scope="col">Date Of Birth</th>
                                            <th scope="col">Phone Number</th>
                                            <th scope="col">Create date</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (count($user_list) > 0) {
                                            $index = 0;
                                            foreach ($user_list as $row) {
                                                echo "<tr id='remove-row{$row['uniqid']}'>";
                                                echo "<td scope='row'>" . ($index + 1) . "</td>";
                                                echo "<td>{$row['full_name']}</td>";
                                                echo "<td>{$row['email']}</td>";
                                                echo "<td>{$row['dob']}</td>";
                                                echo "<td>{$row['phone_number']}</td>";
                                                echo "<td>{$row['creation_date']}</td>";
                                                echo "<td>";
                                                echo "<div class='dropdown'>";
                                                echo "<button class='btn dropdown-toggle' type='button' id='dropdownMenuButton' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>&#8230;</button>";
                                                echo "<div class='dropdown-menu' aria-labelledby='dropdownMenuButton'>";
                                                echo "<a class='dropdown-item' href='/view/edit-user.php?id={$row['uniqid']}'>Edit</a>";
                                                echo "<a class='dropdown-item userDelete' id='{$row['uniqid']}' href='javascript:void(0)'>Delete</a>";
                                                echo "</div>";
                                                echo "</div>";
                                                echo "</td>";
                                                echo "</tr>";
                                                $index++;
                                            }
                                        }else{
                                            echo '<tr>

                                                           <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
                                                       </tr>';
                                        }

                                        
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('../includes/footer_new.php');
?>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="../assets/js/user.js?ver=<?php echo rand(); ?>"></script>
<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../includes/header.php');
include('../includes/sidebar.php');
include('../controllers/ProposalResponse.php');

$uniqid = $_GET['uniqid'];

$proposalResponse = new ProposalsResponse();
$quotes = $proposalResponse->FetchQuotes($uniqid);

$trasactions = $proposalResponse->FetchTrasactionEntries($uniqid);

?>

<div class="content-main-section left">
   <div class="container showdiv studentdetail">
      <div class="tab-content" id="v-pills-tabContent">
         <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab"
            tabindex="0">
            <?php echo headerHtml('Submissons'); ?>
            <div class="active-complete-job">
               <div class="container">
                     <div class="row Me_padding-submission align-items-center">
                        <div class="col-lg-10">
                           <div>
                            <?php foreach ($quotes as $quote) { 
                                $company_info = unserialize($quote['company_info']);
                                ?>
                                 <button class="Me_Btn non-active"><?php echo $company_info['name']; ?></button>
                                 <button class="Me_Btn non-active"><img src="../assets/img//Maps and Flags.png"
                                       alt=""><span class="align-middle ps-1"><?php echo substr($company_info['formatted_address'], 0, 50) . '...'; ?></span></button>
                                 <button class="Me_Btn non-active"><span class="align-middle"><?php echo $company_info['rating']; ?>/5</span><span>
                                 <?php 
                                        $rating = $company_info['rating'];
                                        $integer_part = floor($rating); // Get the integer part of the rating
                                        $fractional_part = $rating - $integer_part; // Get the fractional part of the rating

                                        if ($fractional_part > 0) {
                                            // Display partially filled star icon
                                            ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="41" viewBox="0 0 36 41"
                                                fill="none">
                                                <path
                                                    d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                    fill="#FED156" />
                                                <mask id="mask0_174_3041" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0"
                                                    width="24" height="41">
                                                    <rect x="0.76001" width="22.4255" height="40.0455" fill="white" />
                                                </mask>
                                                <g mask="url(#mask0_174_3041)">
                                                    <path
                                                        d="M23.1854 8.00928L26.0624 17.4173H35.3727L27.8405 23.2318L30.7176 32.6399L23.1854 26.8254L15.6532 32.6399L18.5302 23.2318L10.998 17.4173H20.3083L23.1854 8.00928Z"
                                                        fill="#E2E2E2" />
                                                </g>
                                            </svg>
                                            <?php
                                        }

                                        for ($i = 0; $i < $integer_part; $i++) {
                                            // Display filled star icon
                                            ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
                                                <path d="M12.5 0L15.3064 9.32827H24.3882L17.0409 15.0935L19.8473 24.4217L12.5 18.6565L5.15268 24.4217L7.95911 15.0935L0.611794 9.32827H9.69357L12.5 0Z" fill="#FED156" />
                                            </svg>
                                            <?php
                                        }

                                        
                                    ?>
                                    </span></button>
                                <?php } ?>
                           </div>
                        </div>
                        <div class="col-lg-2">
                           <div class="text-end">
                                 <a class="Me_Btn non-active" href="<?php echo base_url(); ?>view/submission.php">Back</a>
                           </div>
                        </div>
                     </div>

                     <div class="row submit-sec px-lg-3">
                        <div class="row submit_main_box m-auto">
                           <div class="col-lg-4">
                                 <div class="row mb-2">
                                    <div class="col-12 px-0">
                                       <?php
                                          if (!empty($trasactions)) {
                                             foreach ($trasactions as $trasaction) {
                                                $selected_reviews = unserialize($trasaction['selected_reviews']);
                                       ?>
                                       <div class="sub_rating_box inner_bottom" id="<?php echo $trasaction['id']; ?>">
                                             <div class="d-flex review_title_inner align-items-center justify-content-between">
                                                <div class="d-flex align-items-center justify-content-start">
                                                <?php if($selected_reviews['profile_photo_url']){ ?>
                                                   <img src="<?php echo $selected_reviews['profile_photo_url']; ?>"
                                                         alt="">
                                                <?php } ?>
                                                   <h6 class="m-0"><?php echo $selected_reviews['authorName']; ?></h6>
                                                </div>
                                                <div>
                                                   <?php echo $selected_reviews['ratingHtml']; ?>
                                                </div>
                                             </div>
                                             <div class="review_timing second py-2">
                                                <b>Date:</b>
                                                <span><?php echo $selected_reviews['formattedDate']; ?></span>
                                                <span><?php echo $selected_reviews['formattedTime']; ?></span>
                                             </div>
                                             <div class="review_para second">
                                                <p class="mb-0"><?php echo $selected_reviews['text'] == 'null'? '' : $selected_reviews['text'];  ?></p>
                                             </div>
                                       </div>
                                       <?php
                                             }
                                          }
                                       ?>
                                    </div>
                                 </div>
                           </div>
                           <div class="col-lg-3">
                                 <div class="row border-right mb-2">
                                    <div class="col-12 px-0 middle_email_inbox">
                                       
                                    </div>
                                 </div>
                           </div>
                           <div class="col-lg-5">
                                 <div class="row sub_right_para">
                                    <div class="col-12 email_body">
                                       <!-- <div>
                                             <h6>Hello,</h6>
                                             <p class="thanks">Thanks for reaching out to us.</p>
                                       </div>
                                       <div>
                                             <p>We have received your request.</p>
                                       </div>
                                       <div>
                                             <div>
                                                <p>We receive many such requests each day; your message is in
                                                   our
                                                   queue, and we'll get to it as quickly as our workload
                                                   permits.
                                                   Due
                                                   to the large volume of requests that we receive, we will
                                                   only be
                                                   able to provide you with a response if we determine your
                                                   request
                                                   may be a valid and actionable legal complaint, and we may
                                                   respond with questions or requests for clarification.</p>
                                             </div>
                                             <div class="mb-5">
                                                <p>For more information on Google's Terms of Service,
                                                   please visit <a href="" class="Me_link">
                                                         http://www.google.com/accounts/TOS</a></p>
                                             </div>
                                             <div>
                                                <p>Regards,</p>
                                             </div>
                                             <div>
                                                <p>The Google Team</p>
                                             </div>
                                       </div> -->
                                    </div>
                                 </div>

                           </div>
                        </div>
                     </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php 
include('../includes/footer.php');
?>
<script src="../assets/js/transactions.js?ver=<?php echo rand(); ?>"></script>
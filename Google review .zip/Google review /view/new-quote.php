<?php
include('../controllers/QuoteView.php');
$keys = array_keys($_GET);
$QuoteView_obj = new QuoteView();
$response = $QuoteView_obj->FetchQuotes($keys[0]);

$uniqid = $response['uniqid'];
$place_id = $response['place_id'];
$per_review_charge = $response['per_review_charge'];
$email = $response['email'];
$company_info = unserialize($response['company_info']);
$status = $response['status'];



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GR Deletion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href='https://fonts.googleapis.com/css?family=Inter:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/style.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/scss/main.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/custom.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/qoute.css?ver=<?php echo rand(); ?>">
    <script> const base_url = 'https://app.sternehero.de'; </script>
    <script> const uniqid = '<?php echo $uniqid; ?>'; </script>
</head>
<body>
<div id='qoute'>
   <div class=" showdiv studentdetail ">
      <header class="header-fix-top-section">
         <div class="container">
            <div class="row align-items-center">
               <div class="col-8">
                  <div class="brand-title" style="margin: 0;">
                     <a class="d-inline-flex align-items-center cursor-pointer" href="/">
                     <img class="img-fluid Feedback px-1" src="../assets/img/logo.png" alt="">
                     </a>
                  </div>
               </div>
               <div class="col-4 ">
                  <div class="calendar-title">
                     <img src="../assets/img/calendar-01.png" class='d-none' alt="">
                     <div class="calendar-inner">
                        <img src="../assets/img/calendar-01.png" alt="">
                        <span>31-01-2024</span>
                     </div>
                     <div class="calendar-inner">
                        <img src="../assets/img/clock-01.png" alt="">
                        <span id="clock">10:23</span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <div class=" container search-section mt-4">
            <div class="container-fluid">
               <div class="row mb-3 mx-0" style="padding: 1vw 0;">
                  <div class="col-lg-9"  >
                     <div class='card customer-list-card'>
                        <div class='top-heading'>
                           <div class='row'>
                              <div class='col-sm-8'>
                                 <h6 id='total-review-count'>0 Bewertungen</h6>
                              </div>
                              <div class='col-sm-4' id='withoutsubmit'>
                                 <div class='w-100'>
                                    <div class="input-group">
                                       <div class="input-group-prepend">
                                          <div class="input-group-text"><img src="../assets/img/search.png" alt="Lock Icon" class=""></div>
                                       </div>
                                       <input type='text' class='form-control customer-search' placeholder='Suchen' >
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class='row d-flex align-items-base'>
                                <div class='col-sm-8'>
                                    <div class='rating-selection' id='filter-review-by-status'>
                                        <div class="rating-filter filter-tab active non-active " id="0">
                                            <span id='all'>Alle</span>
                                        </div>
                                        <div class="rating-filter filter-tab" id="3">
                                            <span id='progress'>0 In Bearbeitung</span>
                                        </div>
                                        <div class="rating-filter filter-tab" id="1">
                                            <span id='deleted'>0 Gelöscht</span>
                                        </div>
                                        <div class="rating-filter filter-tab" id="2">
                                            <span id='failed'>0  Gescheitert</span>
                                        </div>
                                    </div>
                                </div>
                                <div class='col-sm-4'>
                                   <div class="input-group">
                                       <div class="input-group-prepend">
                                          <div class="input-group-text"><img src="../assets/img/search.png" alt="Lock Icon" class=""></div>
                                       </div>
                                       <input type='text' class='form-control customer-search' placeholder='Suchen'>
                                    </div>
                                </div>
                           </div>
                        </div>
                        <div class='rating-selection'  id="filter_by_rating">
                           <div class="rating-filter filter-tab active non-active" id="0">
                               <img class="img-fluid" src="../assets/img/fill-rating.png" alt="">
                              <span id='all'>Alle</span>
                           </div>
                           <div class="rating-filter filter-tab" id="1">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span class='total1Rating'>1 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="2">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span class='total2Rating'>2 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="3">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span class='total3Rating'>3 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="4">
                               <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span id='total4Rating'>4 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="5">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span id='total5Rating'>5 (0)</span>
                           </div>
                        </div>
                        <hr>
                        <div class='dflex-center '>
                           <div class='row p-01'>
                              <div class='col-sm-6 custom-width-6 '>
                                    <h4>Markiere alle 1, 2, oder 3 Sterne Bewertungen</h4>
                              </div>
                              <div class='col-sm-6  custom-width-62 p-0 p-5-0'>
                                 <div class='rating-selection'>
                                    <div class="rating-filter1 ">
                                       <div class="form-check">
                                          <input class="form-check-input" type="checkbox" value="1" id="rating1">
                                          <label class="form-check-label" for="rating1">
                                             <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                                             <span id='total1Rating'>Alle</span>
                                          </label>
                                       </div>
                                    </div>
                                    <div class="rating-filter1 ">
                                       <div class="form-check">
                                          <input class="form-check-input" type="checkbox" value="2" id="rating2">
                                          <label class="form-check-label" for="rating2">
                                             <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                                             <span id='total2Rating'>Alle</span>
                                          </label>
                                       </div>
                                    </div>
                                    <div class="rating-filter1 ">
                                       <div class="form-check">
                                          <input class="form-check-input" type="checkbox" value="3" id="rating3">
                                          <label class="form-check-label" for="rating3">
                                             <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                                             <span id='total3Rating'>Alle</span>
                                          </label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class='customers-list'  style="overflow: auto;height: 100vh;">
                           <div class="row mb-3 me-0">
                              <div class="col-12" id="search_result">
                                 <?php if($status == 0){ ?>
                                    <img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />
                                 <?php } ?>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 " id="search_company_bio" company-review='<?php echo $company_info['rating']; ?>' company-total-user-review='<?php echo $company_info['user_ratings_total']; ?>' >
                     <div>
                        <div class="row mb-3 offerTimerSection d-none">
                           <div class="col-12">
                              <div class="review_right_box text-center">
                                 <div class="title offerTimer" date='<?php echo date('Y-m-d h:m A',strtotime($response['creation_date'])); ?>' expireIN='<?php echo $response['offer_expire_in_days']; ?>' >
                                   Offer expire in  <span id='inDays'></span>
                                   <div id="timer"></div>
                                 </div>
                                 
                                
                              </div>
                           </div>
                        </div>
                        <div class="row mb-3">
                           <div class="col-12">
                              <div class="review_right_box">
                                 <div class="title">
                                    <h6><?php echo $company_info['name']; ?></h6>
                                 </div>
                                 <div class="d-flex  align-items-center mb-3 ">
                                    <img src="../assets/img/Frame112.png">
                                    <small id='s'>Bewertungsdurchschnitt bei erfolgreicher Löschung der ausgewählten Bewertungen</small>
                                 </div>
                                 <div class="rating">
                                    <span class='rating-rat'><?php echo $company_info['rating']; ?><small>/5.0</small></span>
                                    <span class='rating-update-diff'><img src="../assets/img/Component-2.png" alt=""></span>
                                    <span class='rating-rat RatingValueUpdate'><?php echo $company_info['rating']; ?><small>/5.0</small></span>
                                 </div>
                                 <div class="rating">
                                    <span>
                                    <?php
                                       $company_rating = $company_info['rating'];
                                       $fullStars = floor($company_rating);
                                       $decimalPart = $company_rating % 1;
                                       $hasHalfStar = ($decimalPart >= 0.49 && $decimalPart <= 0.99);
                                       $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);
                                       for ($i = 0; $i < $fullStars; $i++) {
                                           echo '<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">';
                                       }
                                       if ($hasHalfStar) {
                                           echo '<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">';
                                       }
                                       for ($i = 0; $i < $emptyStars; $i++) {
                                           echo '<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">';
                                       }
                                       
                                       
                                       
                                       ?>
                                    </span>
                                    <span></span>
                                    <span id='ratingUpdate'>
                                    <?php
                                       $company_rating = $company_info['rating'];
                                       $fullStars = floor($company_rating);
                                       $decimalPart = $company_rating % 1;
                                       $hasHalfStar = ($decimalPart >= 0.49 && $decimalPart <= 0.99);
                                       $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);
                                       for ($i = 0; $i < $fullStars; $i++) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">';
                                      }
                                      if ($hasHalfStar) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">';
                                      }
                                      for ($i = 0; $i < $emptyStars; $i++) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">';
                                      }
                                       
                                       
                                       
                                       ?>
                                    </span>
                                 </div>
                                 <hr>
                                 <div class="address">
                                    <span><img src="../assets/img/Maps and Flags.png" alt=""></span>
                                    <span><?php echo $company_info['formatted_address']; ?></span>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="row mb-3">
                           <div class="col-12 mb-3">
                              <div class="card review_right_box p-0 price_per_review_management">
                                 <div class="title card-header">
                                    <h6> <img src="../assets/img/Group.png" alt="">  &nbsp;  Preistabelle</h6>
                                 </div>
                                 <div class='card-body'>
                                    <div class=" dflex-space-around">
                                       <div class=" p-0 pe-1 rating justify-content-around">Von
                                       </div>
                                       <div class=" p-0 pe-1 rating justify-content-around">Bis
                                       </div>
                                       <div class=" p-0 pe-1 rating justify-content-around">Preis
                                       </div>
                                    </div>
                                    <?php
                                       $per_review_charge_details = unserialize($per_review_charge);
                                       foreach($per_review_charge_details AS $per_review_charge_detail){
                                           ?>
                                    <div class="dflex-space-around range-group mb-2 price_per_review_management_0">
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_min']; ?></div>
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_max']; ?></div>
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_amt']; ?>€</div>
                                    </div>
                                    <?php
                                       }
                                       ?>
                                 </div>
                              </div>
                           </div>
                           <div class="col-12">
                              <div class=" card review_right_box price-calculation-card" >
                                 <div class="card-header title">
                                    <h6> <img src="../assets/img/maximale-rechnungssumme.png" alt=""> &nbsp; Maximale Rechnungssumme</h6>
                                 </div>
                                 <div class='card-body'>
                                    <div class="row ">
                                       <div class='price-total'>
                                          <h6 id='Total_Price'>0€</h6>
                                          <p  id='total-review-select-price'>0 Bewertungen x 0€</p>
                                       </div>
                                       <div class="d-flex  align-items-center mb-3 ">
                                          <img src="../assets/img/uncheck-img.png">
                                          <small class='element-p'>Bezahlung nur für Tatsächlich gelöschte Bewertungen</small>
                                       </div>
                                       <div class="d-flex  align-items-center mb-3 ">
                                          <img src="../assets/img/uncheck-img.png">
                                          <small class='element-p'>Löschdauer 1-3 Wochen</small>
                                       </div>
                                       <div class="d-flex  align-items-center mb-3 ">
                                          <img src="../assets/img/uncheck-img.png">
                                          <small class='element-p'>Rechnungsstellung erst nach der Löschung</small>
                                       </div>
                                    </div>
                                    <div class="  error-img align-items-center mb-3 ">
                                       <img src="../assets/img/errorr-img.png">
                                       <small class='element-error' id='element-error' >Angebot läuft nach 7 Tagen ab!</small>
                                    </div>
                                    <div class="pt-2 d-flex align-items-center justify-content-around">
                                       <button data-bs-toggle="modal" data-bs-target="#submit_qoute_confirmation" class="send_btn btn-theme submit_qoute_confirmation w-100" >Löschen</button>
                                       <a href="/view/new-quote.php?<?php  echo $keys[0]; ?>"><button   class="send_btn NewQuote d-none btn-theme  w-100" >New Quote</button></a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
   </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.js"></script>
<script src="../assets/js/gr.js"></script>
<script src="../assets/js/new-quote.js?ver=<?php echo rand(); ?>"></script>

</body>
</html>
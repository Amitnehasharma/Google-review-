<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../includes/header.php');
include('../includes/sidebar.php');
include('../controllers/CompletedJobs.php');
$oj = new CompletedJobs();
$getCompletedJob   =  $oj->getCompletedJob();
?>
<div class="content-main-section left">
    <div class="container showdiv studentdetail">
        <?php echo headerHtml('Completed Jobs'); ?>
        <div class="active-complete-job p-x-12">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="row Me_padding align-items-center">
                        <div class="col-lg-12 px-0">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="text-lg-end marin-right">
                                    <input id="mySearch" class="Me-search Me_search_width" type="search" placeholder="Search client"></input>
                                    <img class="Me_Btn active search" src="../assets/img/LoupeWhite.svg"></img>
                                </div>
                                <div class="text-lg-end">
                                    <label>From: <input id="min" type="text" class="datepicker"></label>
                                    <label>To: <input id="max" type="text" class="datepicker"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row table_padd" style="padding: 1.5vw;">
                        <table id="completedJobsTable" class="table">
                            <thead>
                                <tr class="Me_table-Head">
                                    <th class="Me_table-Head" scope="col">List</th>
                                    <th scope="col">Client</th>
                                    <th scope="col">Approval date</th>
                                    <th scope="col">Review to delete</th>
                                    <th scope="col">Deleted</th>
                                    <th scope="col">Not possible</th>
                                    <th scope="col">Pending</th>
                                    <th scope="col">Value($)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $total_reveiw_to_delete=0;
                                $total_delete=0;
                                $total_not_possible=0;
                                $total_pending=0;
                                $total_value=0;
                                foreach ($getCompletedJob as $key => $completeData) {
                                    $total_reveiw_to_delete  += $completeData['reviewtodelete'];
                                    $total_delete  += $completeData['deleted'];
                                    $total_not_possible += $completeData['not_possible'];
                                    $total_pending  += $completeData['pending'];
                                    $total_value  += $completeData['value'];
                                    ?>
                                    <tr>
                                        <th scope="row"><?php echo ($key+1)?></th>
                                        <td><?php echo $completeData['company_name']; ?></td>
                                        <td><?php echo $completeData['approval_date']; ?></td>
                                        <td><?php echo $completeData['reviewtodelete']; ?></td>
                                        <td><?php echo $completeData['deleted']; ?></td>
                                        <td><?php echo $completeData['not_possible']; ?></td>
                                        <td><?php echo $completeData['pending']; ?></td>
                                        <td><?php echo '$'.$completeData['value']; ?></td>
                                    </tr>
                                <?php  } ?>
                            </tbody>
                            <tfoot>
                                <tr class="total_color">
                                    <td></td>
                                    <td>Total</td>
                                    <td></td>
                                    <td><?php echo $total_reveiw_to_delete;?></td>
                                    <td><?php echo $total_delete;?></td>
                                    <td><?php echo $total_not_possible;?></td>
                                    <td><?php echo $total_pending;?></td>
                                    <td>$<?php echo $total_value;?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('../includes/footer.php');
?>
<style>
    /* Style for datepicker input boxes */
    .datepicker {
        font-size: 14px;
        border-radius: 100px;
        border: 1px solid #D8D0F8;
        background: #FFF;
        padding: 0.5vw 1vw;
    }

    /* Style for datepicker calendar icon */
    .datepicker-icon {
        margin-left: 5px; /* Adjust margin as needed */
        cursor: pointer; /* Add cursor pointer */
    }
</style>

<!-- Include jQuery and jQuery UI -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>

<!-- Include DataTables CSS and JS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>

<!-- Include DataTables Buttons CSS and JS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.0.0/css/buttons.dataTables.min.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.0/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.html5.min.js"></script>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/buttons/2.0.0/js/buttons.print.min.js"></script>

<!-- Include DataTables Date Range Search Plugin -->
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/plug-ins/1.11.5/date-range/dataTables.dateRange.min.js"></script>
<script src="../assets/js/completedjobs.js?ver=<?php echo rand(); ?>"></script>
<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../controllers/User.php');
$userId ='';
if(isset($_GET['id'])){
    $userId  = $_GET['id'];
}

$user = new User();
$user=  $user->FetchUser($userId);

if(count($user)<1){
    header("Location: users.php");
    exit();
}
include('../includes/header.php');
include('../includes/sidebar.php');

?>
<div class="content-main-section left">
   <div class="container showdiv studentdetail">
      <div class="tab-content" id="v-pills-tabContent">
         <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab"
            tabindex="0">
            <?php echo headerHtml('Users'); ?>
            <div class="pt-2">
               <div class="container Me_padding-2 ">
                  <div class="floatright-d">
                     <a href='<?php echo base_url().'/view/users.php';?>'><button type="button" class="Me_Btn active float-right"> Users</button></a>
                  </div>
                  <div class="row   ">
                     <form id="EditUser" method="post" enctype="multipart/form-data" >
                        <div class="card ">
                           <div class="card-body row">
                              <input type="hidden" name="userid" id="userid" value='<?php  echo $userId; ?>'>
                              <div class="col-md-6">
                                 <!-- Full Name -->
                                 <div class="mb-3">
                                    <label for="fullName" class="form-label">Full Name:</label>
                                    <input type="text" class="form-control" id="fullName" name="fullName" placeholder="Enter your full name" required value="<?php echo $user['full_name'];?>">
                                 </div>
                                 <!-- Password -->
                                 <div class="mb-3">
                                    <label for="password" class="form-label">Password:</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password"   >
                                    <span id="passwordError" class="text-danger"></span>
                                 </div>
                                 <!-- Phone Number -->
                                 <div class="mb-3">
                                    <label for="phoneNumber" class="form-label">Phone Number:</label>
                                    <input type="tel" maxlength="12" minlength="10" class="form-control"  id="phoneNumber" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="phoneNumber" placeholder="Enter your phone number" required value="<?php echo $user['phone_number'];?>">
                                 </div>
                              </div>
                              <div class='col-md-6'>
                                 <!-- Email -->
                                 <div class="mb-3">
                                    <label for="email" class="form-label">Email:</label>
                                    <input type="email" class="form-control" id="email" name="email"  placeholder="Enter your email" required value="<?php echo $user['email'];?>" readonly='true'>
                                    <span id="emailerror" class="error"></span>
                                 </div>
                                 <!-- Date of Birth -->
                                 <div class="mb-3">
                                    <label for="dob" class="form-label">Date of Birth:</label>
                                    <input type="text" placeholder='Select date of birth' class="form-control datepicker" id="dob" name="dob" required value="<?php echo date('Y-m-d', strtotime($user['dob']));?>">
                                 </div>
                                 <!-- Profile Picture -->
                                 <div class="mb-3">
                                    <label for="profilePic" class="form-label">Profile Picture:</label>
                                    <input type="file" class="form-control" onchange="previewImage()" id="profilePic" name="profilePic">
                                 </div>
                                 <!-- Profile Img Preview -->
                                 <img id="imagePreview" src="<?php echo base_url().'/uploads/'.$user['profile_pic']; ?>" alt="Image Preview">
                              </div>
                           </div>
                           <div class="card-footer">
                              <button type="submit" class="Me_Btn active">Update</button>
                           </div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php 
include('../includes/footer_new.php');
?>
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>'
<script src="../assets/js/user.js?ver=<?php echo rand(); ?>"></script>
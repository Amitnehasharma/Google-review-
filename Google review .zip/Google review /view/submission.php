<?php
session_start();
// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include('../includes/header.php');
include('../includes/sidebar.php');
include('../controllers/ProposalResponse.php');
$proposalResponse = new ProposalsResponse();

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$tab = isset($_GET['tab']) ? $_GET['tab'] : 1;
$search = isset($_GET['search']) ? $_GET['search'] : '';
$limit = isset($_GET['limit']) ? $_GET['limit'] : 10; 
$offset = ($page - 1) * $limit;
$data = $proposalResponse->SubmissionsData($offset, $limit,$search);
$submissions = $data['submissions']; 
$total_data = $data['total_data']; 
$total_records = $proposalResponse->getTotalRecords($search);
/// echo $total_records;

// echo '<pre>';
// print_r($submissions);
// echo '</pre>';

?>
<style>
    .Me_Btn.Me_Btn.search.small {
        padding: 0.5vw 1.25vw !important;
    }
</style>
<div class="content-main-section left">
   <div class="container showdiv studentdetail">
      
         <div class="tab-pane p-x-12" id="v-pills-submissions" role="tabpanel"
            aria-labelledby="v-pills-submissions-tab" tabindex="0">
            <?php echo headerHtml('Submissions'); ?>
            <div class="active-complete-job">
               <div class="container-fluid">
                     <div class="row align-items-center justify-content-center">
                        <div class="row Me_padding-submission">
                           <div class="col-lg-2 ps-0">
                                 <div class="d-none">
                                    <button class="Me_Btn active">Proposals</button>
                                    <button class="Me_Btn non-active">Responses</button>
                                 </div>
                           </div>
                           <div class="col-lg-6">
                                 <div class="text-lg-end">
                                    <input class="Me-search" value='<?php  echo $search; ?>' type="search" placeholder="Search client" id="searchInput"></input>
                                    <img data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>' class="Me_Btn active search" src="../assets/img/LoupeWhite.svg" id="searchBtn"></img>
                                    <select data-page='<?php  echo $page; ?>' data-tab='<?php  echo $tab; ?>'  data-limit='<?php  echo $limit; ?>' name="submission-limit" id='submission-limit' class="filter-list" style="margin: 0;padding: 10px 20px;">
                                          <option value='10' <?php echo  $limit==10?'selected':''; ?>>10</option>
                                          <option value='20' <?php echo  $limit==20?'selected':''; ?>>20</option>
                                          <option value='50' <?php echo $limit==50?'selected':''; ?>>50</option>
                                          <option value='100' <?php echo $limit==100?'selected':''; ?>>100</option>
                                    </select>
                                 </div>
                           </div>
                           <div class="col-lg-4 pe-0">
                                    <div class="text-lg-end d-flex"> 
                                          <?php  updatePagination($total_records, $limit, $page,1,$search); ?>
                                    </div>
                           </div>
                        </div>
                        <div class="row m-auto table_padd">
                           <table class="table">
                                 <thead>
                                    <tr class="Me_table-Head">
                                       <th class="Me_table-Head" scope="col">List</th>
                                       <th width='30%' scope="col">Client</th>
                                       <th scope="col">Submit Date Time</th>
                                       <th width='10%' class='text-center' scope="col">Job no.</th>
                                       <th scope="col">No. of review</th>
                                       <th scope="col">Not possible</th>
                                       <th scope="col">Deleted</th>
                                       <th scope="col">Pending</th>
                                       
                                       <th scope="col" class='text-center' width='10%'>URl Copy</th>
                                       <th scope="col"></th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <?php
                                    $sr_no = ($page - 1) * $limit + 1;
                                    $totalJobNo = 0;
                                    $totalOccurrences = 0;
                                    $totalNotPossible = 0;
                                    $totalDeleted = 0;
                                    $totalRemainingOccurrences = 0;
                                    if(count($submissions)>0){
                                     foreach($submissions as $key=> $submission){ 
                                      $totalJobNo += $submission['job_no'];
                                       $totalOccurrences += $submission['occurrences_in_quotes_details'];
                                       $totalNotPossible += $submission['not_possible'];
                                       $totalDeleted += $submission['deleted'];
                                       $totalRemainingOccurrences += $submission['remaining_occurrences'];
                                    ?>
                                    <tr>
                                       <th scope="row"><?php echo ($key+1); ?></th>
                                       <td>
                                          <?php
                                             $company_name = unserialize($submission['company_info']);
                                             echo $company_name['name'];
                                          ?>
                                       </td>
                                       <td class='text-center'><?php echo date('d-m-Y', strtotime($submission["submit_date"])); ?><br><?php echo date('h:m A', strtotime($submission["submit_date"])); ?></td>
                                       <td class='text-center'><?php echo $submission['job_no']; ?></td>
                                       <td class='text-center'><?php echo $submission['occurrences_in_quotes_details']; ?></td>
                                       <td class='text-center'><?php echo $submission['not_possible']; ?></td>
                                       <td class='text-center'><?php echo $submission['deleted']; ?></td>
                                       <td class='text-center'><?php echo $submission['remaining_occurrences']; ?></td>
                                       
                                       <td class='text-center'><a onclick="copyLink(this)" href="javascript:void(0)" data-link='<?php echo base_url().'qoute?'.$submission["uniqid"]; ?>' id="copyLink">Copy Link</a> </td>
                                       <td><a href="<?php echo base_url(); ?>view/submission-details.php?uniqid=<?php echo $submission['uniqid']; ?>" class="view_details">View details</a></td>
                                    </tr>
                                    <?php }
                                    }else{
                                       echo '<tr>

                                                            <td valign="top" colspan="7" class="dataTables_empty text-center">No data available in table</td>
                                                        </tr>';
                                    } ?>
                                 </tbody>
                                 <tr class="total_color">
                                    <td></td>
                                    <td>Total</td>
                                    <td><?php ///echo $totalJobNo; ?></td>
                                    <td><?php ///echo $totalJobNo; ?></td>
                                    <td class='text-center'><?php echo $totalOccurrences ; ?></td>
                                    <td class='text-center'><?php echo  $totalNotPossible; ?></td>
                                    <td class='text-center'><?php echo $totalDeleted ?></td>
                                    <td class='text-center'><?php echo $totalRemainingOccurrences ; ?></td>
                                    <td></td>
                                    <td></td>
                                 </tr>
                           </table>
                        </div>
                     </div>
               </div>
            </div>

         </div>
      
   </div>
</div>      
<?php 
include('../includes/footer.php');

?>
<script src="../assets/js/submissions.js?ver=<?php echo rand(); ?>"></script>

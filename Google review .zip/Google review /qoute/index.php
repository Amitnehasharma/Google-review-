<?php
include('../controllers/QuoteView.php');
$keys = array_keys($_GET);
$QuoteView_obj = new QuoteView();
$response = $QuoteView_obj->FetchQuotes($keys[0]);

$uniqid = $response['uniqid'];
$place_id = $response['place_id'];
$per_review_charge = $response['per_review_charge'];
$email = $response['email'];
$company_info = unserialize($response['company_info']);
 $status =$response['status'];


$responseCreationDate = $response['creation_date']; 
$originalDateTime = new DateTime($responseCreationDate);
$modifiedDateTime = clone $originalDateTime;
$modifiedDateTime->modify('+'.$response['offer_expire_in_days'].' days');
$dateInterval = $originalDateTime->diff($modifiedDateTime);
$daysDifference = $dateInterval->days;
$currentDateTime = new DateTime();
$expired =0;
if ($modifiedDateTime >= $currentDateTime) {
} else {
    echo '<style>.expired{display:none;} .expired-100{width:100%;}</style>';
    $expired =1; 
    //die;
}
 
if($status !=0){
   $expired =0;
}

// Calculate the difference in days between modifiedDateTime and currentDateTime
$dateIntervalCurrent = $modifiedDateTime->diff($currentDateTime);
$daysDifferenceCurrent = $dateIntervalCurrent->days;

// echo "Modified Date: " . $modifiedDateTime->format('Y-m-d h:i A') . "<br>";
// echo "Current Date: " . $currentDateTime->format('Y-m-d h:i A') . "<br>";
// echo "Difference in Days: " . $daysDifferenceCurrent;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SterneHero</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href='https://fonts.googleapis.com/css?family=Inter:wght@100;200;300;400;500;600;700&display=swap' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/style.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/scss/main.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/custom.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/qoute.css?ver=<?php echo rand(); ?>">
    <script> const base_url = 'https://app.sternehero.de'; </script>
    <script> const uniqid = '<?php echo $uniqid; ?>'; const place_id = '<?php echo $place_id; ?>'; </script>
</head>
<body>
   <div id="loader" class="lds-dual-ring hidden  overlay"></div>
   <div id='qoute'>
      <div class=" showdiv studentdetail ">
         <header class="header-fix-top-section">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-8">
                     <div class="brand-title" style="margin: 0;">
                        <a class="d-inline-flex align-items-center cursor-pointer" href="/">
                        <img class="img-fluid Feedback px-1" src="../assets/img/logo.png" alt="">
                        </a>
                     </div>
                  </div>
                  <div class="col-4  calendar-mobile-verson ">
                     <div class="calendar-title">
                        <img src="../assets/img/calendar-01.png" class='d-none' alt="">
                        <div class="calendar-inner">
                           <img src="../assets/img/calendar-01.png" alt="">
                           <span>31-01-2024</span>
                        </div>
                        <div class="calendar-inner">
                           <img src="../assets/img/clock-01.png" alt="">
                           <span id="clock">10:23</span>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <div class=" container search-section mt-4">
            <div class="container-fluid">
               <div class="row mb-3 mx-0" style="padding: 1vw 0;">
                  <div class="col-lg-9  mobile-top-margin-250"  >
                     <div class='card customer-list-card'>
                        <div class='top-heading'>
                           <div class='row'>
                              <div class='col-sm-8'>
                                 <h6 id='total-review-count' class='<?php if($expired==1){ echo'text-center-mobile-view';}?>'>0 Bewertungen</h6>
                              </div>
                              <div class='col-sm-4' id='withoutsubmit'>
                                 <input type="hidden" value='<?php  echo $place_id;?>'  name='place_id' id='place_id'>
                                 <div class='w-100'>
                                    <div class="input-group">
                                       <div class="input-group-prepend">
                                          <div class="input-group-text"><img src="../assets/img/search.png" alt="Lock Icon" class=""></div>
                                       </div>
                                       <input type='text' class='form-control customer-search' placeholder='Suchen' >
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <?php if($expired==0){?>
                           <div class='row d-flex align-items-base'>
                                <div class='col-sm-8'>
                                    <div class='rating-selection mobile-scroll-top ' id='filter-review-by-status'>
                                        <div class="rating-filter filter-tab active non-active " id="0">
                                            <span id='all'>Alle</span>
                                        </div>
                                        <div class="rating-filter filter-tab" id="3">
                                            <span id='progress'>0 In Bearbeitung</span>
                                        </div>
                                        <div class="rating-filter filter-tab" id="1">
                                            <span id='deleted'>0 Gelöscht</span>
                                        </div>
                                        <div class="rating-filter filter-tab" id="2">
                                            <span id='failed'>0  Gescheitert</span>
                                        </div>
                                    </div>
                                </div>
                                <div class='col-sm-4'>
                                   <div class="input-group">
                                       <div class="input-group-prepend">
                                          <div class="input-group-text"><img src="../assets/img/search.png" alt="Lock Icon" class=""></div>
                                       </div>
                                       <input type='text' class='form-control customer-search' placeholder='Suchen'>
                                    </div>
                                </div>
                           </div>
                           <?php } ?>
                        </div>
                        <?php if($expired==0){?>
                        <div class='rating-selection mobile-scroll-top'  id="filter_by_rating">
                           <div class="rating-filter filter-tab active non-active" id="0">
                               <img class="img-fluid" src="../assets/img/fill-rating.png" alt="">
                              <span id='all'>Alle</span>
                           </div>
                           <div class="rating-filter filter-tab" id="1">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span class='total1Rating'>1 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="2">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span class='total2Rating'>2 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="3">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span class='total3Rating'>3 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="4">
                               <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span id='total4Rating'>4 (0)</span>
                           </div>
                           <div class="rating-filter filter-tab" id="5">
                              <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                              <span id='total5Rating'>5 (0)</span>
                           </div>
                        </div>
                        <hr>
                        <div class='dflex-center '>
                           <div class='row p-01'>
                              <div class='col-sm-6 custom-width-6 '>
                                    <h4>Markiere alle 1, 2, oder 3 Sterne Bewertungen</h4>
                              </div>
                              <div class='col-sm-6  custom-width-62 p-0 p-5-0'>
                                 <div class='rating-selection mobile-scroll-top p-0'>
                                    <div class="rating-filter1 custom-padding ">
                                       <div class="form-check">
                                          <input class="form-check-input" type="checkbox" value="1" id="rating1">
                                          <label class="form-check-label" for="rating1">
                                             <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                                             <span id='total1Rating'>Alle</span>
                                          </label>
                                       </div>
                                    </div>
                                    <div class="rating-filter1 custom-padding ">
                                       <div class="form-check">
                                          <input class="form-check-input" type="checkbox" value="2" id="rating2">
                                          <label class="form-check-label" for="rating2">
                                             <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                                             <span id='total2Rating'>Alle</span>
                                          </label>
                                       </div>
                                    </div>
                                    <div class="rating-filter1 custom-padding ">
                                       <div class="form-check">
                                          <input class="form-check-input" type="checkbox" value="3" id="rating3">
                                          <label class="form-check-label" for="rating3">
                                             <img class="img-fluid" src="../assets/img/RatingItems.png" alt="">
                                             <span id='total3Rating'>Alle</span>
                                          </label>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php }else{
                           echo '<h2 class="text-center offer-expired">Angebot abgelaufen</h2><hr>';
                        } ?>
                        <div class='customers-list'  style="overflow: auto;height: 100vh;">
                           <div class="row mb-3 me-0">
                              <div class="col-12" id="search_result">
                                 <?php if($status == 0){ ?>
                                    <img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />
                                 <?php } ?>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-3 " id="search_company_bio" company-review='<?php echo $company_info['rating']; ?>' company-total-user-review='<?php echo $company_info['user_ratings_total']; ?>' >
                     <div>
                        <div class="row mb-3 offerTimerSection d-none">
                           <div class="col-12">
                              <div class="review_right_box text-center">
                                 <div class="title offerTimer" date='<?php echo date('Y-m-d h:m A',strtotime($response['creation_date'])); ?>' expireIN='<?php echo $response['offer_expire_in_days']; ?>' >
                                   Offer expire in  <span id='inDays'></span>
                                   <div id="timer"></div>
                                 </div>
                                 
                                
                              </div>
                           </div>
                        </div>
                        <div class="row mb-3 position-rela">
                           <div class="col-12 position-absule">
                              <div class="review_right_box">
                                 <div class="title">
                                    <h6><?php echo $company_info['name']; ?></h6>
                                 </div>
                                 <div class="d-flex change-element  align-items-center mb-3 ">
                                    <img src="../assets/img/Frame112.png">
                                    <small id='s'>Bewertungsdurchschnitt bei erfolgreicher Löschung der ausgewählten Bewertungen</small>
                                 </div>
                                 <div class="rating">
                                    <span class='rating-rat'><?php echo $company_info['rating']; ?><small>/5.0</small></span>
                                    <span class='rating-update-diff'><img src="../assets/img/gif/avg-rating.gif" alt=""></span>
                                    <span class='rating-rat RatingValueUpdate'><?php echo $company_info['rating']; ?><small>/5.0</small></span>
                                 </div>
                                 <div class="rating">
                                    <span>
                                    <?php
                                       $company_rating = $company_info['rating'];
                                       $fullStars = floor($company_rating);
                                       $decimalPart = $company_rating % 1;
                                       $hasHalfStar = ($decimalPart >= 0.49 && $decimalPart <= 0.99);
                                       $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);
                                       for ($i = 0; $i < $fullStars; $i++) {
                                           echo '<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">';
                                       }
                                       if ($hasHalfStar) {
                                           echo '<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">';
                                       }
                                       for ($i = 0; $i < $emptyStars; $i++) {
                                           echo '<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">';
                                       }
                                       
                                       
                                       
                                       ?>
                                    </span>
                                    <span></span>
                                    <span id='ratingUpdate'>
                                    <?php
                                       $company_rating = $company_info['rating'];
                                       $fullStars = floor($company_rating);
                                       $decimalPart = $company_rating % 1;
                                       $hasHalfStar = ($decimalPart >= 0.49 && $decimalPart <= 0.99);
                                       $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);
                                       for ($i = 0; $i < $fullStars; $i++) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">';
                                      }
                                      if ($hasHalfStar) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">';
                                      }
                                      for ($i = 0; $i < $emptyStars; $i++) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">';
                                      }
                                       
                                       
                                       
                                       ?>
                                    </span>
                                 </div>
                                 <hr>
                                 <div class="address">
                                    <span><img src="../assets/img/Maps and Flags.png" alt=""></span>
                                    <span><?php echo $company_info['formatted_address']; ?></span>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php if($expired==0):?>
                        <div class="row mb-3">
                           <div class="col-12 price_per_review_management-section mb-3">
                              <div class="card review_right_box p-0 price_per_review_management">
                                 <div class="title card-header">
                                    <h6> <img src="../assets/img/Group.png" alt="">  &nbsp;  Preistabelle</h6>
                                 </div>
                                 <div class='card-body'>
                                    <div class=" dflex-space-around">
                                       <div class=" p-0 pe-1 rating justify-content-around">Von
                                       </div>
                                       <div class=" p-0 pe-1 rating justify-content-around">Bis
                                       </div>
                                       <div class=" p-0 pe-1 rating justify-content-around">Preis
                                       </div>
                                    </div>
                                    <?php
                                       $per_review_charge_details = unserialize($per_review_charge);
                                       foreach($per_review_charge_details AS $per_review_charge_detail){
                                           ?>
                                    <div class="dflex-space-around range-group mb-2 price_per_review_management_0">
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_min']; ?></div>
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_max']; ?></div>
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_amt']; ?>€</div>
                                    </div>
                                    <?php
                                       }
                                       ?>
                                 </div>
                              </div>
                           </div>
                           <div class="col-12 price-calculation-mobile-version ">
                              <div class=" card review_right_box price-calculation-card" >
                                 <div class="card-header title">
                                    
                                 <div class="accordion accordion-flush price_per_review_management" id="accordionFlushExample">
                                    <div class="accordion-item">
                                       <h2 class="accordion-header" id="flush-headingOne">
                                          <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                             <h6> <img src="../assets/img/Group.png" alt="">  &nbsp;  Preistabelle</h6>
                                          </button>
                                       </h2>
                                       <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                          <div class="accordion-body">
                                          <div class=" dflex-space-around">
                                       <div class=" p-0 pe-1 rating justify-content-around">Von
                                       </div>
                                       <div class=" p-0 pe-1 rating justify-content-around">Bis
                                       </div>
                                       <div class=" p-0 pe-1 rating justify-content-around">Preis
                                       </div>
                                    </div>
                                    <?php
                                       $per_review_charge_details = unserialize($per_review_charge);
                                       foreach($per_review_charge_details AS $per_review_charge_detail){
                                           ?>
                                    <div class="dflex-space-around range-group mb-2 price_per_review_management_0">
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_min']; ?></div>
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_max']; ?></div>
                                       <div class=" p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_amt']; ?>€</div>
                                    </div>
                                    <?php
                                       }
                                       ?>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                                    <h6 class='mobile-d-none'> <img src="../assets/img/maximale-rechnungssumme.png" alt=""> &nbsp; Maximale Rechnungssumme</h6>
                                 </div>
                                 <div class='card-body'>
                                    <div class="row ">
                                       <div class='price-total'>
                                          <h6 id='Total_Price'>0€</h6>
                                          <p  id='total-review-select-price'>0 Bewertungen x 0€</p>
                                       </div>
                                       <div class="d-flex  align-items-center mb-3 ">
                                          <img src="../assets/img/uncheck-img.png">
                                          <small class='element-p'>Bezahlung nur für Tatsächlich gelöschte Bewertungen</small>
                                       </div>
                                       <div class="d-flex  align-items-center mb-3 ">
                                          <img src="../assets/img/uncheck-img.png">
                                          <small class='element-p'>Löschdauer 1-3 Wochen</small>
                                       </div>
                                       <div class="d-flex  align-items-center mb-3 ">
                                          <img src="../assets/img/uncheck-img.png">
                                          <small class='element-p'>Rechnungsstellung erst nach der Löschung</small>
                                       </div>
                                    </div>
                                    <div class="  error-img align-items-center mb-3 ">
                                       <img src="../assets/img/errorr-img.png">
                                       <small class='element-error' id='element-error' >Angebot läuft nach <?php echo $daysDifferenceCurrent; ?> Tagen ab !</small>
                                    </div>
                                    <div class="pt-2 d-flex align-items-center justify-content-around">
                                       <button disabled data-bs-toggle="modal" data-bs-target="#submit_qoute_confirmation" class="send_btn btn-theme submit_qoute_confirmation w-100" >Löschen</button>
                                       <button data-placeId='<?php echo $place_id ; ?>' per_review_charge='<?php echo json_encode(unserialize($per_review_charge)) ; ?>'  expireIN='<?php echo $response['offer_expire_in_days']; ?>' clicked='0';  class="send_btn NewQuote d-none btn-theme  w-100" type='button' id='NewQuote' > Neues Angebot anfordern</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <?php endif ; ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" id="submit_qoute_confirmation" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm">
         <div class="modal-content">
            <div class="modal-body">
               <div class='icon-top-area text-center'>
                  <img src="../assets/img/Icon.png">
                  <p class='element-p'>Angebot bestätigen</p>
               </div>
               <hr>
               <h6 class='Zusammenfassung mt-4'>Zusammenfassung</h6>
               <div class='d-flex  align-items-center justify-content-space-between'>
                  <p class='element-title'>Zu löschende Bewertungen</p>
                  <p class='element-price total-deleted-review'>44 Stück</p>
               </div>
               <div class='d-flex  align-items-center justify-content-space-between'>
                  <p class='element-title'>Preis pro Löschung</p>
                  <p class='element-price deleted-review-price'>20€</p>
               </div>
               <hr>
               <div class='d-flex  align-items-center justify-content-space-between mt-2 mb-1'>
                  <p class='element-title-t'>Maximale Rechnungssumme</p>
                  <p class='element-price-total '>880€</p>
               </div>
               <hr class='mt-0'>
               <div class='icon-top-area mt-2'>
                  <img src="../assets/img/vector-6909.png">
                  <span class='element-0-'>Ihr Auftritt nach der Löschung</span>
               </div>
               <div class="review_right_box card mt-3 border-radius-8">
                  <div class="title">
                     <h6><?php echo $company_info['name']; ?></h6>
                  </div>
                  <div class="rating d-block mt-3">
                     <span class='rating-rat RatingValueUpdate'><?php echo $company_info['rating']; ?><small>/5.0</small></span>
                     <span class='mr-2 modal-rating-update'>
                     <?php
                                       $company_rating = $company_info['rating'];
                                       $fullStars = floor($company_rating);
                                       $decimalPart = $company_rating % 1;
                                       $hasHalfStar = ($decimalPart >= 0.49 && $decimalPart <= 0.99);
                                       $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);
                                       for ($i = 0; $i < $fullStars; $i++) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">';
                                      }
                                      if ($hasHalfStar) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">';
                                      }
                                      for ($i = 0; $i < $emptyStars; $i++) {
                                          echo '<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">';
                                      }
                                       
                                       
                                       
                                       ?>
                     </span>
                     <span class='rating-rat'></span>
                  </div>
                  <div class="address pt-2">
                     <span><img src="../assets/img/Maps and Flags.png" alt=""></span>
                     <span><?php echo $company_info['formatted_address']; ?></span>
                  </div>
               </div>
               <hr>
               <p class='modal-company-txt'>Nach der Angebotsbestätigung gelangen Sie zu unserem Portal, zur einfachen Überwachung des Löschvorgangs Ihrer Bewertungen.</p>
            </div>
            <div class="modal-footer">
               <div class='row text-center justify-content-space-around '>
                  <button type="button" class="send_btn cancel-btn  col-5 " data-bs-dismiss="modal">Abbrechen</button>
                  <button type="button" id="send_qoute_button" class=" send_btn btn-theme col-5 "> Bestätigen</button>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="modal fade" data-bs-backdrop="static" data-bs-keyboard="false" id="submit_qoute_confirmation1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-sm">
         <div class="modal-content">
            <div class="modal-body">
               <div class='icon-top-area text-center'>
                  <img src="../assets/img/Icon-1.png">
                  <p class='element-p mt-3'>Geschafft!</p>
               </div>
               <p id='entgegengenommen'>Ihre Anfrage wurde entgegengenommen und wird nun bearbeitet. <br>
                  Falls Sie auf die zu löschenden Bewertungen geantwortet haben,
                  sollten Sie diese bitte noch Löschen.
               </p>
               <button type="button" class=" send_btn btn-theme w-100 mt-4 " id='reload-window'> Zum Portal</button>
            </div>
         </div>
      </div>
   </div>
   <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.js"></script>
   <script src="../assets/js/gr.js"></script>
   <script>
      function updateClock() {
          var now = new Date();
          var hours = now.getHours().toString().padStart(2, '0');
          var minutes = now.getMinutes().toString().padStart(2, '0');
          var seconds = now.getSeconds().toString().padStart(2, '0');
          var timeString = hours + ':' + minutes;
      
          document.getElementById('clock').innerHTML = timeString;
      }
      
      setInterval(updateClock, 1000);
      updateClock(); // Call the function immediately to display the clock on page load
   </script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-dateFormat/1.0/jquery.dateFormat.min.js?ver=129879262"></script>
   <?php if($status !=0 ){ ?>
   <script src="../assets/js/submitquote.js?ver=<?php echo rand(); ?>"></script>
   <?php }else{ ?>
   <script src="../assets/js/searchview.js?ver=<?php echo rand(); ?>"></script>
   <?php } ?>
</body>
</html>
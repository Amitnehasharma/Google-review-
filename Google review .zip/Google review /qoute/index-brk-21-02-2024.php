<?php
include('../controllers/QuoteView.php');
$keys = array_keys($_GET);
$QuoteView_obj = new QuoteView();
$response = $QuoteView_obj->FetchQuotes($keys[0]);

$uniqid = $response['uniqid'];
$place_id = $response['place_id'];
$per_review_charge = $response['per_review_charge'];
$email = $response['email'];
$company_info = unserialize($response['company_info']);
$status = $response['status'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GR Deletion</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Red+Hat+Text:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/scss/main.css?ver=<?php echo rand(); ?>">
    <link rel="stylesheet" href="../assets/css/custom.css?ver=<?php echo rand(); ?>">
    <script> const base_url = 'https://app.sternehero.de'; </script>
    <script> const uniqid = '<?php echo $uniqid; ?>'; </script>
</head>

<body>
    <div>
        <div class="container showdiv studentdetail">
            <div class="tab-content" id="v-pills-tabContent">
                <div class="" id="v-pills-users" role="tabpanel" aria-labelledby="v-pills-users-tab" tabindex="0">
                    <header class="header-fix-top-section boder-top">
                        <div class="container">
                            <div class="row align-items-center">
                                <div class="col-7">
                                    <div class="brand-title" style="margin: 0;">
                                    <a class="d-inline-flex align-items-center cursor-pointer" href="/">
                                        <img class="img-fluid Feedback px-1" src="../assets/img/logo.png" alt="">
                                    </a>
                                    </div>
                                </div>
                                <div class="col-4 offset-1">
                                    <div class="calendar-title">
                                        <div class="calendar-inner">
                                            <img src="../assets/img/Calendar.png" alt="">
                                            <span>31-01-2024</span>
                                        </div>
                                        <div class="calendar-inner">
                                            <img src="../assets/img/Clock.png" alt="">
                                            <span id="clock">16:57</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <div class="search-section">
                        <div class="container-fluid">
                            <div class="row mb-3 mx-0" style="padding: 1vw 0;">
                                <div class="col-lg-9" id="search_result" style="overflow: auto;height: 80vh;">
                                    <?php if($status == 0){ ?>
                                        <img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />
                                    <?php } ?>
                                </div>
                                <div class="col-lg-3 pe-0" id="search_company_bio">
                                    <div>
                                        <div class="row mb-3">
                                            <div class="col-12">
                                                <div class="review_right_box">
                                                    <div class="title">
                                                        <h6><?php echo $company_info['name']; ?></h6>
                                                    </div>
                                                    <div class="rating">
                                                        <span><?php echo $company_info['rating']; ?>/5</span>
                                                        <span>
                                                            <?php
                                                                $company_rating = $company_info['rating'];
                                                                $fullStars = floor($company_rating);
                                                                $decimalPart = $company_rating % 1;
                                                                $hasHalfStar = ($decimalPart >= 0.49 && $decimalPart <= 0.99);
                                                                $emptyStars = 5 - $fullStars - ($hasHalfStar ? 1 : 0);

                                                                for ($i = 0; $i < $emptyStars; $i++) {
                                                                    echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                                                                            <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                                                                        </svg>';
                                                                }
                                                                if ($hasHalfStar) {
                                                                    echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                                                                            <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                                                                            <path d="M15.5 0.000152588L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 0.000152588Z" fill="#FED156"></path>
                                                                        </svg>';
                                                                }
                                                                for ($i = 0; $i < $fullStars; $i++) {
                                                                    echo '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                                                                            <path d="M15.5 7.62939e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 7.62939e-05Z" fill="#FED156"></path>
                                                                        </svg>';
                                                                }

                                                            ?>
                                                        </span>
                                                    </div>
                                                    <div class="address">
                                                        <span><img src="../assets/img/Maps and Flags.png" alt=""></span>
                                                        <span><?php echo $company_info['formatted_address']; ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 mb-3">
                                                <div class="review_right_box price_per_review_management">
                                                    <div class="title">
                                                        <h6>Review deletion price</h6>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <div class="col-4 p-0 pe-1 rating justify-content-around">Min
                                                        </div>
                                                        <div class="col-4 p-0 pe-1 rating justify-content-around">Max
                                                        </div>
                                                        <div class="col-4 p-0 pe-1 rating justify-content-around">Amt
                                                        </div>
                                                    </div>
                                                    <?php
                                                        $per_review_charge_details = unserialize($per_review_charge);
                                                        foreach($per_review_charge_details AS $per_review_charge_detail){
                                                            ?>
                                                                <div class="row range-group mb-2 price_per_review_management_0">
                                                                    <div class="col-4 p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_min']; ?></div>
                                                                    <div class="col-4 p-0 pe-1 rating justify-content-around"><?php echo $per_review_charge_detail['range_max']; ?></div>
                                                                    <div class="col-4 p-0 pe-1 rating justify-content-around">$<?php echo $per_review_charge_detail['range_amt']; ?></div>
                                                                </div>
                                                            <?php
                                                        }
                                                    ?>

                                                    
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="review_right_box">
                                                    <div class="title">
                                                        <h6>Total Selected Review</h6>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <div class="col-6 p-0 pe-1 rating justify-content-around">Total Review
                                                        </div>
                                                        <div class="col-6 p-0 pe-1 rating justify-content-around" id='Total_Review'>5
                                                        </div>
                                                        <div class="col-6 p-0 pe-1 rating justify-content-around Total_Price-label" >Total Price
                                                        </div>
                                                        <div class="col-6 p-0 pe-1 rating justify-content-around" id='Total_Price'>5
                                                        </div>
                                                       
                                                    </div>
                                                    <!-- <div id='_calculation' class="addres4s mb-2 text-center pt-2 align-items-center justify-content-around">
                                                        <span style="font-size: 21px;" class="review_rate_calculation">0 X $0=<span style="font-size: 25px;color: #5d46b7;">$0</span></span>
                                                    </div> -->
                                                    <div class="pt-2 d-flex align-items-center justify-content-around">
                                                        <button class="send_btn" id="send_qoute_button">Submit</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.js"></script>

    <script src="../assets/js/gr.js"></script>

    <script>
        function updateClock() {
            var now = new Date();
            var hours = now.getHours().toString().padStart(2, '0');
            var minutes = now.getMinutes().toString().padStart(2, '0');
            var seconds = now.getSeconds().toString().padStart(2, '0');
            var timeString = hours + ':' + minutes;

            document.getElementById('clock').innerHTML = timeString;
        }

        setInterval(updateClock, 1000);
        updateClock(); // Call the function immediately to display the clock on page load
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-dateFormat/1.0/jquery.dateFormat.min.js?ver=<?php echo rand(); ?>"></script>
    <?php if($status == 1){ ?>
        <script src="../assets/js/submitquote.js?ver=<?php echo rand(); ?>"></script>
    <?php }else{ ?>
        <script src="../assets/js/searchview.js?ver=<?php echo rand(); ?>"></script>
    <?php } ?>
</body>

</html>
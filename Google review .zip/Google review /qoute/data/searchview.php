<?php
$postData = file_get_contents('php://input');
$data = json_decode($postData, true);
if ($data['type'] == 'get_qoute') {
    include('../../controllers/Quotes.php');
    $Quotes_obj  = new Quotes();
    $response = $Quotes_obj->FetchQuotes($data['id']);
    $res      = $Quotes_obj->FetchReview_ids($data['place_id']);
    if(count($response) == 0){
        echo json_encode(['status' => 0]);
    }else{
        $data = [
            'id' => $response['id'],
            'uniqid' => $response['uniqid'],
            'place_id' => $response['place_id'],
            'per_review_charge' => unserialize($response['per_review_charge']),
            'email' => $response['email'],
            'reviews' => unserialize($response['reviews']),
            'creation_date' => $response['creation_date']
        ];
        echo json_encode(['status' => 1,'data' => $data,'not_possible_data'=>$res]);
    }
}
?>
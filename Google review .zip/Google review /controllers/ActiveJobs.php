<?php
include('../config/connection.php');
session_start();

class ActiveJobs 
{
    private $con;

    public function __construct() {
        global $conn;
        $this->con = $conn;
    }

    public function getActiveJobs() {
        $data = array();
        $datalist = array();
        
        if (!$this->con) {
            // Connection error
            echo "Connection error: " . $this->con->connect_error;
            return $data;
        }

        $sql = "SELECT q.*, 
        COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
        COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
        COUNT(qd.uniqid) AS total_review_delete,
        (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS pending
        FROM quotes q LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid 
        WHERE active = 1  And status=2 GROUP BY q.uniqid ORDER BY q.submit_date DESC 
                ";
        $result = $this->con->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    
                    
                    $data['id'] = $row['id'];
                    $data['uniqid'] = $row['uniqid'];
                    $data['company_name'] = unserialize($row['company_info'])['name'];
                    $data['reviewtodelete'] = $row['total_review_delete'] ;//$total_review_delete;
                    $data['deleted'] = $row['deleted'];//$deleted;
                    $data['not_possible'] = $row['not_possible'];
                    $data['pending'] = $row['pending'];
                    $data['value'] = ($row['review_rate']*$row['total_review_delete']);
                    $data['approval_date'] = date('d-m-Y',strtotime($row['creation_date']));
                    $datalist[]=$data;
                }
            }
        } else {
            // Query execution error
            echo "Query error: " . $this->con->error;
        }
        return $datalist;
    }
}
?>
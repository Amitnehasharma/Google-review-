<?php
include('../config/connection.php');
session_start();

class ProposalsResponse{
   

    public function FetchProposals($offset, $limit, $search) {
        global $conn;
        $proposals = array();
    
        // Base SQL query
        $sql = "SELECT * FROM quotes WHERE status = 0"; 
    
        if(!empty($search)){
            $search = $conn->real_escape_string($search); // Sanitize search string to prevent SQL injection
            $sql .= " AND  `reviews` LIKE '%$search%' OR `company_info` LIKE '%$search%'";
        }
        $sql .= " ORDER by `creation_date` DESC LIMIT $offset, $limit";
    
        $result = $conn->query($sql);
    
        if ($result && $result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $proposals[] = $row;
            }
        }
    
        return $proposals;
    }
    
    public function TotalProposalsCount($search){
        global $conn;
        $sql = "SELECT COUNT(*) AS total FROM quotes WHERE status = 0 ";
        if(!empty($search)){
            $search = $conn->real_escape_string($search); // Sanitize search string to prevent SQL injection
            $sql .= " and `reviews` LIKE '%$search%' OR `company_info` LIKE '%$search%'";
        }
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        return $row['total'];
    }
    
    public function FetchResponse($offset, $limit,$search){
        global $conn;
        $responses = array();
    
        $sql = "SELECT quotes.*,quotes.submit_date as submitdate, quotes_details.*, COUNT(quotes_details.uniqid) AS num_occurrences FROM quotes JOIN quotes_details ON quotes.uniqid = quotes_details.uniqid WHERE quotes.status = 1 AND quotes.active = 0 ";
        
        if(!empty($search)){
            $search = $conn->real_escape_string($search); // Sanitize search string to prevent SQL injection
            $sql .= " And `reviews` LIKE '%$search%' OR `company_info` LIKE '%$search%'";
        }
        $sql .=  " GROUP BY quotes_details.uniqid  ORDER by quotes.submit_date DESC LIMIT $offset, $limit";

        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $responses[] = $row;
            }
        }
        return $responses;
    } 



    public function TotalResponsesCount($search){
        global $conn;
        
        // Query to get the total count of responses
        $sql = "SELECT COUNT(DISTINCT quotes_details.uniqid) AS total_responses 
        FROM quotes 
        JOIN quotes_details ON quotes.uniqid = quotes_details.uniqid 
        WHERE quotes.status = 1 AND quotes.active = 0 ";

        if (!empty($search)) {
            $search = $conn->real_escape_string($search); // Sanitize search string to prevent SQL injection
            $sql .= " AND (`reviews` LIKE '%$search%' OR `company_info` LIKE '%$search%')";
        }

        $total_entries_result = $conn->query($sql);

    
        // Check if the query was successful
        if (!$total_entries_result) {
            // Handle the error, for example:
            die("Error: " . $conn->error);
        }
    
        // Fetch the total count from the first query result
        $total_entries_row = $total_entries_result->fetch_assoc();
        $total_responses = $total_entries_row['total_responses'];
    
        // Return the total count of responses
        return $total_responses;
    }     

    public function FetchTrasactionEntries($uniqid){
        global $conn;
        $trasactions = array();

        $sql = "SELECT * FROM quotes_details WHERE uniqid='".$uniqid."'";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $trasactions[] = $row;
            }
        }

        return $trasactions;
    }

    public function SubmissionsData($offset, $limit, $search) {
        global $conn;
        $submissions = array();
        $total_data = array();
    
        // Construct the SQL query
        $sql = "SELECT q.*, 
                       COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
                       COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
                       COUNT(qd.uniqid) AS occurrences_in_quotes_details,
                       (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS remaining_occurrences
                FROM quotes q
                LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid
                WHERE q.job_no <> 0";
    
        // Adding search conditions if $search is not empty
        if (!empty($search)) {
            $search = $conn->real_escape_string($search); // Sanitize search string to prevent SQL injection
            $sql .= " AND (q.reviews LIKE '%$search%' OR q.company_info LIKE '%$search%')";
        }
    
        $sql .= " GROUP BY q.uniqid ORDER BY q.submit_date DESC LIMIT $offset, $limit";
    
        // Execute the query
        $result = $conn->query($sql);
        
        // Check for errors
        if (!$result) {
            // Handle query execution error
            return false;
        }
    
        // Fetch submission data
        while ($row = $result->fetch_assoc()) {
            $submissions[] = $row;
        }
    
        // Fetch total data
        $sql_total = "SELECT SUM(CASE WHEN qd.not_possible = 1 THEN 1 ELSE 0 END) AS not_possible,
                             SUM(CASE WHEN qd.deleted = 1 THEN 1 ELSE 0 END) AS deleted,
                             COUNT(qd.uniqid) AS occurrences_in_quotes_details,
                             (COUNT(qd.uniqid) - SUM(CASE WHEN qd.not_possible = 1 THEN 1 ELSE 0 END) - SUM(CASE WHEN qd.deleted = 1 THEN 1 ELSE 0 END)) AS remaining_occurrences
                      FROM quotes q
                      LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid
                      WHERE q.job_no <> 0";
    
        $result_total = $conn->query($sql_total);
    
        // Check for errors
        if (!$result_total) {
            // Handle query execution error
            return false;
        }
    
        // Fetch total data
        $total_data = $result_total->fetch_assoc();
    
        // Assemble the data array
        $data = array(
            'submissions' => $submissions,
            'total_data' => $total_data,
        );
    
        return $data;
    }
    
    public function getTotalRecords($search){
        global $conn;
        $sql = "SELECT COUNT(*) AS total_records
        FROM (
            SELECT q.*, 
                   COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
                   COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
                   COUNT(qd.uniqid) AS occurrences_in_quotes_details,
                   (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS remaining_occurrences
            FROM quotes q
            LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid
            WHERE  q.job_no <> 0
           
        ";
        if (!empty($search)) {
            $search = $conn->real_escape_string($search); // Sanitize search string to prevent SQL injection
            $sql .= " and  q.reviews LIKE '%$search%' OR q.company_info LIKE '%$search%'";
        }
        $sql .=' GROUP BY q.uniqid
        ) AS subquery;';
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            return $row['total_records'];
        }
        return 0; // Return 0 if no records found or query fails
    }

    public function FetchQuotes($uniqid){
        global $conn;
        $quotes = array();

        $sql = "SELECT company_info FROM quotes WHERE uniqid='".$uniqid."'";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $quotes[] = $row;
            }
        }

        return $quotes;
    }

}



?>
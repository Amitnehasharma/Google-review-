<?php
include('../config/connection.php');
session_start();

class User 
{
    public function Create($email, $password, $fullName, $dob, $phoneNumber, $files){
        global $conn;
        $sql ="SELECT * FROM users WHERE email = '$email' and is_deleted=0";
        $result = $conn->query($sql);
        if($result->num_rows > 0) {
            $response['error']= "Email already exists. Please choose another one.";
            $response['status']=400; 
            return $response;
        }

        $created_by = $_SESSION['full_name'];
        $last_modification_date = date("Y-m-d H:i:s");
        $uploadDirectory = '../uploads';
        $uniqid      = md5(uniqid());
        if (!file_exists($uploadDirectory)) {
            mkdir($uploadDirectory, 0755, true);
        }

        if (isset($files["profilePic"]) && $files["profilePic"]["error"] == UPLOAD_ERR_OK) {
            $profilePic = uniqid() . "_" . strtolower(str_replace(' ','-',basename($files["profilePic"]["name"]))) ;
            $path = $uploadDirectory . DIRECTORY_SEPARATOR; // upload directory
            $path = $path . strtolower($profilePic);
            move_uploaded_file($files["profilePic"]["tmp_name"], $path);
        }

        $sql = "INSERT INTO users (email, password, full_name, dob, phone_number, role, profile_pic, created_by, last_modification_date, last_modification_by,uniqid) 
                VALUES ('$email', '$password', '$fullName', '$dob', '$phoneNumber', 'user', '$profilePic','$created_by','$last_modification_date','$created_by','$uniqid')";

        
        if ($conn->query($sql) === TRUE) {
            $response['success'] =  "User added successfully";
            $response['status'] =200;
            return $response;
        } else { 
            $response['error'] =  "Error: " . $sql . "<br>" . $conn->error;
            $response['status'] =400;
            return $response;
        }

        // Close database connection
        $conn->close();
    }

    public function ShowAllUsers(){
        global $conn;
        $users = array();

        $sql = "SELECT * FROM users where is_deleted=0 and role='user' ORDER BY id DESC  ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }

        return $users;
    }

    public function FetchUser($id){
        global $conn;
        $users = array();

        $sql = "SELECT * FROM users WHERE uniqid = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $users  = $row;
        } 

        return $users;
    }

    public function UserUpdate($userid,$email, $password, $fullName, $dob, $phoneNumber, $files){
        global $conn;
        $sql ="SELECT * FROM users WHERE email = '$email' and is_deleted=0";
        $result = $conn->query($sql);
        if($result->num_rows > 1) {
            $response['error']= "Email already exists. Please choose another one.";
            $response['status']=400; 
            return $response;
        }

        $created_by = $_SESSION['full_name'];
        $last_modification_date = date("Y-m-d H:i:s");
        $uploadDirectory = '../uploads';
        $uniqid      = md5(uniqid());
        if (!file_exists($uploadDirectory)) {
            mkdir($uploadDirectory, 0755, true);
        }

        if (isset($files["profilePic"]) && $files["profilePic"]["error"] == UPLOAD_ERR_OK) {
            $profilePic = uniqid() . "_" . strtolower(str_replace(' ','-',basename($files["profilePic"]["name"]))) ;
            $path = $uploadDirectory . DIRECTORY_SEPARATOR; // upload directory
            $path = $path . strtolower($profilePic);
            move_uploaded_file($files["profilePic"]["tmp_name"], $path);
        }

       $sql =  "UPDATE users  SET email = '$email', full_name = '$fullName', dob = '$dob', phone_number = '$phoneNumber', role = 'user', 
        created_by = '$created_by', last_modification_date = '$last_modification_date', last_modification_by = '$created_by'";
        
        if (isset($files["profilePic"]) && $files["profilePic"]["error"] == UPLOAD_ERR_OK) {
         $sql .=", profile_pic = '$profilePic'";
        }
        if(!empty($password)){
            $sql .=", password = '$password'";
        }
        $sql .=" WHERE 
        uniqid = '$userid'";
       
        if ($conn->query($sql) === TRUE) {
             
            $response['success']= "User updated successfully";
            $response['status']=200; 
            return $response;
        } else {
             
            $response['error']= "Error: " . $sql . "<br>" . $conn->error;
            $response['status']=400; 
            return $response;
        }

        // Close database connection
        $conn->close();
    }

    public function UserDeleted($userid){
        
        global $conn;

       $sql =  "DELETE FROM users WHERE uniqid = '$userid'";
    
        if ($conn->query($sql) === TRUE) {
            echo "User Deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close database connection
        $conn->close();
    }

    public function checkEmail($email){
        global $conn, $response;
        if(isset($_POST['email'])) {
            $email = $_POST['email'];
            $sql ="SELECT * FROM users WHERE email = '$email' and is_deleted=0";
            $result = $conn->query($sql);
           /// echo $result->num_rows;
            if($result->num_rows > 0) {
                $response['error']=  "Email already exists. Please choose another one.";
            }else{
                $response['success']=''; 
            }
            return json_encode($response);
        }
    }
    public function UserPasination($offset, $limit,$search){
        global $conn,$response;
      
            $sql ="SELECT * FROM users WHERE is_deleted=0 and role='user' ";
            if(!empty($search)){
                $sql .=" And ( email LIKE '%$search%' or `full_name` LIKE '%$search%' ) ";
            }
            $sql .="ORDER BY id DESC LIMIT  $offset, $limit";
            $result = $conn->query($sql);

            
            
            if ($result->num_rows > 0) {
                $response['status']='success';
                $i = 0;
                while ($row = $result->fetch_assoc()) {
                    $users[$i]['uniqid'] = $row['uniqid'];
                    $users[$i]['full_name'] = $row['full_name'];
                    $users[$i]['email'] = $row['email'];
                    $users[$i]['dob'] =  date('d M Y',strtotime($row['dob']));
                    $users[$i]['phone_number'] = $row['phone_number'];
                    $users[$i]['creation_date'] = date('d M Y',strtotime($row['creation_date']));
                    $i++;
                }
                // get total record 
                $sql ="SELECT count(id) as total_row FROM users WHERE is_deleted=0 and role='user' ";
                if(!empty($search)){
                    $sql .=" And ( email LIKE '%$search%' or `full_name` LIKE '%$search%' ) ";
                }
                $result = $conn->query($sql);
                $total_row = $result->fetch_assoc();
                $response['data']=$users;
                $response['totalRow']=$total_row['total_row'];

            }else{
                $response['success']=''; 
                $response['data']=[];
                $response['totalRow']=0;
            }
            return $response;
        
    }
}

?>

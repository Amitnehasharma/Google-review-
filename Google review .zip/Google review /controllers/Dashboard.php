<?php
include('../config/connection.php');
session_start();

class Dashboard 
{
    private $con;

    public function __construct() {
        global $conn;
        $this->con = $conn;
    }
    public function getCurrentProposal(){
        global $conn;
        $data = array();
        $sql = "SELECT COUNT(id) as total FROM quotes WHERE DATE(creation_date) = CURDATE()";
        $result = $this->con->query($sql);
        $data['today_proposal'] = ($result) ? $result->fetch_assoc()['total'] : 0;

        $sql = "SELECT COUNT(id) as total_proposal_week FROM quotes 
                WHERE YEAR(creation_date) = YEAR(CURDATE()) AND WEEK(creation_date) = WEEK(CURDATE())";
        $result = $this->con->query($sql);
        $data['total_proposal_week'] = ($result) ? $result->fetch_assoc()['total_proposal_week'] : 0;
        $sql = "SELECT COUNT(id) as current_month_proposal FROM quotes 
                WHERE MONTH(creation_date) = MONTH(CURDATE()) AND YEAR(creation_date) = YEAR(CURDATE())";
        $result = $this->con->query($sql);
        $data['current_month_proposal'] = ($result) ? $result->fetch_assoc()['current_month_proposal'] : 0;
    
        $sql = "SELECT COUNT(id) as current_year FROM quotes WHERE YEAR(creation_date) = YEAR(CURDATE())";
        $result = $this->con->query($sql);
        $data['current_year'] = ($result) ? $result->fetch_assoc()['current_year'] : 0;
         return $data;
    }
    public function getCurrentResponse() {
        global $conn;
        $data = array();

        
        $sql = "SELECT COUNT(id) as today_response FROM quotes WHERE DATE(submit_date) = CURDATE() AND status != 0";
        $result = $conn->query($sql);
        $data['today_response'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['today_response'] : 0;

        
        $sql = "SELECT COUNT(id) as total_response_week FROM quotes 
                WHERE YEAR(submit_date) = YEAR(CURDATE()) AND WEEK(submit_date) = WEEK(CURDATE()) AND status != 0";
        $result = $conn->query($sql);
        $data['total_response_week'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total_response_week'] : 0;

       
        $sql = "SELECT COUNT(id) as current_month_response FROM quotes 
                WHERE MONTH(submit_date) = MONTH(CURDATE()) AND YEAR(submit_date) = YEAR(CURDATE()) AND status != 0";
        $result = $conn->query($sql);
        $data['current_month_response'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['current_month_response'] : 0;

        $sql = "SELECT COUNT(id) as current_year FROM quotes 
                WHERE YEAR(submit_date) = YEAR(CURDATE()) AND status != 0";
        $result = $conn->query($sql);
        $data['current_year'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['current_year'] : 0;

        return $data;
    }

    public function getActiveJob() {
        $data = array();
        $datalist = array();
        
        if (!$this->con) {
            
            echo "Connection error: " . $this->con->connect_error;
            return $data;
        }

        $sql = "SELECT q.*, 
        COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
        COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
        COUNT(qd.uniqid) AS total_review_delete,
        (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS pending
        FROM quotes q LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid 
        WHERE active = 1  And status=2 GROUP BY q.uniqid ORDER BY q.submit_date DESC LIMIT 10
                ";

        $result = $this->con->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    
                    $data['id'] = $row['id'];
                    $data['uniqid'] = $row['uniqid'];
                    $data['company_name'] = unserialize($row['company_info'])['name'];
                    $data['reviewtodelete'] = $row['total_review_delete'] ;//$total_review_delete;
                    $data['deleted'] = $row['deleted'];//$deleted;
                    $data['not_possible'] = $row['not_possible'];
                    $data['pending'] = $row['pending'];
                    $data['value'] = ($row['review_rate']*$row['total_review_delete']);
                    $data['approval_date'] = date('d-m-Y',strtotime($row['creation_date']));
                    $datalist[]=$data;
                }
            }
        } else {
            // Query execution error
            echo "Query error: " . $this->con->error;
        }
        return $datalist;
    }

    public function getCompletedJob() {
        $data = array();
        $datalist['current_week'] = array();
        $datalist['last_week'] = array();
        $datalist['last_month'] = array();
        $datalist['last_year'] = array();
        
        if (!$this->con) {
            // Connection error
            echo "Connection error: " . $this->con->connect_error;
            return $data;
        }

        $sql = "SELECT q.*, 
        COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
        COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
        COUNT(qd.uniqid) AS total_review_delete,
        (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS pending
        FROM quotes q LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid 
        WHERE  YEAR(complete_date) = YEAR(CURDATE()) AND WEEK(complete_date) = WEEK(CURDATE()) and active = 1  And status=3
        GROUP BY q.uniqid ORDER BY q.submit_date DESC LIMIT 10";

        $result = $this->con->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $data['id'] = $row['id'];
                    $data['uniqid'] = $row['uniqid'];
                    $data['company_name'] = unserialize($row['company_info'])['name'];
                    $data['reviewtodelete'] = $row['total_review_delete'] ;//$total_review_delete;
                    $data['deleted'] = $row['deleted'];//$deleted;
                    $data['not_possible'] = $row['not_possible'];
                    $data['pending'] = $row['pending'];
                    $data['value'] = ($row['review_rate']*$row['total_review_delete']);
                    $data['approval_date'] = date('d-m-Y',strtotime($row['complete_date']));
                    $datalist['current_week'][]=$data;
                }
            }
        }
        $sql = "SELECT q.*, 
        COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
        COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
        COUNT(qd.uniqid) AS total_review_delete,
        (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS pending
        FROM quotes q LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid  WHERE YEAR(complete_date) = YEAR(CURDATE()) AND WEEK(complete_date) = WEEK(CURDATE()) - 1 AND active = 1 AND status = 3 
        GROUP BY q.uniqid ORDER BY q.submit_date DESC LIMIT 10";

        $result = $this->con->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $data['id'] = $row['id'];
                    $data['uniqid'] = $row['uniqid'];
                    $data['company_name'] = unserialize($row['company_info'])['name'];
                    $data['reviewtodelete'] = $row['total_review_delete'] ;//$total_review_delete;
                    $data['deleted'] = $row['deleted'];//$deleted;
                    $data['not_possible'] = $row['not_possible'];
                    $data['pending'] = $row['pending'];
                    $data['value'] = ($row['review_rate']*$row['total_review_delete']);
                    $data['approval_date'] = date('d-m-Y',strtotime($row['complete_date']));
                    $datalist['last_week'][]=$data;
                }
            }
        } 
        $sql = "SELECT q.*, 
        COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
        COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
        COUNT(qd.uniqid) AS total_review_delete,
        (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS pending
        FROM quotes q  LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid  
        WHERE YEAR(complete_date) = YEAR(CURDATE()) AND MONTH(complete_date) = MONTH(CURDATE()) - 1 AND active = 1 AND status = 3
        GROUP BY q.uniqid ORDER BY q.submit_date DESC LIMIT 10;";

        $result = $this->con->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $data['id'] = $row['id'];
                    $data['uniqid'] = $row['uniqid'];
                    $data['company_name'] = unserialize($row['company_info'])['name'];
                    $data['reviewtodelete'] = $row['total_review_delete'] ;//$total_review_delete;
                    $data['deleted'] = $row['deleted'];//$deleted;
                    $data['not_possible'] = $row['not_possible'];
                    $data['pending'] = $row['pending'];
                    $data['value'] = ($row['review_rate']*$row['total_review_delete']);
                    $data['approval_date'] = date('d-m-Y',strtotime($row['complete_date']));
                    $datalist['last_month'][]=$data;
                }
            }
        }
        $sql = "SELECT q.*, 
        COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) AS not_possible,
        COUNT(CASE WHEN qd.deleted = 1 THEN 1 END) AS deleted,
        COUNT(qd.uniqid) AS total_review_delete,
        (COUNT(qd.uniqid) - COUNT(CASE WHEN qd.not_possible = 1 THEN 1 END) - COUNT(CASE WHEN qd.deleted = 1 THEN 1 END)) AS pending
        FROM quotes q LEFT JOIN quotes_details qd ON qd.uniqid = q.uniqid  
        WHERE  YEAR(complete_date) = YEAR(CURDATE())-1    and active = 1  And status=3
        GROUP BY q.uniqid ORDER BY q.submit_date DESC LIMIT 10";

        $result = $this->con->query($sql);
        if ($result) {
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    
                   
                    $data['id'] = $row['id'];
                    $data['uniqid'] = $row['uniqid'];
                    $data['company_name'] = unserialize($row['company_info'])['name'];
                    $data['reviewtodelete'] = $row['total_review_delete'] ;//$total_review_delete;
                    $data['deleted'] = $row['deleted'];//$deleted;
                    $data['not_possible'] = $row['not_possible'];
                    $data['pending'] = $row['pending'];
                    $data['value'] = ($row['review_rate']*$row['total_review_delete']);
                    $data['approval_date'] = date('d-m-Y',strtotime($row['complete_date']));
                    $datalist['last_year'][]=$data;
                }
            }
        }
        return $datalist;
    }

    public function getCurrentConversion() {
        global $conn;
        $data = array();
    
        // Get count and total review_rate of quotes with status 2 for today
        $sql = "SELECT COUNT(id) as today_conversion, SUM(review_rate) as today_review_rate_total  
                FROM quotes 
                WHERE DATE(active_date_time) = CURDATE() AND status = 1 AND active = 1";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $data['today_conversion'] = ($result && $result->num_rows > 0) ? $row['today_conversion'] : 0;
        $data['today_review_rate_total'] = ($result && $result->num_rows > 0 && $row['today_review_rate_total'] !== null) ? $row['today_review_rate_total'] : 0;
    
        // Get count and total review_rate of quotes with status 2 for the current week
        $sql = "SELECT COUNT(id) as total_conversion_week, SUM(review_rate) as total_week_review_rate_total 
                FROM quotes 
                WHERE YEAR(active_date_time) = YEAR(CURDATE()) AND WEEK(active_date_time) = WEEK(CURDATE()) AND status = 1 AND active = 1";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $data['total_conversion_week'] = ($result && $result->num_rows > 0) ? $row['total_conversion_week'] : 0;
        $data['total_week_review_rate_total'] = ($result && $result->num_rows > 0 && $row['total_week_review_rate_total'] !== null) ? $row['total_week_review_rate_total'] : 0;
    
        // Get count and total review_rate of quotes with status 2 for the current month
        $sql = "SELECT COUNT(id) as current_month_conversion, SUM(review_rate) as current_month_review_rate_total 
                FROM quotes 
                WHERE MONTH(active_date_time) = MONTH(CURDATE()) AND YEAR(active_date_time) = YEAR(CURDATE()) AND status = 1 AND active = 1";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $data['current_month_conversion'] = ($result && $result->num_rows > 0) ? $row['current_month_conversion'] : 0;
        $data['current_month_review_rate_total'] = ($result && $result->num_rows > 0 && $row['current_month_review_rate_total'] !== null) ? $row['current_month_review_rate_total'] : 0;
    
        // Get count and total review_rate of quotes with status 2 for the current year
        $sql = "SELECT COUNT(id) as current_year_conversion, SUM(review_rate) as current_year_review_rate_total 
                FROM quotes 
                WHERE YEAR(active_date_time) = YEAR(CURDATE()) AND status = 1 AND active = 1";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        $data['current_year_conversion'] = ($result && $result->num_rows > 0) ? $row['current_year_conversion'] : 0;
        $data['current_year_review_rate_total'] = ($result && $result->num_rows > 0 && $row['current_year_review_rate_total'] !== null) ? $row['current_year_review_rate_total'] : 0;
    
        return $data;
    }    
    
}
?>

<?php
include('../config/connection.php');
session_start();

class QuoteView
{
    // public function Create($place_id, $per_review_charge, $email, $reviews){
    //     $created_by = $_SESSION['full_name'];
    //     $last_modification_date = date("Y-m-d H:i:s");
    //     $uniqid = md5(uniqid());
    //     $sql = "INSERT INTO quotes (place_id, per_review_charge, email, reviews, uniqid)VALUES ('$place_id', '$per_review_charge', '$email', '$reviews','$uniqid')";
    //     global $conn;
    //     if ($conn->query($sql) === TRUE) {
    //         $last_insert_id = $conn->insert_id;
    //         echo json_encode(['status'=>1,'id'=>$last_insert_id,'uniqid'=>$uniqid]);
    //     } else {
    //         echo json_encode(['status'=>0,'error'=>$conn->error]);
    //     }

    //     // Close database connection
    //     $conn->close();
    // }

    public function FetchQuotes($id){
        global $conn;
        $users = array();

        $sql = "SELECT * FROM quotes WHERE uniqid = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $users  = $row;
            // Update the row
            $update_sql = "UPDATE quotes SET is_seen=1 WHERE uniqid='$id'";
            $update_result = $conn->query($update_sql);

            if (!$update_result) {
                // Handle update failure
                return null;
            }
        } 

        return $users;
    }
    public function ProposalDeleted($id){
        global $conn;
        $users = array();

        // Update the row
        $update_sql = "delete from quotes  WHERE uniqid='$id'";
        $update_result = $conn->query($update_sql);

        if (!$update_result) {
            echo 'something went wrong';

        }
        echo 'Proposal deleted successfully';

    }

    /*
    public function ShowAllUsers(){
        global $conn;
        $users = array();

        $sql = "SELECT * FROM users where is_deleted=0 and role='user' ORDER BY id DESC  ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }

        return $users;
    }

    public function FetchUser($id){
        global $conn;
        $users = array();

        $sql = "SELECT * FROM users WHERE uniqid = '$id'";
        $result = $conn->query($sql);
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $users  = $row;
        } 

        return $users;
    }

    public function UserUpdate($userid,$email, $password, $fullName, $dob, $phoneNumber, $files){
        $created_by = $_SESSION['full_name'];
        $last_modification_date = date("Y-m-d H:i:s");
        $uploadDirectory = '../uploads';
        $uniqid      = md5(uniqid());
        if (!file_exists($uploadDirectory)) {
            mkdir($uploadDirectory, 0755, true);
        }

        if (isset($files["profilePic"]) && $files["profilePic"]["error"] == UPLOAD_ERR_OK) {
            $profilePic = uniqid() . "_" . strtolower(str_replace(' ','-',basename($files["profilePic"]["name"]))) ;
            $path = $uploadDirectory . DIRECTORY_SEPARATOR; // upload directory
            $path = $path . strtolower($profilePic);
            move_uploaded_file($files["profilePic"]["tmp_name"], $path);
        }

       $sql =  "UPDATE users  SET email = '$email', full_name = '$fullName', dob = '$dob', phone_number = '$phoneNumber', role = 'user', 
        created_by = '$created_by', last_modification_date = '$last_modification_date', last_modification_by = '$created_by'";
        
        if (isset($files["profilePic"]) && $files["profilePic"]["error"] == UPLOAD_ERR_OK) {
         $sql .=", profile_pic = '$profilePic'";
        }
        if(!empty($password)){
            $sql .=", password = '$password'";
        }
        $sql .=" WHERE 
        uniqid = '$userid'";
        global $conn;
        if ($conn->query($sql) === TRUE) {
            echo "User updated successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close database connection
        $conn->close();
    }

    public function UserDeleted($userid){
        
        global $conn;

       $sql =  "UPDATE users  SET is_deleted = 1  WHERE uniqid = '$userid'";
    
        if ($conn->query($sql) === TRUE) {
            echo "User Deleted successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        // Close database connection
        $conn->close();
    }

    public function checkEmail($email){
        global $conn;
        $response;
        if(isset($_POST['email'])) {
            $email = $_POST['email'];
            $sql ="SELECT * FROM users WHERE email = '$email' and is_deleted=0";
            $result = $conn->query($sql);
            if($result->num_rows == 1) {
                $response['error']=  "Email already exists. Please choose another one.";
            }else{
                $response['success']=''; 
            }
            return json_encode($response);
        }
    }
    public function UserPasination($startIndex,$endIndex,$search){
        global $conn;
        $response;
        if(isset($_POST['startIndex']) && isset($_POST['endIndex'])) {
            // get user data sql 

            $sql ="SELECT * FROM users WHERE is_deleted=0 and role='user' ";
            if(!empty($search)){
                $sql .=" And ( email LIKE '%$search%' or `full_name` LIKE '%$search%' ) ";
            }
            $sql .="ORDER BY id DESC LIMIT $startIndex , 10";
            $result = $conn->query($sql);

            
            
            if ($result->num_rows > 0) {
                $response['status']='success';
                $i = 0;
                while ($row = $result->fetch_assoc()) {
                    $users[$i]['uniqid'] = $row['uniqid'];
                    $users[$i]['full_name'] = $row['full_name'];
                    $users[$i]['email'] = $row['email'];
                    $users[$i]['dob'] =  date('d M Y',strtotime($row['dob']));
                    $users[$i]['phone_number'] = $row['phone_number'];
                    $users[$i]['creation_date'] = date('d M Y',strtotime($row['creation_date']));
                    $i++;
                }
                // get total record 
                $sql ="SELECT count(id) as total_row FROM users WHERE is_deleted=0 and role='user' ";
                if(!empty($search)){
                    $sql .=" And ( email LIKE '%$search%' or `full_name` LIKE '%$search%' ) ";
                }
                $result = $conn->query($sql);
                $total_row = $result->fetch_assoc();
                $response['data']=$users;
                $response['totalRow']=$total_row['total_row'];

            }else{
                $response['success']=''; 
            }
            return json_encode($response);
        }
    }*/
}

?>

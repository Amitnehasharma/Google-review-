$(document).ready(function() {
    // Initialize DataTable
    /* var table = $('#completedJobsTable').DataTable({
        "pageLength": 10, // Set the number of rows displayed per page
        "order": [], // Disable initial sorting
        "dom": 'lfrtip', // Remove 'B' for buttons
        "buttons": [], // No buttons
        "aoColumnDefs": [{
            'bSortable': false,
            'aTargets': [-1] // Disable sorting on the last column
        }]
    }); */
    var table = $('#completedJobsTable').DataTable({
        // DataTable initialization options...
        drawCallback: function(settings) {
            var api = this.api();
            var filteredData = api.rows({ search: 'applied' }).data();
            var total_reveiw_to_delete = 0;
            var total_delete = 0;
            var total_not_possible = 0;
            var total_pending = 0;
            var total_value = 0;

            filteredData.each(function(value, index) {
                // Debugging statements
                console.log("Row " + index + ": " + JSON.stringify(value));

                // Check if the value exists and is not null or empty
                if (!isNaN(parseFloat(value[3]))) {
                    total_reveiw_to_delete += parseFloat(value[3]);
                }
                if (!isNaN(parseFloat(value[4]))) {
                    total_delete += parseFloat(value[4]);
                }
                if (!isNaN(parseFloat(value[5]))) {
                    total_not_possible += parseFloat(value[5]);
                }
                if (!isNaN(parseFloat(value[6]))) {
                    total_pending += parseFloat(value[6]);
                }
                // Check if the 'value' exists and is not null or empty
                if (value[7] !== undefined && value[7] !== null && value[7] !== "") {
                    // Remove currency symbols ('$') and commas (if present) and parse to float
                    var valueWithoutCurrency = parseFloat(value[7].replace(/[^\d.-]/g, ''));
                    // Check if the parsed value is a valid number
                    if (!isNaN(valueWithoutCurrency)) {
                        total_value += valueWithoutCurrency;
                    }
                }
            });

            // Format total value
            var formattedTotalValue = total_value % 1 === 0 ? total_value.toFixed(0) : total_value.toFixed(2);

            // Update total row
            $('.total_color td:nth-child(4)').text(total_reveiw_to_delete.toFixed(0));
            $('.total_color td:nth-child(5)').text(total_delete.toFixed(0));
            $('.total_color td:nth-child(6)').text(total_not_possible.toFixed(0));
            $('.total_color td:nth-child(7)').text(total_pending.toFixed(0));
            $('.total_color td:nth-child(8)').text('$' + formattedTotalValue);
        }
    });

    // Hide DataTables search box
    $(".dataTables_filter").hide();

    // Apply custom date range filter
    $.fn.dataTable.ext.search.push(
        function(settings, data, dataIndex) {
            var min = $('#min').datepicker("getDate");
            var max = $('#max').datepicker("getDate");
            var approvalDateParts = data[2].split('-'); // Split approval date into day, month, year parts
            var approvalDate = new Date(approvalDateParts[2], approvalDateParts[1] - 1, approvalDateParts[0]); // Assuming Approval date is at index 2
    
            if ((min == null && max == null) ||
                (min == null && approvalDate <= max) ||
                (min <= approvalDate && max == null) ||
                (min <= approvalDate && approvalDate <= max)) {
                return true;
            }
            return false;
        }
    );

    // Re-draw the DataTable when date inputs change
    $('.datepicker').datepicker({
        dateFormat: 'yy-mm-dd', // Set date format
        onSelect: function(dateText, inst) {
            table.draw();
            validateDateRange();
        }
    });

    // Function to validate date range
    function validateDateRange() {
        var fromDate = $('#min').datepicker("getDate");
        var toDate = $('#max').datepicker("getDate");

        if (fromDate && toDate) {
            if (fromDate > toDate) {
                alert("To date should be greater than or equal to From date.");
                $('#max').val('');
            }
        }
    }

    // Re-draw the DataTable when search input changes
    $('#mySearch').on('keyup', function() {
        table.search($(this).val()).draw();
    });
});
// document.addEventListener('DOMContentLoaded', function () {

//     const menuButtons = document.querySelectorAll('.nav-link');



//     menuButtons.forEach(button => {

//         button.addEventListener('click', function () {

//             // Toggle the 'active' class on the clicked button

//             button.classList.toggle('active');



//             // Update the image source based on the active state

//             const img = button.querySelector('.menu-img');

//             if (img) {

//                 const src = button.classList.contains('active')

//                     ? img.getAttribute('data-active-src')

//                     : img.getAttribute('data-inactive-src');

//                 img.src = src;

//             }

//         });

//     });

// });

$(document).ready(function() {

    $('.flexSwitchCheckChecked').click(function() {

        // Get the ID of the row

        var rowId = $(this).closest('tr').find('.row-id').val();

    

        // Check if the checkbox is checked

        var isActive = $(this).prop('checked') ? 1 : 0;

        

        // Make an AJAX request to update the 'active' column

        $.ajax({

            url: base_url + "/ajax/update_active.php",

            method: 'POST',

            data: { rowId: rowId, isActive: isActive },

            success: function(response) {

                console.log('Update successful');

            },

            error: function(xhr, status, error) {

                console.error('Error:', error);

            }

        }); 

    });



    $(document).on('click', '.modal_class_response', function() {

        var dynamicValue = $(this).data('dynamic-value');

        var modalId = $(this).closest('.modal').attr('data_modal_id');

        fetchReviews(dynamicValue, modalId);

    });

    

    function fetchReviews(dynamicValue, modalId) {

        

        //console.log(dynamicValue);

        $.ajax({

            url: base_url + "/ajax/fetch_reviews.php", // Replace with your PHP script URL

            type: 'GET',

            data:{dynamicValue: dynamicValue},

            dataType: 'json',

            success: function(data) {

                console.log(data);

                // Assuming data is an array of reviews

                var reviewContainer = $('#' + modalId + ' #pills-profile_'+modalId);

                reviewContainer.empty(); // Clear previous reviews

                $.each(data, function(index, review) {



                    reviewContainer.append(`

                    <div class="model_review_box d-flex align-items-center justify-content-between">

                    <div class="d-flex align-items-center model_inner">

                        

                        ` + (review.selected_reviews.profile_photo_url ?

                        `<img src="` + review.selected_reviews.profile_photo_url + `" alt="">` : '') + `

                        <h6 class="m-0 ps-2">`+review.selected_reviews.authorName+`</h6>

                    </div>

                    <div class="model_date">

                        <p class="m-0">`+review.selected_reviews.formattedDate+`</p>

                    </div>

                    <div>

                        <span>

                        `+review.selected_reviews.ratingHtml+`

                        </span>

                    </div>

                </div>

                    `);

                });

            },

            error: function(xhr, status, error) {

                console.error('Error fetching reviews:', error);

            }

        });

    }  



    var itemsPerPage = 10;

    var currentPage = 1;

    var totalPage = null;



    function updatePagination() {

        var totalPages = Math.ceil(totalPage / itemsPerPage);

        var startPage = Math.max(1, currentPage - 2);

        var endPage = Math.min(startPage + 3, totalPages);

        var paginationHtml = '<button class="Me_Btn non-active prev me-1" ' + (currentPage == 1 ? 'disabled' : '') + '>Prev</button>';

    

        for (var i = startPage; i <= endPage; i++) {

          paginationHtml += '<button class="Me_Btn pageLInk ' + (i === currentPage ? 'active' : 'non-active  ') + '" ' + (i === currentPage ? 'disabled' : '') + '  data-page="' + i + '" search me-1">' + i + '</button>';

        }

        paginationHtml += '<button class="Me_Btn next non-active" ' + (currentPage == totalPages ? 'disabled' : '') + '>Next</button>';

        $('#pagination').html(paginationHtml);

    }



    updatePagination();



    $(document).on('click', '.prev', function (e) {

        e.preventDefault();

        currentPage--;

        updatePagination();

    });



    $(document).on('click', '.next', function (e) {

        e.preventDefault();

        currentPage++;

        updatePagination();

    });



    $(document).on('click','#proposal_searchBtn',function() {

            

         var searchTerm = $('#proposal_searchInput').val().toLowerCase();

         var tab = $(this).data('tab');

         var page = $(this).data('page');



         var limit = $(this).data('limit');



         window.location.href = base_url + "/view/proposal.php?page="+page+"&tab="+tab+"&search="+searchTerm+"&limit="+limit;

    });

    

    $(document).on('click','#searchBtnResponse',function() {

            

        var searchTerm = $('#searchInputResponse').val().toLowerCase();

        var tab = $(this).data('tab');

        var page = $(this).data('page');

        var limit = $(this).data('limit');



        window.location.href = base_url + "/view/proposal.php?page="+page+"&tab="+tab+"&search="+searchTerm+"&limit="+limit;

   });



   $(document).on('change','#proposal-limit',function() {

            

        var searchTerm = $('#searchInputResponse').val().toLowerCase();

        var tab = $(this).data('tab');

        var page = 1//$(this).data('page');

        var limit = $(this).val();



        window.location.href = base_url + "/view/proposal.php?page="+page+"&tab="+tab+"&search="+searchTerm+"&limit="+limit;

    });

    $(document).on('change','#response-limit',function() {

            

        var searchTerm = $('#searchInputResponse').val().toLowerCase();

        var tab = $(this).data('tab');

        var page = 1//$(this).data('page');

        var limit = $(this).val();



        window.location.href = base_url + "/view/proposal.php?page="+page+"&tab="+tab+"&search="+searchTerm+"&limit="+limit;

    });



   $(document).on('click','#pills-proposal-tab',function() {

        window.location.href = base_url + "view/proposal.php?page=1&tab=1&search=&limit=10";

    });

    $(document).on('click','#pills-response-tab',function() {

        window.location.href = base_url + "view/proposal.php?page=1&tab=2&search=&limit=10";

    });







    // Event handler for pagination links

    $('.pagination-link').click(function(e) {

        console.log('Pagination link clicked');

        

        // Remove 'active' class from all pagination links

        $('.pagination-link').removeClass('non-active');



        // Add 'active' class to the clicked pagination link

        $(this).addClass('active');

        

        console.log('Active class added');

    });



});
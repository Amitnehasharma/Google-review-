function validateLoginForm() {
    // Reset error messages
    document.getElementById('usernameError').textContent = '';
    document.getElementById('passwordError').textContent = '';

    // Get values from form
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    var validation_error = 0;

    // Simple email validation
    if (!email || !validateEmail(email)) {
        document.getElementById('usernameError').textContent = 'Please enter a valid email address.';
        
        validation_error=1;
    }
    var password = password.trim();
    if (password.length === 0) {
       document.getElementById('passwordError').textContent = 'Password is required.';
       validation_error=1;
    } else if (password.length < 5) {
       document.getElementById('passwordError').textContent = 'Password must be at least 5 characters long.';
       validation_error=1;
    } 
   
    if(validation_error==1){
        return false;
    }
    return true;
}

// Simple email validation function
function validateEmail(email) {
    // Use a regular expression for basic email validation
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function togglePasswordVisibility() {
  var passwordInput = document.getElementById('password');
 
  if (passwordInput.type === 'password') {
    passwordInput.type = 'text';
  } else {
    passwordInput.type = 'password';
    
  }
}


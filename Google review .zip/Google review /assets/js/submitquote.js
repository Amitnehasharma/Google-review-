
$(document).ready(function () {
    $('.dflex-center').css('display', 'none')
    $('#filter_by_rating').css('display', 'none');
    $('#withoutsubmit').css('display', 'none');
    $('.error-img').css('display', 'none');
    $('.submit_qoute_confirmation').css('display', 'none');
    $('.offerTimerSection').css('display', 'none');
    $('.NewQuote').removeClass('d-none');
    $('.change-element').removeClass('d-flex').addClass('d-none');
    // Declare the uniqid variable
    var uniqid;
    var queryString = window.location.search;
    var number = queryString.substring(1);
    var ratingStatus = [];
    var total_deleted_review = 0;
    function total_review_colculate(reviews) {
        if (reviews.length > 0) {
            var progress = 0;
            var deleted = 0;
            var failed = 0;
            reviews.forEach(function (element) {
                if (element.status == 1) {
                    deleted++;
                } else if (element.status == 2) {
                    failed++;
                } else {
                    progress++;
                }


            });
            $('#progress').text(`${progress} In Bearbeitung`);
            $('#deleted').text(`${deleted} Gelöscht`);
            $('#failed').text(`${failed} Gescheitert`);
        }
    }
    function show_review(reviews) {

        $('#search_result .row.mb-3.me-0').remove();

        if (Array.isArray(reviews) && reviews.length > 0) {
            var html = '';
            var count = 0;
            var progress = 0;
            var deleted = 0;
            var failed = 0;
            var rangeAmt = 0;
            reviews.forEach(function (element) {
                var selectedReviews = element.selected_reviews;
                total_deleted_review += parseInt(selectedReviews.reviewRating);

                var author_name = selectedReviews.authorName;
                rangeAmt = selectedReviews.rangeAmt;
                var profile_photo_url = selectedReviews.profile_photo_url;
                var relative_time_description = selectedReviews.relativeTimeDescription;
                var text = selectedReviews.text;
                var text = selectedReviews.text != null ? selectedReviews.text : '';
                var review_link = selectedReviews.review_link;
                var date = new Date(selectedReviews.formattedDate * 1000); // Convert seconds to milliseconds
                var formattedDate = selectedReviews.formattedDate;
                var formattedTime = selectedReviews.formattedTime;
                var ratingHtml = selectedReviews.ratingHtml;

                var svgCount = (ratingHtml.match(/<svg/g) || []).length;

                var rating = svgCount;
                var rating_html = '';
                var fullStars = Math.floor(rating);
                var decimalPart = rating % 1;
                var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
                var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
                count++;
                // Calculate empty stars
                emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

                for (var i = 0; i < fullStars; i++) {
                    rating_html += `<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">`;
                }
                // Append half star if needed
                if (hasHalfStar) {
                    rating_html += `<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">`;
                }
                for (var i = 0; i < emptyStars; i++) {
                    rating_html += `<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">`;
                }

                // Determine the status
                var status = '';
                if (element.status == 1) {
                    status = '<span class="review_status deleted-color" >Gelöscht</span>';
                } else if (element.status == 2) {
                    status = '<span  class="review_status not-possiable-color">Gescheitert</span>';
                } else {
                    status = '<span  class="review_status pending-color">In Bearbeitung</span>';

                }
                html += `<div class="row review_box  ">
                 <div class="col-sm-12   align-items-center pe-0">
                    <div class='row'>
                       <div class='col-sm-4 d-flex align-items-center  '>
                          <div class='row'>
                             <div class='col-12'>
                                <div class="d-flex review_title_inner align-items-center mr-2">
                                   <img src="`+ profile_photo_url + `" alt="` + author_name + `">
                                   <h6 class="m-0">`+ author_name + `</h6>
                                </div>
                             </div>
                          </div>
                       </div>
                       <div class='col-sm-8 position-relative'>
                          <div class="review_timing">
                             <p>
                                <span class="text-end"> `+ ratingHtml + `</span>
                                <span>`+ formattedTime + `  ` + formattedDate + `</span>
                                `+ status + `
                             </p>
                             <p data-text='${text.length < 150 ? text.substring(0, 150) : text}' class='description'>
                                    ${text.length > 150 ? text.substring(0, 150) + '...' : text}
                                </p>
                                ${text.length > 150 ? '<a href="javascript:void(0)" data-type="read_more" class="read-more-btn">mehr lesen…</a>' : ''}

                          </div>
                       </div>
                    </div>
                 </div>
              </div>`;

            });
            $('#search_result').html(html);
            $('#total-review-count').text(`${count}  Bewertungen eingereicht`);
            var totalReviews = reviews.length;
            var value = reviews[0].review_rate;
            $('#total-review-select-price').text(`${totalReviews} Bewertungen x ${rangeAmt}€`);
            $('#Total_Price').html(`${value}€  <span class="net-price" >Netto</span>`)
            //$('.review_rate_calculation').html(totalReviews+' X $'+value+'=<span style="font-size: 25px;color: #5d46b7;">$'+(totalReviews*value)+'</span>');
        } else {
            var html = `<div class="row mb-3 me-0">
                            <div class="col-12" style="text-align: center;font-size: 30px;margin-top: 20px;">No review found</div>
                        </div>`;
            $('#search_result').html(html);
        }
    }
    $.ajax({
        type: "POST",
        url: base_url + "/ajax/checkUniqIdQuoteDetails.php",
        data: {
            uniqid: number
        },
        dataType: 'json',
        success: function (response) {
            console.log("Response from server:", response);
            if (response.hasOwnProperty('error')) {
                // Handle the case where the uniqid does not exist
                console.log("Uniqid does not exist");
            } else {
                // Hide elements if response status is 2
                if (response.status === 2) {
                    $('.price_per_review_management').hide();
                    $('.price_per_review_management').each(function () {
                        this.style.setProperty('display', 'none', 'important');
                    });;
                    $("#send_qoute_button").hide();
                    $('.shorting_filder_selection').hide();
                    // Loop through each object in the array
                    response.response.forEach(function (review) {
                        // Add the "status" key with a dynamic value
                        review.status = getStatus(review);
                    });
                    var reviews = response.response;
                    ratingStatus = response.response;

                    show_review(reviews);
                    ReviewCalculateAfterDeletion();
                    total_review_colculate(reviews)

                }
            }
        },
        error: function (xhr, status, error) {
            console.error("Error value:", error);
        }
    });
    $(document).on('click', ".read-more-btn", function () {
        var $content = $(this).prev(".description");
        var read_more = $(this).attr("data-type");
        var longtext = $(this).prev(".description").attr('data-text');
        var shorttext = $(this).prev(".description").text();

        /// $content.toggleClass("expanded");
        if (read_more == 'read_more') {
            $(this).text("Lese weniger");
            $(this).attr("data-type", 'read_less')
            $(this).prev(".description").text(longtext);
            $(this).prev(".description").attr('data-text', shorttext);
        } else if (read_more == 'read_less') {
            $(this).text("mehr lesen…");
            $(this).attr("data-type", 'read_more')
            $(this).prev(".description").text(longtext);
            $(this).prev(".description").attr('data-text', shorttext);
        }
    });
    $(document).on('click', '#0', function () {

        $(this).toggleClass('active non-active');
        $('.filter-tab').removeClass('active non-active');

    });
    $(document).on('click', '#filter-review-by-status .filter-tab', function () {
        $(this).toggleClass('active non-active');
        if ($(this).attr('id') != 0) {
            $('#0').removeClass('active non-active');
        }
        if ($('#filter_by_rating .filter-tab.active').length == 3) {
            $('#0').addClass('active non-active');
        }
        // Collect selected filters
        var selectedFilters = [];
        $('#filter-review-by-status .filter-tab.active').each(function () {
            if ($(this).attr('id') != 0) {
                selectedFilters.push($(this).attr('id'));
            }

        });
        filter_shorting_review(selectedFilters);
        if (selectedFilters.length == 0) {
            $('#filter-review-by-status #0').addClass('active non-active')
        }
    });


    // Function to search for the searchString in the text property
    function searchByText(searchString, data) {
        const matchingItems = [];

        data.forEach(item => {
            const text = (item.selected_reviews.authorName + ' ' + item.selected_reviews.text).toLocaleLowerCase();
            if (text.includes(searchString)) {
                matchingItems.push(item);
            }
        });

        return matchingItems;
    }



    $(document).on('keyup', '.customer-search', function () {
        var search = $(this).val().toLocaleLowerCase();
        const matchingItems = searchByText(search, ratingStatus);
        show_review(matchingItems);

    });
    function filter_shorting_review(filter_by_rating) {
        var temp_company_reviews = ratingStatus;
        console.log(temp_company_reviews)
        if (filter_by_rating.length > 0) {
            temp_company_reviews = temp_company_reviews.filter(function (item) {
                return filter_by_rating.includes(item.status.toString());
            });

        }
        show_review(temp_company_reviews);
    }

    function ReviewCalculateAfterDeletion() {
        var company_review = parseFloat($('#search_company_bio').attr('company-review'));
        var company_total_user_review = parseInt($('#search_company_bio').attr('company-total-user-review'));


        var total_user_after_delete = parseInt(company_total_user_review) - parseInt(ratingStatus.length);
        console.log(total_user_after_delete)
        // Check if the attributes are valid numbers
        // if (!isNaN(company_review) || !isNaN(company_total_user_review)) {
        //     console.log("Invalid review or total user review.");
        //     return; // Exit the function early if the attributes are invalid
        // }

        var rating = ((company_review * company_total_user_review) - total_deleted_review) / total_user_after_delete;

        var fullStars = Math.floor(rating);
        var decimalPart = rating % 1;
        var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
        var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        var rating_html = '';

        console.log(fullStars, hasHalfStar, emptyStars);
        for (var i = 0; i < fullStars; i++) {
            rating_html += `<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">`;
        }
        // Append half star if needed
        if (hasHalfStar) {
            rating_html += `<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">`;
        }
        for (var i = 0; i < emptyStars; i++) {
            rating_html += `<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">`;
        }
        $('#ratingUpdate').html(rating_html);
        $('.RatingValueUpdate').html(`${rating.toFixed(1) > 5 ? 5 : rating.toFixed(1)}<small> /5.0</small>`);
    }


});





// Function to determine the status based on the review properties
function getStatus(review) {
    if (review.deleted == 1) {
        return 1;
    } else if (review.not_possible == 1) {
        return 2;
    } else {
        return 3;
    }
}

// Retrieve the value from the hidden input field outside of the loop
/*  $("#send_qoute_button").click(function() {
     $("script").each(function() {
         var scriptContent = $(this).html();
         if (scriptContent.includes("const uniqid")) {
             var matches = scriptContent.match(/const uniqid = '([^']+)';/);
             if (matches) {
                 uniqid = matches[1];
                 return false; // Stop looping once uniqid is found
             }
         }
     });
     console.log("uniqid: " + uniqid); // Debugging statement
     
     var reviewChargeValue = parseFloat($('#reviewChargeValue').val());
     console.log("Review Charge Value Retrieved: " + reviewChargeValue); // Debugging statement
     
     // Loop through each checkbox with class "select_review_for_delection"
     $(".select_review_for_delection:checked").each(function() {
         var reviewBox = $(this).closest(".review_box"); // Get the parent review_box div
         var authorName = reviewBox.find(".review_title_inner h6").text(); // Get author name
         var formattedDate = reviewBox.find(".review_timing span:eq(0)").text(); // Get formatted date
         var formattedTime = reviewBox.find(".review_timing span:eq(1)").text(); // Get formatted time
         var text = reviewBox.find(".review_para p").text(); // Get review text
         var ratingHtml = reviewBox.find(".text-end").html(); // Get rating HTML
         var relativeTimeDescription = reviewBox.find(".year_ago p").text(); // Get relative time description
         var profile_photo_url = reviewBox.find(".review_title_inner img").attr("src");
         var review_link = reviewBox.find('input[name="review_link"]').val();
         // Now you can use these variables as needed
         // console.log("Author Name: " + authorName);
         // console.log("Date: " + formattedDate);
         // console.log("Time: " + formattedTime);
         // console.log("Review Text: " + text);
         // console.log("Rating HTML: " + ratingHtml);
         // console.log("Relative Time Description: " + relativeTimeDescription);
         // console.log("uniqid: " + uniqid);
         // console.log("profile_photo_url: " + profile_photo_url);
         // Here you can perform any further actions with the retrieved data
         // Send the review data to the PHP script using AJAX
         $.ajax({
             type: "POST",
             url: base_url + "/ajax/selectedReviewInsert.php", 
             data: {
                 authorName: authorName,
                 formattedDate: formattedDate,
                 formattedTime: formattedTime,
                 text: text,
                 ratingHtml: ratingHtml,
                 relativeTimeDescription: relativeTimeDescription,
                 uniqid: uniqid,
                 reviewChargeValue: reviewChargeValue,
                 profile_photo_url: profile_photo_url,
                 review_link: review_link
             },
             success: function(response) {
                 console.log("Review inserted successfully:", response);
                 // Perform any further actions after successful insertion
             },
             error: function(xhr, status, error) {
                 console.error("Error inserting review:", error);
                 // Handle errors if insertion fails
             }
         }); 
     });
     $.ajax({
         type: "POST",
         url: base_url + "/ajax/rateInsert.php", 
         data: {
             reviewChargeValue: reviewChargeValue,
             uniqid: uniqid
         },
         success: function(response) {
             console.log("Review charge value inserted successfully:", response);
             Swal.fire({
                 title: 'Request submitted successfully!',
                 // text: 'Your message here',
                 icon: 'success',
                 confirmButtonText: 'OK'
             });
             $("#send_qoute_button").hide();
         },
         error: function(xhr, status, error) {
             console.error("Error inserting review charge value:", error);
             // Handle errors if insertion fails
         }
     }); 
     $('.price_per_review_management').hide();
     $("#send_qoute_button").hide();
     $('.shorting_filder_selection').hide();
     
 }); */








//  --------------- new Quote Code by Amit sharma


$(document).ready(function () {
    $(document).on('click', '#NewQuote', function () {
        $('#loader').removeClass('hidden')
        //$('#search_result').html('<img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />')
        var per_review_charge = $(this).attr('per_review_charge');
        var clicked = $(this).attr('clicked');
        if (clicked != 0) {
            return;
        }

        $(this).attr('clicked', 1);
        $(this).text('Sie erhalten in Kürze Ihr Angebot');
        var offer_expire = $(this).attr('expireIN');
        var per_review_charge_array = JSON.parse(per_review_charge);
        var company_reviews = [];
        var company_info = {};
        var place_id = $(this).attr('data-placeId');
        var postData = {
            place_id: place_id,
            type: 'find_review_for_new_quote',
        };
        // Define the AJAX call
        try {
            $.ajax({
                url: '/view/data/search.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(postData),
                success: function (data) {
                    var response = $.parseJSON(data);
                    var place_id = response.place_id;
                    company_info = {
                        'name': response.name,
                        'formatted_address': response.formatted_address,
                        'rating': response.rating,
                        'user_ratings_total': response.user_ratings_total
                    }
                    var postData = {
                        place_id: place_id,
                        type: 'find_review',
                    };
                    ///$('#search_result').html('<img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />')
                    try {
                        $.ajax({
                            url: '/view/data/search.php',
                            method: 'POST',
                            contentType: 'application/json',
                            data: JSON.stringify(postData),
                            success: function (data) {

                                var response = $.parseJSON(data);
                                response = response.data[0];
                                company_reviews = response.reviews_data;


                                // console.log(company_reviews)
                                // console.log(company_info)

                                var valuesArray = [];

                                $.each(per_review_charge_array, function (index, val) {

                                    valuesArray.push({
                                        range_min: val.range_min,
                                        range_max: val.range_max,
                                        range_amt: val.range_amt
                                    });
                                });
                                //var offer_expire = $.trim($('#offer_expire').val());

                                var postData = {
                                    place_id: place_id,
                                    per_review_amount: valuesArray,
                                    email_id: '',
                                    offer_expire: offer_expire,
                                    company_reviews: company_reviews,
                                    company_info: company_info,
                                    type: 'copy_qoute',
                                };

                                try {
                                    $.ajax({
                                        url: '/view/data/search.php',
                                        method: 'POST',
                                        contentType: 'application/json',
                                        data: JSON.stringify(postData),
                                        success: function (data) {
                                            //$('#NewQuote').attr('clicked',0);
                                            window.location.href = data;

                                        },
                                        error: function (xhr, status, error) {
                                            console.error(xhr, status, error);
                                        }
                                    });
                                } catch (exception) {
                                    console.error('Exception caught:', exception);
                                }

                            },
                            error: function (xhr, status, error) {
                                console.error(xhr, status, error);
                            }
                        });
                    } catch (exception) {
                        console.error('Exception caught:', exception);
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr, status, error);
                }
            });
        } catch (exception) {
            console.error('Exception caught:', exception);
        }
    })
})
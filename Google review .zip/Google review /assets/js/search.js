jQuery(document).ready(function ($) {
    localStorage.clear();
    var company_reviews = [];
    var company_info = {};
    $("#search_company_input").keypress(function () {
        $('#search_company_input_error').hide();
    });
    $("#per_review_amount").keypress(function () {
        $('#per_review_amount_error').hide();
    });
    $("#email_id").keypress(function () {
        $('#email_id_input_error').hide();
    });
    $("#search_company").click(function () {
        $('#search_company_bio,#search_result').html('');
        var postData = {
            key: $('#search_company_input').val(),
            type: 'find_company',
        };
        $('#search_company_input_error').hide();

        if ($.trim($('#search_company_input').val()) == '') {
            $('#search_company_input_error').show();
            return false;
        }


        $('#search_result').html('<img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />')
        // Define the AJAX call
        try {
            $.ajax({
                url: '/view/data/search.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(postData),
                success: function (data) {
                    var response = $.parseJSON(data);
                    $('#search_result').html('');
                    response.forEach(function (element) {
                        var place_id = element.place_id;
                        var address = element.formatted_address
                        var name = element.name;
                        var rating = element.rating;
                        var lines = address.split(',');
                        var formattedAddress = '';
                        for (var i = 0; i < lines.length; i++) {
                            lines[i] = lines[i].trim();
                            formattedAddress += lines[i];

                            if ((i + 1) % 4 === 0 && i + 1 !== lines.length) {
                                formattedAddress += ',<br>';
                            } else {
                                formattedAddress += ', ';
                            }
                        }

                        var rating_html = '';

                        var fullStars = Math.floor(rating);
                        var decimalPart = rating % 1;
                        var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
                        var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

                        // Append empty stars
                        for (var i = 0; i < emptyStars; i++) {
                            rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                            <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                         </svg>`;
                        }
                        // Append half star if needed
                        if (hasHalfStar) {
                            rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                            <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                                            <path d="M15.5 0.000152588L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 0.000152588Z" fill="#FED156"></path>
                                </svg>`;
                        }

                        // Append full stars
                        for (var i = 0; i < fullStars; i++) {
                            rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                             <path d="M15.5 7.62939e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 7.62939e-05Z" fill="#FED156"></path>
                                        </svg>`;
                        }

                        var htmlCode = `
                            <div class="row mb-3">
                                <div class="col-12">
                                    <div class="review_right_box get_the_company_review" style="cursor: pointer;" data-place_id="${place_id}">
                                        <div class="title">
                                            <h6>${name}</h6>
                                        </div>
                                        <div class="rating">
                                            <span>${rating}/5</span>
                                            <span>${rating_html}</span>
                                        </div>
                                        <div class="address">
                                            <span><img src="../assets/img/Maps and Flags.png" alt=""></span>
                                            <span>${formattedAddress}</span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            `;
                        $("#search_result").append(htmlCode);
                    });
                },
                error: function (xhr, status, error) {
                    console.error(xhr, status, error);
                }
            });
        } catch (exception) {
            console.error('Exception caught:', exception);
        }
    });

    $(document).on('click', '.get_the_company_review', function () {
        var place_id = $(this).data('place_id');
        var postData = {
            place_id: place_id,
            review_pagination_id : '',
            type: 'find_review',
        };
        $('#search_result').html('<img src="../assets/img/gif/search_loader.gif" alt="" style="margin: 2vw auto;display: block;" />')
        try {
            $.ajax({
                url: '/view/data/search.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(postData),
                success: function (data) {
                    
                    var response = $.parseJSON(data);
                    response = response.data[0];

                    var html1 = `<div class="row mb-3 shorting_filder_selection">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="d-flex justify-content-end">
                                                <div>
                                                    <div class="custom-select">
                                                        <select class="sort" id="short_by_rating">
                                                            <option value="">Sort by Rating</option>
                                                            <option value="desc">5-1 Star</option>
                                                            <option value="asc">1-5 Star</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div>
                                                    <div class="custom-select">
                                                        <select class="sort" id="short_by_date">
                                                            <option value="">Sort by Date</option>
                                                            <option value="asc">Date Asc</option>
                                                            <option value="desc">Date Desc</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div>
                                                    <div class="custom-select" id="filter_by_rating" style="margin-top: 6px;">
                                                        <div class="filter-tab non-active" id="1">1 Star</div>
                                                        <div class="filter-tab non-active" id="2">2 Star</div>
                                                        <div class="filter-tab non-active" id="3">3 Star</div>
                                                        <div class="filter-tab non-active" id="4">4 Star</div>
                                                        <div class="filter-tab non-active" id="5">5 Star</div>
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                    $('#search_result').html();

                    var address = response.full_address
                    var name = response.name;
                    var company_rating = response.rating;
                    var rating_html = '';
                    var fullStars = Math.floor(company_rating);
                    var decimalPart = company_rating % 1;
                    var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
                    var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

                    company_info  = {
                        'name' : response.name,
                        'formatted_address' : response.full_address,
                        'rating' : response.rating,
                        'user_ratings_total' : response.reviews
                    }

                    // Append empty stars
                    for (var i = 0; i < emptyStars; i++) {
                        rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                        <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                     </svg>`;
                    }
                    // Append half star if needed
                    if (hasHalfStar) {
                        rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                                        <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                                        <path d="M15.5 0.000152588L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 0.000152588Z" fill="#FED156"></path>
                            </svg>`;
                    }

                    // Append full stars
                    for (var i = 0; i < fullStars; i++) {
                        rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 32 32" fill="none">
                                         <path d="M15.5 7.62939e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 7.62939e-05Z" fill="#FED156"></path>
                                    </svg>`;
                    }

                    var html2 = `<div>
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <div class="review_right_box">
                                                <div class="title">
                                                    <h6>`+name+`</h6>
                                                </div>
                                                <div class="rating">
                                                    <span>`+company_rating+`/5</span>
                                                    <span>
                                                        `+rating_html+`
                                                    </span>
                                                </div>
                                                <div class="address">
                                                    <span><img src="../assets/img/Maps and Flags.png" alt=""></span>
                                                    <span>
                                                        `+address+`
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-12 mb-3">
                                            <div class="review_right_box price_per_review_management">
                                                <div class="title">
                                                    <h6>Price Per Review</h6>
                                                </div>
                                                <div class="row mb-2">
                                                    <div class="col-3 p-0 pe-1 rating justify-content-around">Min</div>
                                                    <div class="col-3 p-0 pe-1 rating justify-content-around">Max</div>
                                                    <div class="col-3 p-0 pe-1 rating justify-content-around">Amt</div>
                                                    <div class="col-2 p-0 pe-1 rating"></div>
                                                </div>
                                                <div class="row range-group mb-2 price_per_review_management_0">
                                                    <div class="col-3 p-0 pe-1 rating justify-content-around">
                                                        <span class="amour_inp">
                                                            <input style="width:100%" type="number" id='range_min0'  name="range_min" class="text-center" onchange="checkRangeMin(this)" placeholder="Min">
                                                            <p id="range_min_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                                                        </span>
                                                    </div>
                                                    <div class="col-3 p-0 pe-1 rating justify-content-around">
                                                        <span class="amour_inp">
                                                            <input style="width:100%" type="number"   id='range_max0' name="range_max" class="text-center" onchange="checkRangeMax(this)" placeholder="Max">
                                                            <p id="range_max_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                                                        </span>
                                                    </div>
                                                    <div class="col-3 p-0 pe-1 rating justify-content-around">
                                                        <span class="amour_inp">    
                                                            <input style="width:100%" type="number"   id='range_amt0' name="range_amt" class="text-center" placeholder="Amt">
                                                            <p id="range_amt_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                                                        </span>
                                                    </div>
                                                    <div class="col-2 p-0 pe-1 rating">
                                                        <button class="add_range pin" data-id="0" style="padding: 0.5vw;border-width: 0;background: transparent;">
                                                            <img style="width: 100%;" src="../assets/img/plus.png" alt="">
                                                        </button>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class='error-message'></div>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <div class="review_right_box">
                                                <div class="title">
                                                    <h6>Offer expiration day's </h6>
                                                </div>
                                                <div class="address pt-2 enter_email">
                                                    <input class="text-center w-100" id="offer_expire" value='7' type="text" placeholder="Offer expire in days">
                                                </div>
                                                <p id="offer_expire_input_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                                                
                                            </div>
                                        </div>
                                        <div class="col-12 mb-3">
                                            <div class="review_right_box">
                                                <div class="title">
                                                    <h6>Reviews for proposals</h6>
                                                </div>
                                                <div class="address pt-2 enter_email">
                                                    <input class="text-center w-100" id="email_id" type="email" placeholder="Enter email address">
                                                </div>
                                                <p id="email_id_input_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                                                <div class="pt-2 d-flex align-items-center justify-content-around">
                                                    <button class="send_btn" id="send_qoute_button" data-id="`+place_id+`">Send a quote</button>
                                                    <button class="send_btn pin" id='copy' data-clicked='0' data-id="`+place_id+`"><img src="../assets/img/Url.png" alt=""></button>
                                                    <input type='hidden' id='dynamicLink'>
                                                    <div class="tooltip" id="myTooltip">Copied!</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
                    company_reviews = response.reviews_data;
                    
                    if(response.reviews.length == 0){
                        $('.shorting_filder_selection').hide();
                    }
                    
                    get_more_data(postData,response.reviews_data,html2,html1);

                    // var review_pagination_id = '';
                    
                },
                error: function (xhr, status, error) {
                    console.error(xhr, status, error);
                }
            });
        } catch (exception) {
            console.error('Exception caught:', exception);
        }
    });
    $(document).on('keyup', '#offer_expire', function (event) {
        
        var inputElement = event.target;
        inputElement.value = inputElement.value.replace(/[^0-9]/g, '');
    });

    function get_more_data(postData,reviews_data,html2,html1){
        postData.review_pagination_id = reviews_data[reviews_data.length - 1].review_pagination_id;
        if(postData.review_pagination_id == null){
            $('#search_result').html(html1);
            $('#search_company_bio').html(html2);
            show_review(reviews_data);
            return false;
        }
        
        try {
            $.ajax({
                url: '/view/data/search.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(postData),
                success: function (data) {                        
                    var response = $.parseJSON(data);
                    response = response.data[0];   
                    reviews_data = [...reviews_data, ...response.reviews_data];
                    company_reviews = reviews_data;

                    if(response.reviews_data.length == 0){
                        $('#search_result').html(html1);
                        $('#search_company_bio').html(html2);                        
                        show_review(reviews_data);
                    }else{
                        if(response.reviews_data[response.reviews_data.length - 1].review_rating < 4){
                            get_more_data(postData,reviews_data,html2,html1);                      
                        }else{
                            $('#search_result').html(html1);
                            $('#search_company_bio').html(html2);
                            show_review(reviews_data);
                        }
                    }
                },
                error: function (xhr, status, error) {
                    console.error(xhr, status, error);
                }
            });
        } catch (exception) {
            console.error('Exception caught:', exception);
        }
        
        

        // 
    }
    
    
    
    $(document).on('change', '#short_by_date', function () {
        var short_by_date = $(this).val();
        var filter_by_rating = $('#filter_by_rating').val();
        var short_by_rating = $('#short_by_rating').val();
        filter_shorting_review(filter_by_rating,short_by_date,short_by_rating);
       
    });
    /* $(document).on('change', '#filter_by_rating', function () {        
        var filter_by_rating = $(this).val();
        var short_by_date = $('#short_by_date').val();
        var short_by_rating = $('#short_by_rating').val();
        filter_shorting_review(filter_by_rating,short_by_date,short_by_rating);
    }); */
    $(document).on('click', '#filter_by_rating .filter-tab', function () {
        // Toggle "active" and "non-active" classes for the clicked tab
        $(this).toggleClass('active non-active');
    
        // Collect selected filters
        var selectedFilters = [];
        $('#filter_by_rating .filter-tab.active').each(function() {
            selectedFilters.push($(this).attr('id'));
        });
    
        // Here 'selectedFilters' array will contain the IDs of the active filter tabs
        var short_by_date = $('#short_by_date').val();
        var short_by_rating = $('#short_by_rating').val();
        filter_shorting_review(selectedFilters, short_by_date, short_by_rating);
    });
       
    
    $(document).on('change', '#short_by_rating', function () { 
        var short_by_rating = $(this).val();       
        var filter_by_rating = $('#filter_by_rating').val();
        var short_by_date = $('#short_by_date').val();
        filter_shorting_review(filter_by_rating,short_by_date,short_by_rating);
    });
    
    
    $(document).on('input', '#per_review_amount', function() {
        $(this).val(function(index, value) {
            // Remove any non-numeric characters
            let numericValue = value.replace(/[^0-9.]/g, '');
            
            // Allow only one dot
            if (numericValue.indexOf('.') !== -1) {
              const parts = numericValue.split('.');
              numericValue = parts[0] + '.' + parts.slice(1).join('');
            }
    
            return numericValue;
        });
    });

    var current_price_range = 0;
    $(document).on('click', '.delete_range', function(e) {
        var current_id = $(this).data('id');
        $('.price_per_review_management_' + current_id).each(function() {
            var range_min = parseFloat($(this).find("input[name='range_min']").val());
            var range_max = parseFloat($(this).find("input[name='range_max']").val());
            var range_amt = parseFloat($(this).find("input[name='range_amt']").val());
            localStorage.setItem('range_max',range_max);
        });
        $('.price_per_review_management_'+current_id).remove();
        
    });


    $(document).on('click', '.add_range', function() {
        var validation = 0;
        $('#all_is_required' + current_price_range).remove();
        
        // Check if any field in the current range group is empty
        $('.price_per_review_management_' + current_price_range).each(function() {
            var range_min = parseFloat($(this).find("input[name='range_min']").val());
            var range_max = parseFloat($(this).find("input[name='range_max']").val());
            var range_amt = parseFloat($(this).find("input[name='range_amt']").val());
    
            if (isNaN(range_min) || isNaN(range_max) || isNaN(range_amt)) {
                validation = 1;
            }
        });
    
        if (validation == 1) {
            $('.error-message').html('<p style="color: red;font-size: 13px;">At least add one Price Per Review</p>')
            return false;
        } else {
            // Disable input fields in the current range group
            $('.price_per_review_management_' + current_price_range).each(function() {
                $(this).find("input[name='range_min']").attr('disabled', true);
                $(this).find("input[name='range_max']").attr('disabled', true);
                $(this).find("input[name='range_amt']").attr('disabled', true);
            });
        }
    
        current_price_range++;
        var current_id = $(this).data('id');
        var newSrc = '../assets/img/minus.png';
        $(this).find('img').attr('src', newSrc);
        $(this).removeClass('add_range').addClass('delete_range');
    
        // Get the last maximum value
        var lastMax = parseFloat($('.price_per_review_management_' + (current_price_range - 1)).find("input[name='range_max']").val());
    
        // Create HTML for the new range group
        var html = `<div class="row range-group mb-2 price_per_review_management_` + current_price_range + `">
                        <div class="col-3 p-0 pe-1 rating justify-content-around">
                            <span class="amour_inp">
                                <input style="width:100%" type="number" id='range_min${current_price_range}'  name="range_min" class="text-center" placeholder="Min" onchange="checkRangeMin(this)">
                                <p id="range_min_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                            </span>
                        </div>
                        <div class="col-3 p-0 pe-1 rating justify-content-around">
                            <span class="amour_inp">
                                <input style="width:100%" type="number" id='range_max${current_price_range}'  name="range_max" class="text-center" placeholder="Max" onchange="checkRangeMax(this)">
                                <p id="range_max_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                            </span>
                        </div>
                        <div class="col-3 p-0 pe-1 rating justify-content-around">
                            <span class="amour_inp">    
                                <input style="width:100%" type="number" id='range_amt${current_price_range}'  name="range_amt" class="text-center" placeholder="Amt">
                                <p id="range_amt_error" style="color: red;font-size: 13px;padding-left: 10px;display: none;"></p>
                            </span>
                        </div>
                        <div class="col-2 p-0 pe-1 rating">
                            <button class="add_range pin" data-id="` + current_price_range + `" style="padding: 0.5vw;border-width: 0;background: transparent;">
                                <img style="width: 100%;" src="../assets/img/plus.png" alt="">
                            </button>
                        </div>
                    </div>`;
    
        // Append the new range group
        $('.price_per_review_management').append(html);
    });
    
    
    

    $(document).on('click', '#send_qoute_button', function() {
        $('#offer_expire_input_error').hide();
        var valuesArray = [];
        var validation_error= 0;
        // Loop through each set of fields
        $(".range-group").each(function(index,val) {
            // Get values of each field in the current set
            var rangeMin = $(this).find("input[name='range_min']").val();
            var rangeMax = $(this).find("input[name='range_max']").val();
            var rangeAmt = $(this).find("input[name='range_amt']").val();
            if((rangeMin==''||rangeMax==''||rangeAmt=='' )&&index==0){
                validation_error=1;
                
            }
            // Create an object for each set of values and push it to the array
            valuesArray.push({
                range_min: rangeMin,
                range_max: rangeMax,
                range_amt: rangeAmt
            });
        });
        if (validation_error==1) {
            $('.error-message').html('<p style="color: red;font-size: 13px;">At least add one Price Per Review</p>')
        }
        var place_id = $(this).data('id');
        // var per_review_amount = $('#per_review_amount').val();
        var email_id = $.trim($('#email_id').val());
        var offer_expire = $.trim($('#offer_expire').val());
        $('#email_id_input_error,#per_review_amount_error').hide();
        var error = 0;
        var offer_expire_error = 0;
        if(email_id == ''){
            $('#email_id_input_error').html('Email is required');
            $('#email_id_input_error').show();
            error = 1;
        }else{
            var regex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;

            if (!regex.test(email_id)) {
                $('#email_id_input_error').html('Please enter a valid email');
                $('#email_id_input_error').show();
                error = 1;
            }
        }
        if(offer_expire==''){
            $('#offer_expire_input_error').html('Offer expire is required');
            $('#offer_expire_input_error').show();
            offer_expire_error = 1;
        }
        if(error == 1 || validation_error==1 || offer_expire_error==1 ){
            return false;
        }
        var postData = {
            place_id: place_id,
            per_review_amount : valuesArray,
            email_id : email_id,
            offer_expire : offer_expire,
            company_reviews : company_reviews,
            company_info : company_info,
            type: 'send_qoute',
        };
        try {
            $.ajax({
                url: '/view/data/search.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(postData),
                success: function (data) {
                    Swal.fire({
                        title: 'Quote sent successfully!',
                        // text: 'Your message here',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    });
                },
                error: function (xhr, status, error) {
                    console.error(xhr, status, error);
                }
            });
        } catch (exception) {
            console.error('Exception caught:', exception);
        }

    });
    $(document).on('click', '#copy', function() {
        var clicked = $(this).attr('data-clicked');
        
        $('#email_id_input_error').hide();
        $('#offer_expire_input_error').hide();

        var valuesArray = [];
        var validation_error= 0;
        // Loop through each set of fields
        $(".range-group").each(function(index ,val) {
            // Get values of each field in the current set
            var rangeMin = $(this).find("input[name='range_min']").val();
            var rangeMax = $(this).find("input[name='range_max']").val();
            var rangeAmt = $(this).find("input[name='range_amt']").val();
            if((rangeMin==''||rangeMax==''||rangeAmt=='' )&&index==0){
                validation_error=1;
                
            }
            // Create an object for each set of values and push it to the array
            valuesArray.push({
                range_min: rangeMin,
                range_max: rangeMax,
                range_amt: rangeAmt
            });
        });
        var offer_expire = $.trim($('#offer_expire').val());
        var offer_expire_error = 0;
        
        if(offer_expire==''){
            $('#offer_expire_input_error').html('Offer expire is required');
            $('#offer_expire_input_error').show();
            offer_expire_error = 1;
        }
        if (validation_error==1) {
            $('.error-message').html('<p style="color: red;font-size: 13px;">At least add one Price Per Review</p>');
            return false;
        }
        if(offer_expire_error==1){
            return false;
        }
        if(clicked==1){
            return;
        }
        $(this).attr('data-clicked',1);
        var place_id = $(this).data('id');
        // var per_review_amount = $('#per_review_amount').val();
        //var email_id = $.trim($('#email_id').val());
        $('#email_id_input_error,#per_review_amount_error,#error-message').hide();

        var postData = {
            place_id: place_id,
            per_review_amount : valuesArray,
            email_id : '',
            offer_expire : offer_expire,
            company_reviews : company_reviews,
            company_info : company_info,
            type: 'copy_qoute',
        };

        try {
            $.ajax({
                url: '/view/data/search.php',
                method: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(postData),
                success: function (data) {
                    
                    $('#dynamicLink').val(data);
                    $(this).attr('data-clicked',0);
                    CopyTheLink();

                    // Swal.fire({
                    //     title: 'Link Copy successfully!',
                    //     icon: 'success',
                    //     confirmButtonText: 'OK'
                    // });
                },
                error: function (xhr, status, error) {
                    console.error(xhr, status, error);
                }
            });
        } catch (exception) {
            console.error('Exception caught:', exception);
        }

    });

      

    function filter_shorting_review(filter_by_rating,short_by_date,short_by_rating){
        var temp_company_reviews = company_reviews;
        /* if(filter_by_rating != ''){
            temp_company_reviews = company_reviews.filter(function(item) {
                return item.rating === parseInt(filter_by_rating);
            });
        } */
         // Filter by rating
        if (filter_by_rating.length > 0) {
            temp_company_reviews = temp_company_reviews.filter(function(item) {
                return filter_by_rating.includes(item.review_rating.toString());
            });
        }
        
        if(short_by_date == 'asc'){
            temp_company_reviews.sort(function(a, b) {
                return a.review_timestamp - b.review_timestamp;
            }); 
        }
        if(short_by_date == 'desc'){
            temp_company_reviews.sort(function(a, b) {
                return b.review_timestamp - a.review_timestamp;
            });
        }

        if(short_by_rating == 'asc'){
            temp_company_reviews.sort(function(a, b) {
                return a.rating - b.review_rating;
            });  
        }
        if(short_by_rating == 'desc'){
            temp_company_reviews.sort(function(a, b) {
                return b.rating - a.review_rating;
            });
        }
        show_review(temp_company_reviews);
    }
    function show_review(reviews){


        $('#search_result .row.mb-3.me-0').remove();
        if(reviews.length > 0){
            reviews.forEach(function (element) {
                var author_name = element.author_title;
                var profile_photo_url = element.author_image;
                var relative_time_description = element.review_datetime_utc;
                var text = element.review_text;
                var date = new Date(element.review_timestamp * 1000); // Convert seconds to milliseconds
                var formattedDate = $.format.date(date, 'yyyy-MM-dd');
                var formattedTime = $.format.date(date, 'HH:mm a');

                var rating = element.review_rating;
                var rating_html = '';
                var fullStars = Math.floor(rating);
                var decimalPart = rating % 1;
                var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
                var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

                // Append empty stars
                for (var i = 0; i < emptyStars; i++) {
                    rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                </svg>`;
                }
                // Append half star if needed
                if (hasHalfStar) {
                    rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                    <path d="M15.5 6.10352e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 6.10352e-05Z" fill="#E2E2E2"></path>
                                    <path d="M15.5 0.000152588L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 0.000152588Z" fill="#FED156"></path>
                        </svg>`;
                }

                // Append full stars
                for (var i = 0; i < fullStars; i++) {
                    rating_html += `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                                    <path d="M15.5 7.62939e-05L18.98 11.0558H30.2414L21.1307 17.8886L24.6107 28.9443L15.5 22.1115L6.38933 28.9443L9.8693 17.8886L0.758624 11.0558H12.02L15.5 7.62939e-05Z" fill="#FED156"></path>
                                </svg>`;
                }

                var html = `<div class="row mb-3 me-0">
                            <div class="col-12">
                                <div class="row review_box">
                                    <div class="col-lg-8 pe-0">
                                        <div class="d-flex review_title_inner align-items-center">
                                            <img src="`+ profile_photo_url + `" alt="` + author_name + `">
                                            <h6 class="m-0">`+ author_name + `</h6>
                                        </div>
                                        <div class="review_timing">
                                            <b>Date:</b>
                                            <span>`+ formattedDate + `</span>
                                            <span>`+ formattedTime + `</span>
                                        </div>
                                        <div class="review_para">
                                            <p>`+ text + `</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div>
                                            <div class="text-end">`+ rating_html + `</div>
                                            <div class="year_ago">
                                                <p class="m-0">`+ relative_time_description + `</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>`;
                    $('#search_result').append(html);
            });
        }else{
            var html = `<div class="row mb-3 me-0">
                            <div class="col-12" style="text-align: center;font-size: 30px;margin-top: 20px;">No review found</div>
                        </div>`;
            $('#search_result').append(html);
        }

    }
    
});

// Function to check if the minimum value is greater than the maximum value
function checkRangeMin(input) {
    // Clear any existing error messages
    $('.error-message').html('');

    // Get the value of the current input
    var thisInputValue = parseFloat(input.value);
    var rangeMinInput = input.parentElement.parentElement.parentElement.previousElementSibling.querySelector("input[name='range_max']");
    var rangeMin = parseFloat(rangeMinInput.value);
    if(thisInputValue>rangeMin){
        localStorage.clear();
    }
    // Loop through each range group
    $(".range-group").each(function(index, val) {
        // Get the values of range_min and range_max inputs in the current set
        var rangeMin = parseFloat($(this).find("input[name='range_min']").val());
        var rangeMax = parseFloat($(this).find("input[name='range_max']").val());
        
        // Check if the input value falls within the range between rangeMin and rangeMax
        if (!isNaN(thisInputValue) && thisInputValue >= rangeMin && thisInputValue <= rangeMax) {
            input.value = '';
            $('.error-message').html('<p style="color: red;font-size: 13px;">Maximum value must be greater than the previous maximum value.</p>');
            // You can break the loop if the condition is met
            return false;
        }
    });
}



function checkRangeMax(input) {
    $('.error-message').html('');
    var thisInputValue = parseFloat(input.value);
    var rangeMinInput = input.parentElement.parentElement.previousElementSibling.querySelector("input[name='range_min']");
    var lastRangeMinValue = parseFloat(rangeMinInput.value);
    var lastDeletedRange = localStorage.getItem('range_max');

    // Check if the input value is less than the last rangeMin value
    if (thisInputValue < lastRangeMinValue) {
        input.value = '';
        $('.error-message').html('<p style="color: red;font-size: 13px;">Maximum value must be greater than the previous maximum value.</p>');
        return; // Stop further execution if the condition is met
    }

    // Check if the last deleted range exists and if the input value is less than it
    if (lastDeletedRange !== null && thisInputValue > parseFloat(lastDeletedRange)) {
        input.value = '';
        $('.error-message').html('<p style="color: red;font-size: 13px;">Maximum value must be greater than the previous maximum value.</p>');
        return; // Stop further execution if the condition is met
    }
}





function CopyTheLink(){
    var linkField = document.getElementById('dynamicLink');

    linkField.type = 'text';
    linkField.select();
    linkField.setSelectionRange(0, 99999); // For mobile devices
    
    // Copy the selected text
    document.execCommand('copy');

    $('.error-message').hide();
    
    // Once the text is copied, you can hide the input element again if needed
    linkField.type = 'hidden';
    var tooltip = document.getElementById("myTooltip");
    tooltip.className = "tooltip show";
    setTimeout(function() {
        tooltip.className = "tooltip";
    }, 1000);
}

$(document).ready(function () {
  $(document).on('click', ".ProposalDelete", function (e) {
    e.preventDefault();
    var id = $(this).attr('id');
    if (id != undefined) {
      Swal.fire({
        title: "Are you sure?",
        text: "Are you sure you want to delete this user?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
          var formData = new FormData();
          formData.append('id', id);
          formData.append('status', 1);
          $.ajax({
            type: "POST",
            url: base_url + "/ajax/proposal.php",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
              Swal.fire({
                title: "Deleted!",
                text: response,
                icon: "success"
              });
              $('#remove-row' + id).remove();
              // Optionally, you can redirect or update the UI after successful submission
            },
            error: function (error) {

              Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Something went wrong!",
              });
            }
          });

        }
      });

    }

  });
})

function copyLink(linkElement) {
  var copyTooltip = document.getElementById('copyTooltip');

  // Create a temporary input element to hold the link
  var tempInput = document.createElement('input');
  tempInput.setAttribute('value', linkElement.getAttribute('data-link'));
  document.body.appendChild(tempInput);

  // Select the link text and copy it to the clipboard
  tempInput.select();
  document.execCommand('copy');

  // Remove the temporary input element
  document.body.removeChild(tempInput);

  // Change the text of the link to "Copied"
  linkElement.textContent = 'Copied';

  // Show the tooltip
  copyTooltip.style.visibility = 'visible';

  // Hide the tooltip after 2 seconds
  setTimeout(function () {
    copyTooltip.style.visibility = 'hidden';
    // Change the text of the link back to "Copy Link"
    linkElement.textContent = 'Copy Link';
  }, 2000);
}


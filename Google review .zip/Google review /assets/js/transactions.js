/* $(document).ready(function() {
    $('.sub_rating_box:first').removeClass('inner_bottom');
    
    $('.sub_rating_box').click(function(){
        var transactionId = $(this).attr('id');
        
        // AJAX call
        $.ajax({
            url: base_url + "/ajax/getTransactions.php",
            type: 'POST',
            data: { transactionId: transactionId },
            success: function(data) {
                
                var emailContainer = $('.middle_email_inbox');
                emailContainer.empty(); // Clear previous reviews
                
                try {
                    data = JSON.parse(data); // Parse JSON response
                    if (Array.isArray(data)) {
                        data.forEach(function(email) {
                            emailContainer.append(` 
                                <div class="sub_rating_box inner_bottom middle_col" id="${email.id}">
                                    <div class="review_timing third mb-3 py-0 d-flex">
                                        <b class="m-0 pe-2">Email date :</b>
                                        <span class="m-0">${email.trans_date}</span>
                                    </div>
                                    <div class="review_timing third py-0 d-flex">
                                        <b class="m-0 pe-2">Subject:</b>
                                        <span class="m-0 pe-0">${email.subject}</span>
                                    </div>
                                </div>
                            `);
                        });
                        $('.middle_email_inbox .sub_rating_box:first').removeClass('inner_bottom');

                        $('.middle_col').click(function() {
                            var middleColId = $(this).attr('id');

                            $('.email_body').empty();
                            // AJAX call for the middle_col div
                            $.ajax({
                                url: base_url + "/ajax/getTransactionEmailBody.php",
                                type: 'POST',
                                data: { middleColId: middleColId },
                                success: function(response) {
                                    var responseData = JSON.parse(response);
                                    $('.email_body').empty();
                                    // Append body HTML
                                    $('.email_body').append(`<div>${responseData[0].body}</div>`);
                                },
                                error: function(xhr, status, error) {
                                    // Handle errors here
                                    console.error(error);
                                }
                            });
                        });
                    } else {
                        console.error("Data is not an array:", data);
                    }
                } catch (e) {
                    console.error("Error parsing JSON:", e);
                }
            },
            error: function(xhr, status, error) {
                // Handle errors here
                console.error("AJAX error:", error);
            }
        }); 
    });
    $('.sub_rating_box:first').click();
    setTimeout(function() {
        $('.middle_email_inbox .sub_rating_box:first').trigger('click');
    }, 1000);

});
 */

$(document).ready(function() {
    var previousClickedSubRatingBox = null;
    var previousClickedMiddleCol = null;

    // Function to remove 'inner_bottom' class from the previously clicked sub_rating_box
    function removeInnerBottomFromPreviousSubRatingBox() {
        if (previousClickedSubRatingBox !== null) {
            previousClickedSubRatingBox.addClass('inner_bottom');
        }
    }

    // Function to remove 'inner_bottom' class from the previously clicked middle_col
    function removeInnerBottomFromPreviousMiddleCol() {
        if (previousClickedMiddleCol !== null) {
            previousClickedMiddleCol.addClass('inner_bottom');
        }
    }

    $('.sub_rating_box:first').removeClass('inner_bottom');
    
    // Flag to track if it's the first click
    var isFirstClick = true;

    $('.sub_rating_box').click(function(){
        var transactionId = $(this).attr('id');
        
        // Empty email body on the first click
        if (isFirstClick) {
            $('.email_body').empty();
            isFirstClick = false;
        } else {
            // Remove 'inner_bottom' class from the previously clicked sub_rating_box
            removeInnerBottomFromPreviousSubRatingBox();
        }

        // Remove 'inner_bottom' class from the current sub_rating_box
        $(this).removeClass('inner_bottom');
        
        // Store the current sub_rating_box as the previously clicked one
        previousClickedSubRatingBox = $(this);

        // AJAX call
        $.ajax({
            url: base_url + "/ajax/getTransactions.php",
            type: 'POST',
            data: { transactionId: transactionId },
            success: function(data) {
                var emailContainer = $('.middle_email_inbox');
                emailContainer.empty(); // Clear previous reviews
                
                try {
                    data = JSON.parse(data); // Parse JSON response
                    if (Array.isArray(data)) {
                        data.forEach(function(email) {
                            emailContainer.append(` 
                                <div class="sub_rating_box inner_bottom middle_col" id="${email.id}">
                                    <div class="review_timing third mb-3 py-0 d-flex">
                                        <b class="m-0 pe-2">Email date :</b>
                                        <span class="m-0">${email.trans_date}</span>
                                    </div>
                                    <div class="review_timing third py-0 d-flex">
                                        <b class="m-0 pe-2">Subject:</b>
                                        <span class="m-0 pe-0">${email.subject}</span>
                                    </div>
                                </div>
                            `);
                        });

                        // Remove 'inner_bottom' class from the first '.sub_rating_box' element
                        $('.middle_email_inbox .sub_rating_box:first').removeClass('inner_bottom');

                        // Click event handler for '.middle_col' elements
                        $('.middle_col').click(function() {
                            // Remove 'inner_bottom' class from the previously clicked middle_col
                            removeInnerBottomFromPreviousMiddleCol();
                            
                            // Remove 'inner_bottom' class from the current middle_col
                            $(this).removeClass('inner_bottom');
                            
                            // Store the current middle_col as the previously clicked one
                            previousClickedMiddleCol = $(this);

                            var middleColId = $(this).attr('id');
                            
                            // Empty email body
                            $('.email_body').empty();

                            // AJAX call for the middle_col div
                            $.ajax({
                                url: base_url + "/ajax/getTransactionEmailBody.php",
                                type: 'POST',
                                data: { middleColId: middleColId },
                                success: function(response) {
                                    var responseData = JSON.parse(response);
                                    
                                    // Append email body to '.email_body' element
                                    $('.email_body').empty().append(`<div>${responseData[0].body}</div>`);
                                },
                                error: function(xhr, status, error) {
                                    // Handle errors here
                                    console.error(error);
                                }
                            });
                        });
                    } else {
                        console.error("Data is not an array:", data);
                    }
                } catch (e) {
                    console.error("Error parsing JSON:", e);
                }
            },
            error: function(xhr, status, error) {
                // Handle errors here
                console.error("AJAX error:", error);
            }
        }); 
    });

    // Trigger click event on the first '.sub_rating_box' element
    $('.sub_rating_box:first').click();

    // Trigger click event on the first '.middle_email_inbox .sub_rating_box' element after a delay
    setTimeout(function() {
        $('.middle_email_inbox .sub_rating_box:first').trigger('click');
    }, 1000);

});

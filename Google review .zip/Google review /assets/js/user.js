$(document).ready(function () {
  localStorage.clear();
  $('.datepicker').datepicker({
    dateFormat: 'yy-mm-dd', // Set date format,
    maxDate: '-18Y',

  });
  $(document).on("keydown", ".datepicker", function (e) {
    e.preventDefault();
  }).attr("readonly", "readonly");

  $.validator.addMethod("customEmail", function (value, element) {
    return this.optional(element) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }, "Please enter a valid email address.");
  $.validator.addMethod("nameValid", function (value, element) {
    //return true;
    return this.optional(element) || /^(?!\s).+(?<!\s)$/.test(value);
  }, "Please enter your full name");
  $('#AddUser').validate({
    rules: {
      email: {
        required: true,
        email: true,
        customEmail: true
      },
      password: {
        required: true
      },
      fullName: {
        required: true,
        nameValid: true
      },
      phoneNumber: {
        required: true,
        maxlength: 12,
        minlength: 10
      },
      dob: {
        required: true,
        date: true
      }, profilePic: {
        required: true,
        extension: "jpg|jpeg|png" // Add the allowed file extensions
      }
    },
    messages: {
      email: {
        required: 'Please enter your email address.',
        email: 'Please enter a valid email address.'
      },
      password: {
        required: 'Please enter your password.'
      },
      fullName: {
        required: 'Please enter your full name.'
      },
      phoneNumber: {
        required: 'Please enter your phone number.',
        minlength: 'Phone number must be exactly 10 digits.',
        maxlength: 'Phone number must be exactly 12 digits.'
      },
      dob: {
        required: 'Please enter your date of birth.',
        date: 'Please enter a valid date of birth.'
      },
      profilePic: {
        required: 'Please choose a file.',
        extension: 'Please choose a valid file with JPG, JPEG, PNG, extension.'
      }
    },
    errorPlacement: function (error, element) {
      error.addClass('error');
      error.insertAfter(element);
    },
    submitHandler: function (form) {
      let errorExit = localStorage.getItem('errorExit');
      if (errorExit == 1) {
        return false;
      }
      // Form is valid, submit the form
      var formData = new FormData(form);
      formData.append('status', 1);

      $.ajax({
        type: "POST",
        url: base_url + "/ajax/user.php",
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (response) {
          if (response.status == 200) {
            Swal.fire({
              title: "Good job!",
              text: response.success,
              icon: "success"
            });
            localStorage.clear();
            setTimeout(function () { window.location.href = base_url + '/view/users.php' }, 2000);
          } else {
            Swal.fire({
              icon: "error",
              title: "Oops...",
              text: response.error,
            });
          }



        },
        error: function (error) {
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Something went wrong!",
          });
        }
      });
    }
  });



  $('#EditUser').validate({
    rules: {
      email: {
        required: true,
        email: true
      },
      fullName: {
        required: true
      },
      phoneNumber: {
        required: true,
        minlength: 10,
        maxlength: 12
      },
      dob: {
        required: true,
        date: true
      }
    },
    messages: {
      email: {
        required: 'Please enter your email address.',
        email: 'Please enter a valid email address.'
      },
      fullName: {
        required: 'Please enter your full name.'
      },
      phoneNumber: {
        required: 'Please enter your phone number.',
        minlength: 'Phone number must be exactly 10 digits.',
        maxlength: 'Phone number must be exactly 12 digits.'
      },
      dob: {
        required: 'Please enter your date of birth.',
        date: 'Please enter a valid date of birth.'
      }
    },
    errorPlacement: function (error, element) {
      error.addClass('error');
      error.insertAfter(element);
    },
    submitHandler: function (form) {
      let errorExit = localStorage.getItem('errorExit');
      if (errorExit == 1) {
        return false;
      }
      // Form is valid, submit the form
      var formData = new FormData(form);
      formData.append('status', 2);

      $.ajax({
        type: "POST",
        url: base_url + "/ajax/user.php",
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        success: function (response) {
          if (response.status == 200) {
            Swal.fire({
              title: "Good job!",
              text: response.success,
              icon: "success"
            });
            localStorage.clear();
            setTimeout(function () { window.location.href = base_url + '/view/users.php' }, 2000);
          } else {
            Swal.fire({
              icon: "error",
              title: "Oops...",
              text: response.error,
            });
          }

          // Optionally, you can redirect or update the UI after successful submission
        },
        error: function (error) {
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Something went wrong!",
          });
        }
      });
    }
  });


  $(document).on('click', ".userDelete", function (e) {
    e.preventDefault();
    var userId = $(this).attr('id');
    if (userId != undefined) {
      Swal.fire({
        title: "Are you sure?",
        text: "Are you sure you want to delete this user?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
          var formData = new FormData();
          formData.append('userId', userId);
          formData.append('status', 3);
          $.ajax({
            type: "POST",
            url: base_url + "/ajax/user.php",
            data: formData,
            contentType: false,
            processData: false,
            success: function (response) {
              Swal.fire({
                title: "Deleted!",
                text: response,
                icon: "success"
              });
              $('#remove-row' + userId).remove();
              // Optionally, you can redirect or update the UI after successful submission
            },
            error: function (error) {

              Swal.fire({
                icon: "error",
                title: "Oops...",
                text: "Something went wrong!",
              });
            }
          });

        }
      });

    }

  });
});
function previewImage() {
  var input = document.getElementById('profilePic');
  var preview = document.getElementById('imagePreview');

  var file = input.files[0];

  if (file) {
    var reader = new FileReader();

    reader.onload = function (e) {
      preview.src = e.target.result;
      preview.classList.remove('d-none');
    };

    reader.readAsDataURL(file);
  } else {
    preview.src = ''; // Clear the preview if no file is selected
  }
}

function checkEmailAvailability() {
  var email = $('#email').val().trim();
  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  $('#emailerror').html('');
  localStorage.setItem('errorExit', 0);
  if (emailRegex.test(email)) {
    $.ajax({
      type: 'POST',
      dataType: 'json',
      url: base_url + "/ajax/user.php",
      data: { email: email, status: 4 },
      success: function (response) {
        if (response.error) {
          localStorage.setItem('errorExit', 1);
          $('#email-error').remove();
          $('#emailerror').html(response.error);
        }

      }
    });
  }
}
function validateEmail(email) {
  // Use a regular expression for basic email validation
  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}
$(document).ready(function () {
  // var data = [];
  // var totalPage = null;

  // var itemsPerPage = 10;
  // var currentPage = 1;
  //var currentPage = 1;

  // function updateTable(page) {
  //   var startIndex = (page - 1) * itemsPerPage;
  //   var endIndex = parseInt(startIndex) + parseInt(itemsPerPage);
  //   var search = $('#user-search').val();
  //   var formData = new FormData();
  //   formData.append('startIndex', startIndex);
  //   formData.append('endIndex', endIndex);
  //   formData.append('search', search);
  //   formData.append('itemsPerPage', itemsPerPage);
  //   formData.append('status', 10);
  //   $.ajax({
  //     type: "POST",
  //     url: base_url + "/ajax/user.php",
  //     data: formData,
  //     dataType: 'json',
  //     contentType: false,
  //     processData: false,
  //     success: function (response) {
  //       $('#userTable tbody').empty();
  //       data = response.data;
  //       totalPage = response.totalRow;
  //       updatePagination();
  //       // Populate the table with data for the current page
  //       var index = 0;
  //       if(data.length>0){
  //         for (var i = 0; i < data.length; i++) {
  //           var tableHtml = `<tr id='remove-row${data[index].uniqid}'>
  //                           <td scope="row">${index + 1}</td>
  //                           <td>${data[index].full_name}</td>
  //                           <td>${data[index].email}</td>
  //                           <td>${data[index].dob}</td>
  //                           <td>${data[index].phone_number}</td>
  //                           <td>${data[index].creation_date}</td>
  //                           <td>
  //                               <div class="dropdown">
  //                                   <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  //                                   <!-- Three dots icon (ellipsis) -->
  //                                   &#8230;
  //                                   </button>
  //                                   <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
  //                                   <a class="dropdown-item" href="${base_url}/view/edit-user.php?id=${data[index].uniqid}">Edit</a>
  //                                   <a class="dropdown-item userDelete" id="${data[index].uniqid}" href="javascript:void(0)" >Delete</a>
  //                                   <!-- Add more actions as needed -->
  //                                   </div>
  //                               </div>
  //                           </td>
  //                       </tr>`;
  //           $('#userTable tbody').append(tableHtml);
  //           index++;
  //         }
  //       }else{
  //         var tableHtml = ` <tr>

  //               <td valign="top" colspan="8" class="dataTables_empty text-center">No data available in table</td>
  //           </tr>`;
  //           $('#userTable tbody').append(tableHtml);
  //       }

  //     },
  //     error: function (error) {

  //       Swal.fire({
  //         icon: "error",
  //         title: "Oops...",
  //         text: "Something went wrong!",
  //       });
  //     }
  //   });

  // }

  // function updatePagination() {
  //   var totalPages = Math.ceil(totalPage / itemsPerPage);
  //   var startPage = Math.max(1, currentPage - 2);
  //   var endPage = Math.min(startPage + 3, totalPages);
  //   var paginationHtml = '<button class="Me_Btn non-active prev me-1" ' + (currentPage == 1 ? 'disabled' : '') + '>Prev</button>';

  //   for (var i = startPage; i <= endPage; i++) {
  //     paginationHtml += '<button class="Me_Btn pageLInk ' + (i === currentPage ? 'active' : 'non-active  ') + '" ' + (i === currentPage ? 'disabled' : '') + '  data-page="' + i + '" search me-1">' + i + '</button>';
  //   }
  //   paginationHtml += '<button class="Me_Btn next non-active" ' + (currentPage == totalPages ? 'disabled' : '') + '>Next</button>';
  //   $('#pagination').html(paginationHtml);
  // }

  // Initial table and pagination rendering
  // updateTable(currentPage);
  // updatePagination();

  // Pagination click event
  // $(document).on('click', '.pageLInk', function (e) {
  //   e.preventDefault();
  //   currentPage = parseInt($(this).data('page'));
  //   updateTable(currentPage);
  //   updatePagination();
  // });
  // $(document).on('click', '.prev', function (e) {
  //   e.preventDefault();
  //   currentPage--;
  //   updateTable(currentPage);
  //   updatePagination();
  // });
  // $(document).on('click', '.next', function (e) {
  //   e.preventDefault();
  //   currentPage++;
  //   updateTable(currentPage);
  //   updatePagination();
  // });

  // $(document).on('click', '#user-search-btn', function (e) {
  //   e.preventDefault();
  //   currentPage = 1;
  //   updateTable(1);
  //   updatePagination();
  // });
  // $(document).on('keyup', '#user-search', function (e) {
  //   e.preventDefault();
  //   currentPage = 1;
  //   updateTable(1);
  //   updatePagination();
  // });
  // $(document).on('change','#user-limit',function(e) {

  //   itemsPerPage  = $(this).val();
  //   e.preventDefault();
  //   currentPage = 1;
  //   updateTable(1);
  //   updatePagination();
  // });


  $(document).on('click', '#user-search-btn', function () {

    var searchTerm = $('#user-search').val().toLowerCase();
    var tab = $(this).data('tab');
    var page = $(this).data('page');
    var limit = $(this).data('limit');
    window.location.href = base_url + "/view/users.php?page=" + page + "&tab=" + tab + "&search=" + searchTerm + "&limit=" + limit;
  });
  $(document).on('change', '#user-limit', function () {

    var searchTerm = $('#user-search').val().toLowerCase();
    var tab = $(this).data('tab');
    var page = 1//$(this).data('page');
    var limit = $(this).val();

    window.location.href = base_url + "/view/users.php?page=" + page + "&tab=" + tab + "&search=" + searchTerm + "&limit=" + limit;
  });
});
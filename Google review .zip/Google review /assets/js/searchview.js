jQuery(document).ready(function ($) {
    $('.align-items-base').remove();
    var company_reviews = [];
    var selected_reviews = [];
    var per_review_charge = [];
    var not_possible_data = [];

    var postData = {
        id: uniqid,
        place_id: place_id,
        type: 'get_qoute',
    };
    try {
        $.ajax({
            url: '/qoute/data/searchview.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(postData),
            success: function (data) {

                var response = $.parseJSON(data);

                if (response.status == 1) {
                    company_reviews = response.data.reviews;
                    //console.log(company_reviews)
                    
                    per_review_charge = response.data.per_review_charge;
                    not_possible_data = response.not_possible_data;
                    //console.log(not_possible_data)
                    if(not_possible_data.length>0){
                        company_reviews =   remove_not_possible_data(company_reviews,not_possible_data);
                        //console.log(company_reviews)
                        show_review(company_reviews);
                        total_review_colculate(company_reviews);
                    }else{
                        show_review(company_reviews);
                        total_review_colculate(company_reviews);
                    }
                    
                    calculate_the_raview();
                }

            },
            error: function (xhr, status, error) {
                console.error(xhr, status, error);
            }
        });
    } catch (exception) {
        console.error('Exception caught:', exception);
    }
    $(document).on('change', '#short_by_date', function () {
        var short_by_date = $(this).val();
        var filter_by_rating = $('#filter_by_rating').val();
        var short_by_rating = $('#short_by_rating').val();
        filter_shorting_review(filter_by_rating, short_by_date, short_by_rating);

    });
    function remove_not_possible_data(company_reviews, not_possible_data) {
        // Iterate through the not_possible_data array
        not_possible_data.forEach(notPosiObj => {
            // Find the index of the object with matching review_id in the company_reviews array
            const index = company_reviews.findIndex(companyReview => companyReview.review_id === notPosiObj.review_id);
            
            // If the object is found, remove it from the company_reviews array
            if (index !== -1) {
                company_reviews.splice(index, 1);
            }
        });
    
        // Return the modified company_reviews array
        return company_reviews;
    }
    
    /* $(document).on('change', '#filter_by_rating', function () {        
        var filter_by_rating = $(this).val();
        var short_by_date = $('#short_by_date').val();
        var short_by_rating = $('#short_by_rating').val();
        filter_shorting_review(filter_by_rating,short_by_date,short_by_rating);
    }); */
    $(document).on('click', '#0', function () {
       
        $(this).toggleClass('active non-active');
        $('.filter-tab').removeClass('active non-active');

    });
    $(document).on('click', '#filter_by_rating .filter-tab', function () {
        // Toggle "active" and "non-active" classes for the clicked tab
        $(this).toggleClass('active non-active');
        if($(this).attr('id') != 0){
            $('#0').removeClass('active non-active');
        }
        if($('#filter_by_rating .filter-tab.active').length==5){
            $('#0').addClass('active non-active');
        }
        // Collect selected filters
        var selectedFilters = [];
        $('#filter_by_rating .filter-tab.active').each(function () {
            if ($(this).attr('id') != 0) {
                selectedFilters.push($(this).attr('id'));
            } 
            if($(this).attr('id')==0){
                selectedFilters=[];
                ///console.log(selectedFilters)
            }
            

        });
       
        if (selectedFilters.length == 0) {
            $('#filter_by_rating #0').addClass('active non-active')
        }
        selected_reviews = Array.from(new Set(selected_reviews));
        // Here 'selectedFilters' array will contain the IDs of the active filter tabs
        var short_by_date = $('#short_by_date').val();
        var short_by_rating = $('#short_by_rating').val();
        filter_shorting_review(selectedFilters, short_by_date, short_by_rating);
        ///calculate_the_raview();
    });
    // $(document).on('click', '.p-5-0 .form-check-input', function () {
    //     // Toggle "active" and "non-active" classes for the clicked tab
    //     $(this).toggleClass('active non-active');

    //     // Collect selected filters
    //     var selectedFilters = [];
    //     $('.p-5-0 .form-check-input:checked').each(function () {
    //         selectedFilters.push($(this).val());
    //     });

    //     // Here 'selectedFilters' array will contain the IDs of the active filter tabs
    //     var short_by_date = $('#short_by_date').val();
    //     var short_by_rating = $('#short_by_rating').val();
    //     filter_shorting_review(selectedFilters, short_by_date, short_by_rating);
    // });
    $(document).on('click', '#reload-window', function () {
        window.location.reload();
    });
    $(document).on('change', '#short_by_rating', function () {
        var short_by_rating = $(this).val();
        var filter_by_rating = $('#filter_by_rating').val();
        var short_by_date = $('#short_by_date').val();
        filter_shorting_review(filter_by_rating, short_by_date, short_by_rating);
    });

    $(document).on('change', '.select_review_for_delection', function () {
        var id = parseInt($(this).val());
        var isChecked = $(this).prop('checked');

        if (isChecked) {
            selected_reviews.push(id);
            $(this).parent().parent().parent().parent().parent().parent().parent().parent().addClass('active');
        } else {
            var index = $.inArray(id, selected_reviews);
            if (index !== -1) {
                selected_reviews.splice(index, 1);
            }
            $(this).parent().parent().parent().parent().parent().parent().parent().parent().removeClass('active')
        }
        calculate_the_raview();
        //console.log(selected_reviews)
    });

    $(document).on('change', '.custom-width-62 .form-check-input', function () {

        if($(this).prop('checked')==true){
            $(this).parent().parent().addClass('active');
        }else{
            $(this).parent().parent().removeClass('active')
        }   
        
        calculate_the_raview();
    })
    $('#rating1').on('change', function () {
        var isCheckedAll = $(this).prop('checked');
        $('.selectRating1').each(function () {
            var id = parseInt($(this).val());
            var isChecked = isCheckedAll; // Use isCheckedAll for all checkboxes

            if (isChecked) {
                selected_reviews.push(id);
                $(this).parent().parent().parent().parent().parent().parent().parent().parent().addClass('active');
            } else {
                var index = $.inArray(id, selected_reviews);
                if (index !== -1) {
                    selected_reviews.splice(index, 1);
                }
                $(this).parent().parent().parent().parent().parent().parent().parent().parent().removeClass('active')
            }
            calculate_the_raview();
            this.checked = isChecked;
        });
    });
    $('#rating2').on('change', function () {
        var isCheckedAll = $(this).prop('checked');
        $('.selectRating2').each(function () {
            var id = parseInt($(this).val());
            var isChecked = isCheckedAll; // Use isCheckedAll for all checkboxes

            if (isChecked) {
                selected_reviews.push(id);
                $(this).parent().parent().parent().parent().parent().parent().parent().parent().addClass('active');
            } else {
                var index = $.inArray(id, selected_reviews);
                if (index !== -1) {
                    selected_reviews.splice(index, 1);
                }
                $(this).parent().parent().parent().parent().parent().parent().parent().parent().removeClass('active')
            }
            calculate_the_raview();
            this.checked = isChecked;
        });
    });
    $('#rating3').on('change', function () {
        var isCheckedAll = $(this).prop('checked');
        $('.selectRating3').each(function () {
            var id = parseInt($(this).val());
            var isChecked = isCheckedAll; // Use isCheckedAll for all checkboxes

            if (isChecked) {
                selected_reviews.push(id);
                $(this).parent().parent().parent().parent().parent().parent().parent().parent().addClass('active');
            } else {
                var index = $.inArray(id, selected_reviews);
                if (index !== -1) {
                    selected_reviews.splice(index, 1);
                }
                $(this).parent().parent().parent().parent().parent().parent().parent().parent().removeClass('active')
            }
            calculate_the_raview();
            this.checked = isChecked;
        });
    });



    function filter_shorting_review(filter_by_rating, short_by_date, short_by_rating) {
        var temp_company_reviews = company_reviews;
        /* if(filter_by_rating != ''){
            temp_company_reviews = company_reviews.filter(function(item) {
                return item.rating === parseInt(filter_by_rating);
            });
        } */
        // Filter by rating
        if (filter_by_rating.length > 0) {
            temp_company_reviews = temp_company_reviews.filter(function (item) {
                return filter_by_rating.includes(item.review_rating.toString()) || selected_reviews.includes(item.sr_number);
            });
            
        }

        if (short_by_date == 'asc') {
            temp_company_reviews.sort(function (a, b) {
                return a.review_timestamp - b.review_timestamp;
            });
        }
        if (short_by_date == 'desc') {
            temp_company_reviews.sort(function (a, b) {
                return b.review_timestamp - a.review_timestamp;
            });
        }

        if (short_by_rating == 'asc') {
            temp_company_reviews.sort(function (a, b) {
                return a.rating - b.review_rating;
            });
        }
        if (short_by_rating == 'desc') {
            temp_company_reviews.sort(function (a, b) {
                return b.rating - a.review_rating;
            });
        }
        show_review(temp_company_reviews);
    }

    function total_review_colculate(reviews) {
        if (reviews.length > 0) {
            var count1 = 0;
            var count2 = 0;
            var count3 = 0;
            var count4 = 0;
            var count5 = 0;
            reviews.forEach(function (element) {


                var rating = element.review_rating;
                var fullStars = Math.floor(rating);
                if (fullStars == 1) {
                    count1++;

                    $('.total1Rating').text(`1 (${count1})`);
                } else {
                    $('.total1Rating').text(`1 (${count1})`);
                }
                if (fullStars == 2) {
                    count2++;
                    $('.total2Rating').text(`2 (${count2})`);
                } else {
                    $('.total2Rating').text(`2 (${count2})`);
                }
                if (fullStars == 3) {
                    count3++;
                    $('.total3Rating').text(`3 (${count3})`);
                } else {
                    $('.total3Rating').text(`3 (${count3})`);
                }
                if (fullStars == 4) {
                    count4++;
                    $('#total4Rating').text(`4 (${count4})`);
                } else {
                    $('#total4Rating').text(`4 (${count4})`);
                }
                if (fullStars == 5) {
                    count5++;
                    $('#total5Rating').text(`5 (${count5})`);
                } else {
                    $('#total5Rating').text(`5 (${count5})`);
                }




            });
        }
    }
    function show_review(reviews) {
        $('#search_result .row.mb-3.me-0').remove();
        if (reviews.length > 0) {
            var html = '';
            var html1 = '';
            var count = 0;
            var count1 = 0;
            var count2 = 0;
            var count3 = 0;
            reviews.forEach(function (element) {
                var author_name = element.author_title;
                var review_id = element.review_id;
                var profile_photo_url = element.author_image;
                var relative_time_description = element.review_datetime_utc;
                var text = element.review_text != null ? element.review_text : '';
                var date = new Date(element.review_timestamp * 1000); // Convert seconds to milliseconds
                var formattedDate = $.format.date(date, 'yyyy-MM-dd');
                var formattedTime = $.format.date(date, 'HH:mm ');

                var review_link = element.review_link;

                var rating = element.review_rating;
                var rating_html = '';
                var fullStars = Math.floor(rating);
                var decimalPart = rating % 1;
                var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
                var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
                count++;

                // Append empty stars
                // Append full stars
                for (var i = 0; i < fullStars; i++) {
                    rating_html += `<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">`;
                }
                // Append half star if needed
                if (hasHalfStar) {
                    rating_html += `<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">`;
                }
                for (var i = 0; i < emptyStars; i++) {
                    rating_html += `<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">`;
                }

                if (fullStars == 1) {
                    count1++;

                    $('#total1Rating').text(`1 (${count1})`);
                } else {
                    $('#total1Rating').text(`1 (${count1})`);
                }
                if (fullStars == 2) {
                    count2++;
                    $('#total2Rating').text(`2 (${count2})`);
                } else {
                    $('#total2Rating').text(`2 (${count2})`);
                }
                if (fullStars == 3) {
                    count3++;
                    $('#total3Rating').text(`3 (${count3})`);
                } else {
                    $('#total3Rating').text(`3 (${count3})`);
                }

                html += `<div class="row review_box ${selected_reviews.includes(element.sr_number) ? 'active' : ''}">
                <div class="col-sm-12 align-items-center pe-0">
                    <div class='row'>
                        <div class='col-sm-4 d-flex align-items-center'>
                            <div class='row w-100'>
                                <div class='col-4 expired'>
                                    <div class="checkbox review_title_inner align-items-center">
                                        <div class="form-check">
                                            <input type="hidden" id="reviewChargeValue">
                                            <input type="hidden" id="reviewRating" value="${rating}">
                                            <input type="hidden" id="review_id" value="${review_id}">
                                            <input type="hidden" id="review_link" name="review_link" value="${review_link}">
                                            <input class="form-check-input selectRating${rating} select_review_for_delection" type="checkbox" ${selected_reviews.includes(element.sr_number) ? 'checked' : ''} value="${element.sr_number}">

                                        </div>
                                    </div>
                                </div>
                                <div class='col-8 expired-100'>
                                    <div class="d-flex review_title_inner align-items-center mr-2">
                                        <img src="${profile_photo_url}" alt="${author_name}">
                                        <h6 class="m-0">${author_name}</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='col-sm-8'>
                            <div class="review_timing">
                                <p>
                                    <input type='hidden' value='${formattedTime} Uhr' id='formattedTime'>
                                    <input type='hidden' value='${formattedDate}' id='formattedDate'>
                                    <span class="text-end">${rating_html}</span>
                                    <span>${formattedTime} Uhr ${formattedDate}</span>
                                </p>
                                <p data-text='${text.length < 150 ? text.substring(0, 150) : text}' class='description'>
                                    ${text.length > 150 ? text.substring(0, 150)+'...' : text}
                                </p>
                                ${text.length > 150 ? '<a href="javascript:void(0)" data-type="read_more" class="read-more-btn">mehr lesen…</a>' : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
    


            });
            $('#search_result').html(html);
            $('#total-review-count').text(`${count} Bewertungen`);

            if($('#rating1').prop('checked')==true){
                $('#rating1').trigger('change');
            }
            if($('#rating2').prop('checked')==true){
                $('#rating2').trigger('change');
            }
            if($('#rating3').prop('checked')==true){
                $('#rating3').trigger('change');
            }
            calculate_the_raview()
        } else {
            var html = `<div class="row mb-3 me-0">
                            <div class="col-12" style="text-align: center;font-size: 30px;margin-top: 20px;">No review found</div>
                        </div>`;
            $('#search_result').html(html);
            $('#total-review-count').text(`${0} Bewertungen`);
        }
    }
    $(document).on('click', ".read-more-btn", function () {
        var $content = $(this).prev(".description");
        var read_more = $(this).attr("data-type");
        var longtext = $(this).prev(".description").attr('data-text');
        var shorttext = $(this).prev(".description").text();
        if (read_more=='read_more') {
            $(this).text("Lese weniger");
            $(this).attr("data-type",'read_less')
            $(this).prev(".description").text(longtext);
            $(this).prev(".description").attr('data-text',shorttext);
        } else if (read_more=='read_less') {
            $(this).text("mehr lesen…");
            $(this).attr("data-type",'read_more')
            $(this).prev(".description").text(longtext);
            $(this).prev(".description").attr('data-text',shorttext  );
        }
    });
    /* function calculate_the_raview(){
        // review_rate_calculation
        var value = 0;
        for (var i = 0; i < per_review_charge.length; i++) {
            var rangeMin = parseInt(per_review_charge[i].range_min);
            var rangeMax = parseInt(per_review_charge[i].range_max);
    
            if (selected_reviews.length >= rangeMin && selected_reviews.length <= rangeMax) {
                value = per_review_charge[i].range_amt;
            }
        }
        
        $('#reviewChargeValue').val(value);
        $('.review_rate_calculation').html(selected_reviews.length+' X $'+value+'=<span style="font-size: 25px;color: #5d46b7;">$'+(selected_reviews.length*value)+'</span>');
       
    } */


    function calculate_the_raview() {
        
        var value = 0;
        var minValue = parseInt(per_review_charge[0].range_amt);
        var maxValue = parseInt(per_review_charge[per_review_charge.length - 1].range_amt);
        var selectedReviewsLength = $(".select_review_for_delection:checked").length;
        if(selectedReviewsLength>0){
            $('.submit_qoute_confirmation').attr('disabled',false);
        }else{
            $('.submit_qoute_confirmation').attr('disabled',true); 
        }
    
        if (!selectedReviewsLength || selectedReviewsLength === 0) {
            value = minValue;
            $('#total-review-select-price').text(`${selectedReviewsLength} Bewertungen x ${0}€`);
            $('#Total_Price').html(0 + '€ <span class="net-price" >Netto</span>');
            $('.total-deleted-review').text(selectedReviewsLength + ' Stück');
            $('.deleted-review-price').text(`${0}€`);
            $('.deleted-review-price').text(`${0}€`);
            $('.element-price-total').text(`${0}€`);
        } else {
            var selectedRange;
            // Find the appropriate range for the selected number of reviews
            for (var i = 0; i < per_review_charge.length; i++) {
                var rangeMin = parseInt(per_review_charge[i].range_min);
                var rangeMax = parseInt(per_review_charge[i].range_max);
                var rangeAmt = parseInt(per_review_charge[i].range_amt);
    
                if (selectedReviewsLength >= rangeMin && selectedReviewsLength <= rangeMax) {
                    selectedRange = per_review_charge[i];
                    break; // Once found, exit the loop
                }else if(selectedReviewsLength >= rangeMax){
                    selectedRange = per_review_charge[i];   
                }
            }
    
            // Calculate the value based on the selected range
            if (selectedRange) {
                value = (selectedReviewsLength) * selectedRange.range_amt;
                $('#total-review-select-price').text(`${selectedReviewsLength} Bewertungen x ${selectedRange.range_amt}€`);
                $('#Total_Price').html(value + '€ <span class="net-price" >Netto</span>');
                $('.total-deleted-review').text(selectedReviewsLength + ' Stück');
                $('.deleted-review-price').text(`${selectedRange.range_amt}€`).attr('rangeAmt', selectedRange.range_amt);
                $('.element-price-total').html(`${value}€  <span class="net-price" >Netto</span>`);
            }
        }
    
        // $('#total-review-select-price').text(`${selectedReviewsLength} Bewertungen x ${value}` );
        // $('#Total_Price').text(value);
        $('#reviewChargeValue').val(value);
        ReviewCalculateAfterDeletion()
    }
    
    

    function ReviewCalculateAfterDeletion() {
        var company_review = parseFloat($('#search_company_bio').attr('company-review'));
        var company_total_user_review = parseInt($('#search_company_bio').attr('company-total-user-review'));
        var total_deleted_review = 0;
        $('.review_box.active').each(function (index, val) {
            total_deleted_review += parseInt($(this).find('#reviewRating').val())
        })
        var selected_review  = $(".select_review_for_delection:checked").length;
        var total_user_after_delete = parseInt(company_total_user_review) - parseInt(selected_review);
        var rating = ((company_review * company_total_user_review) - total_deleted_review) / total_user_after_delete;

        var fullStars = Math.floor(rating);
        var decimalPart = rating % 1;
        var hasHalfStar = decimalPart >= 0.49 && decimalPart <= 0.99;
        var emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        var rating_html = '';


        for (var i = 0; i < fullStars; i++) {
            rating_html += `<img class="img-fluid rating-img" src="../assets/img/fill-rating.png" alt="">`;
        }
        // Append half star if needed
        if (hasHalfStar) {
            rating_html += `<img class="img-fluid rating-img" src="../assets/img/rating-half.png" alt="">`;
        }
        for (var i = 0; i < emptyStars; i++) {
            rating_html += `<img class="img-fluid rating-img" src="../assets/img/without-fill-rating.png" alt="">`;
        }
        $('#ratingUpdate').html(rating_html);
        $('.RatingValueUpdate').html(`${rating.toFixed(1) > 5 ? 5 : rating.toFixed(1)}<small> /5.0</small>`);
        $('.modal-rating-update').html(rating_html);

    }
    // Function to search for the searchString in the text property
    function searchByText(searchString, data) {
        const matchingItems = [];

        data.forEach(item => {
            const text = (item.author_title + ' ' + item.review_text).toLocaleLowerCase();
            if (text.includes(searchString)) {
                matchingItems.push(item);
            }
        });

        return matchingItems;
    }



    $(document).on('keyup', '.customer-search', function () {
        var search = $(this).val().toLocaleLowerCase();
        const matchingItems = searchByText(search, company_reviews);
        show_review(matchingItems);

    });
    /*Pooja code*/
    $("#send_qoute_button").click(function () {
        $("script").each(function () {
            var scriptContent = $(this).html();
            if (scriptContent.includes("const uniqid")) {
                var matches = scriptContent.match(/const uniqid = '([^']+)';/);
                if (matches) {
                    let uniqid = matches[1];
                    return false; // Stop looping once uniqid is found
                }
            }
        });


        var reviewChargeValue = parseFloat($('#reviewChargeValue').val());
        //console.log("Review Charge Value Retrieved: " + reviewChargeValue); // Debugging statement

        // Loop through each checkbox with class "select_review_for_delection"
        $(".select_review_for_delection:checked").each(function () {
            var reviewBox = $(this).closest(".review_box"); // Get the parent review_box div
            var authorName = reviewBox.find(".review_title_inner h6").text(); // Get author name
            var formattedDate = reviewBox.find(".review_timing #formattedDate").val(); // Get formatted date
            var formattedTime = reviewBox.find(".review_timing #formattedTime").val(); // Get formatted time
            var text = reviewBox.find(".description").text(); // Get review text
            var reviewRating = reviewBox.find("#reviewRating").val(); // Get review text
            var review_id = reviewBox.find("#review_id").val(); // Get review text
            var ratingHtml = reviewBox.find(".text-end").html(); // Get rating HTML
            var relativeTimeDescription = reviewBox.find(".year_ago p").text(); // Get relative time description
            var profile_photo_url = reviewBox.find(".review_title_inner img").attr("src");
            var review_link = reviewBox.find('input[name="review_link"]').val();
            var rangeAmt = $('.deleted-review-price').attr('rangeAmt');
            var place_id = $('#place_id').val();
            // Now you can use these variables as needed
            // console.log("Author Name: " + authorName);
            // console.log("Date: " + formattedDate);
            // console.log("Time: " + formattedTime);
            // console.log("Review Text: " + text);
            // console.log("Rating HTML: " + ratingHtml);
            // console.log("Relative Time Description: " + relativeTimeDescription);
            // console.log("uniqid: " + uniqid);
            // console.log("profile_photo_url: " + profile_photo_url);
            // Here you can perform any further actions with the retrieved data
            // Send the review data to the PHP script using AJAX
            $.ajax({
                type: "POST",
                url: base_url + "/ajax/selectedReviewInsert.php",
                data: {
                    authorName: authorName,
                    formattedDate: formattedDate,
                    formattedTime: formattedTime,
                    text: text,
                    ratingHtml: ratingHtml,
                    relativeTimeDescription: relativeTimeDescription,
                    uniqid: uniqid,
                    review_id: review_id,
                    place_id: place_id,
                    reviewChargeValue: reviewChargeValue,
                    profile_photo_url: profile_photo_url,
                    review_link: review_link,
                    reviewRating: reviewRating,
                    rangeAmt: rangeAmt
                },
                success: function (response) {
                    // console.log("Review inserted successfully:", response);
                    // Perform any further actions after successful insertion
                },
                error: function (xhr, status, error) {
                    console.error("Error inserting review:", error);
                    // Handle errors if insertion fails
                }
            });
        });
        $.ajax({
            type: "POST",
            url: base_url + "/ajax/rateInsert.php",
            data: {
                reviewChargeValue: reviewChargeValue,
                uniqid: uniqid
            },
            success: function (response) {
                //console.log("Review charge value inserted successfully:", response);
                // Swal.fire({
                //     title: 'Request submitted successfully!',
                //     // text: 'Your message here',
                //     icon: 'success',
                //     confirmButtonText: 'OK'
                // });
                $('#submit_qoute_confirmation').modal('hide');
                $('#submit_qoute_confirmation1').modal('show');
                $("#send_qoute_button").hide();
            },
            error: function (xhr, status, error) {
                console.error("Error inserting review charge value:", error);
                // Handle errors if insertion fails
            }
        });
        $('.price_per_review_management').hide();
        $("#send_qoute_button").hide();
        $('.shorting_filder_selection').hide();

    });
});





// Truncate text after 150 characters

// Timer show 


// Function to calculate time difference and update timer
function updateTimer(expiredDateTime) {
    // Get current date/time
    var now = new Date();

    // Calculate time difference in milliseconds
    var timeDiff = expiredDateTime - now;

    // Check if the timer has expired
    if (timeDiff <= 0) {
        document.write("<h2>Offer Expired!</h2>");
        return;
    }

    // Convert time difference to hours, minutes, and seconds
    var days = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
    var hours = Math.floor(timeDiff / (1000 * 60 * 60));
    var minutes = Math.floor((timeDiff % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((timeDiff % (1000 * 60)) / 1000);

    // Display remaining time in the format: hours : minutes : seconds
    document.getElementById('timer').innerHTML = hours + "h : " + minutes + "m : " + seconds + "s";
    document.getElementById('element-error').innerText = `Angebot läuft nach ${days} Tagen ab `;
}





// Initial update of the timer


var expiredDateTime = '';
var offerTimer = $('.offerTimer').attr('date');
var daysToAdd = parseInt($('.offerTimer').attr('expireIN'));
console.log(daysToAdd)
var inputDate = new Date(offerTimer);
console.log(inputDate)
var resultDate = new Date(inputDate);
resultDate.setDate(resultDate.getDate() + daysToAdd);
expiredDateTime = resultDate;
//updateTimer(expiredDateTime);
// console.log(resultDate)
// setInterval(function () {
//     updateTimer(expiredDateTime);
// }, 1000);
var daysDifference = calculateDaysDifference(expiredDateTime);
console.log("Days difference:", daysDifference);
function calculateDaysDifference(expiredDateTime) {
    // Get current date/time
    var now = new Date();

    // Calculate time difference in milliseconds
    var timeDiff = expiredDateTime.getTime() - now.getTime();

    // Convert time difference to days
    var daysDiff = Math.floor(timeDiff / (1000 * 60 * 60 * 24));

    return daysDiff;
}
// document.addEventListener("DOMContentLoaded", function() {
//     var headers = document.querySelectorAll('.accordion-header');
//     headers.forEach(function(header) {
//       header.addEventListener('click', function() {
//         var content = this.nextElementSibling;
//         if (content.style.display === 'block') {
//           content.style.display = 'none';
//         } else {
//           content.style.display = 'block';
//         }
//       });
//     });
//   });